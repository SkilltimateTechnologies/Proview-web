import { sqliteTable, text, integer, real, index, uniqueIndex } from "drizzle-orm/sqlite-core";

export * from "./auth-schema";

const now = () => new Date();

/** Colleges / organizations. Single multi-tenant deployment. */
export const tenants = sqliteTable("tenants", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  shortName: text("short_name").notNull(), // logo chip e.g. "GR"
  slug: text("slug").notNull().unique(),
  logoUrl: text("logo_url"),
  primaryColor: text("primary_color").notNull().default("#1e3a5f"),
  enabled: integer("enabled", { mode: "boolean" }).notNull().default(true),
  // ---- Capacity quotas (see lib/tenant-quota.ts) ----
  // NULL = inherit the platform-global default in `settings`; if that is NULL too,
  // unlimited. 0 and negatives are read as "not set", never as "block everything":
  // an accidental 0 must not cancel a whole college's exam, and `enabled = false`
  // already exists for deliberately stopping a tenant.
  // Nullable on purpose: REQUIRED_COLUMNS adds these to live databases with
  // ALTER TABLE ADD COLUMN, which cannot add a NOT NULL column.
  maxConcurrentAttempts: integer("max_concurrent_attempts"),
  maxEvidencePerAttempt: integer("max_evidence_per_attempt"),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(now),
});

/** Domain profile attached to a Better Auth user. */
export const profiles = sqliteTable(
  "profiles",
  {
    userId: text("user_id").primaryKey(), // == auth user.id
    tenantId: text("tenant_id"),          // null for platform super admin
    role: text("role").notNull(),         // super_admin | tpo | student
    displayId: text("display_id").notNull(), // USR-0007
    phone: text("phone"),
    enabled: integer("enabled", { mode: "boolean" }).notNull().default(true),
    // TPO module permissions JSON: { dashboard, liveMonitor, reports, questionBank, exams, users, branding, settings }
    permissions: text("permissions", { mode: "json" }).$type<Record<string, boolean>>(),
    createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(now),
  },
  (t) => [index("profiles_tenant_idx").on(t.tenantId)],
);

/** Class = Branch + Batch start year + Section. */
export const classes = sqliteTable(
  "classes",
  {
    id: text("id").primaryKey(),
    tenantId: text("tenant_id").notNull(),
    branch: text("branch").notNull(),        // CSE, ECE, MECH
    batchStartYear: integer("batch_start_year").notNull(), // 2021
    section: text("section").notNull(),      // A, B
    code: text("code").notNull(),            // CSE-A (display)
    createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(now),
  },
  (t) => [index("classes_tenant_idx").on(t.tenantId)],
);

/** Student records (Phase 2 desktop login; managed here in Phase 1). */
export const students = sqliteTable(
  "students",
  {
    id: text("id").primaryKey(),
    tenantId: text("tenant_id").notNull(),
    classId: text("class_id"),
    // The student's home/regular section before they were promoted into a special
    // cohort (e.g. ELITE). Set when moving into Elite so the move is reversible and
    // reports can show where they came from. Null = never moved.
    originalClassId: text("original_class_id"),
    rollNo: text("roll_no").notNull(),   // STU-21CS102
    name: text("name").notNull(),
    email: text("email"),
    phone: text("phone"),
    gender: text("gender"),              // male | female
    // Phase 1 stores a login password for the Phase 2 desktop student client.
    password: text("password").notNull().default("Welcome@123"),
    // Force a password change on first login with the issued password.
    mustChangePassword: integer("must_change_password", { mode: "boolean" }).notNull().default(true),
    enabled: integer("enabled", { mode: "boolean" }).notNull().default(true),
    createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(now),
  },
  (t) => [
    index("students_tenant_idx").on(t.tenantId),
    index("students_class_idx").on(t.classId),
    // One student = one row per tenant. Enforced in the DB because every
    // application-level check is a select-then-insert that a concurrent request can
    // slip past, and because roll numbers arrive from three different write paths.
    //
    // The LIVE index is on the EXPRESSION `upper(trim(roll_no))` so that case and
    // padding variants collide; drizzle cannot express that here, so this
    // declaration is the plain-column approximation and
    // `src/api/database/invariants.ts` creates the real one at boot.
    // Declaring it here does NOT guarantee it exists on a given database.
    uniqueIndex("students_tenant_roll_uq").on(t.tenantId, t.rollNo),
  ],
);

/** Question bank. */
export const categories = sqliteTable(
  "categories",
  {
    id: text("id").primaryKey(),
    tenantId: text("tenant_id").notNull(),
    name: text("name").notNull(),
    description: text("description"),
    color: text("color").notNull().default("#1e3a5f"),
    createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(now),
  },
  (t) => [index("categories_tenant_idx").on(t.tenantId)],
);

export const questions = sqliteTable(
  "questions",
  {
    id: text("id").primaryKey(),
    tenantId: text("tenant_id").notNull(),
    categoryId: text("category_id"),
    type: text("type").notNull(), // mcq | multi | truefalse | fillblank | short | essay | coding
    prompt: text("prompt").notNull(),
    // options: string[] for mcq/multi/fillblank; empty for others
    options: text("options", { mode: "json" }).$type<string[]>(),
    // correct: for objective types (indices / value / boolean). null for AI-graded.
    correct: text("correct", { mode: "json" }).$type<unknown>(),
    // coding: language + starter + reference solution + testcases
    meta: text("meta", { mode: "json" }).$type<Record<string, unknown>>(),
    points: integer("points").notNull().default(1),
    difficulty: text("difficulty").notNull().default("medium"), // easy | medium | hard
    topic: text("topic"),
    // Global questions are visible to (and reusable by) every college. College-specific = own tenant only.
    isGlobal: integer("is_global", { mode: "boolean" }).notNull().default(true),
    aiGenerated: integer("ai_generated", { mode: "boolean" }).notNull().default(false),
    createdBy: text("created_by"),
    createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(now),
  },
  (t) => [index("questions_tenant_idx").on(t.tenantId)],
);

/** Exams / assessments. */
export const exams = sqliteTable(
  "exams",
  {
    id: text("id").primaryKey(),
    tenantId: text("tenant_id").notNull(),
    title: text("title").notNull(),
    classId: text("class_id"),
    // sectionIds: null/empty = all sections; otherwise a subset of class ids
    sectionIds: text("section_ids", { mode: "json" }).$type<string[]>(),
    // assignMode: "cohort" = target sections (sectionIds); "students" = only the
    // explicitly picked students (roster "add" list), no cohort match at all.
    assignMode: text("assign_mode").notNull().default("cohort"),
    status: text("status").notNull().default("draft"), // draft | scheduled | live | finished
    startAt: integer("start_at", { mode: "timestamp_ms" }),
    endAt: integer("end_at", { mode: "timestamp_ms" }),
    durationMin: integer("duration_min").notNull().default(60),
    totalPoints: integer("total_points").notNull().default(0),
    // Admin global hold (outage). heldAt set = currently held; holdMs = total ms already held.
    heldAt: integer("held_at", { mode: "timestamp_ms" }),
    holdMs: integer("hold_ms").notNull().default(0),
    // Extra minutes granted by admin for the whole exam.
    extraMin: integer("extra_min").notNull().default(0),
    // When AI/coding grading is allowed to run.
    //   NULL / "after_close" -> deferred until the exam window has closed (default)
    //   "immediate"          -> graded at submit, the pre-2026-08-30 behaviour
    // Deferring is a load decision: 300 students hitting the bell used to fire 300
    // AI grading passes plus Judge0 calls from the web process while other students
    // were still writing to the same database. Objective questions are unaffected —
    // they are graded inline at submit (pure CPU) and still return instantly.
    // Nullable on purpose: REQUIRED_COLUMNS adds this to live databases with
    // ALTER TABLE ADD COLUMN, which cannot add a NOT NULL column.
    gradingMode: text("grading_mode").$type<"after_close" | "immediate">(),
    createdBy: text("created_by"),
    createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(now),
  },
  (t) => [index("exams_tenant_idx").on(t.tenantId)],
);

export const examQuestions = sqliteTable(
  "exam_questions",
  {
    id: text("id").primaryKey(),
    examId: text("exam_id").notNull(),
    questionId: text("question_id").notNull(),
    order: integer("order").notNull().default(0),
    points: integer("points").notNull().default(1),
  },
  (t) => [index("exam_questions_exam_idx").on(t.examId)],
);

/**
 * Ad-hoc roster overrides for an exam. Base eligibility is cohort-based
 * (class + optional sections). These rows let an admin explicitly add a
 * student who isn't in the cohort, or remove a student who is — e.g. when
 * merging students from another batch onto spare machines.
 *   mode "add"    -> student is eligible regardless of cohort
 *   mode "remove" -> student is excluded even if the cohort matches
 * An "add" always wins over a "remove".
 */
export const examRoster = sqliteTable(
  "exam_roster",
  {
    id: text("id").primaryKey(),
    examId: text("exam_id").notNull(),
    studentId: text("student_id").notNull(),
    mode: text("mode").notNull(), // add | remove
    createdBy: text("created_by"),
    createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(now),
  },
  (t) => [index("exam_roster_exam_idx").on(t.examId)],
);

/** A student's attempt at an exam. */
export const attempts = sqliteTable(
  "attempts",
  {
    id: text("id").primaryKey(),
    examId: text("exam_id").notNull(),
    studentId: text("student_id").notNull(),
    status: text("status").notNull().default("not_started"), // not_started | in_progress | submitted | graded
    score: real("score"),          // percentage 0-100
    integrityScore: real("integrity_score"), // 0-100 clean
    startedAt: integer("started_at", { mode: "timestamp_ms" }),
    // Total ms the exam was paused (e.g. internet loss). Added to the deadline so
    // the student is not penalised for a network drop — timer freezes while paused.
    pausedMs: integer("paused_ms").notNull().default(0),
    lastPausedAt: integer("last_paused_at", { mode: "timestamp_ms" }),
    // Last heartbeat from the student client — drives Live Monitor online/offline.
    lastSeenAt: integer("last_seen_at", { mode: "timestamp_ms" }),
    // Number of questions with a synced (server-received) answer. Kept current by
    // the per-answer autosave endpoint + finalizeAttempt, so reports can show
    // "answered N/total" even for attempts that never reached a normal submit.
    answeredCount: integer("answered_count").notNull().default(0),
    // True when the attempt was force-finalized by the server-side sweep because
    // the student started but never submitted (lost connection through the
    // cutoff). Lets reports show a distinct "Disconnected" status vs true Absent.
    disconnected: integer("disconnected", { mode: "boolean" }).notNull().default(false),
    // Section code (e.g. "CSM-C") captured at attempt time. Reports read this so a
    // later section change (e.g. promotion into ELITE) never retroactively relabels
    // historical results. Null on old rows -> reports fall back to current section.
    sectionSnapshot: text("section_snapshot"),
    // Which option-order scheme the student's paper was rendered with (see
    // lib/option-order.ts). Options are shuffled per student, so the review screen
    // needs to know whether to show this attempt in its shuffled order or in the
    // authored order. NULL on every attempt sat before shuffling existed, which is
    // exactly what makes those reviews render unchanged.
    optionOrder: text("option_order"),
    // The browser/OS user-agent string the client reported at /start, truncated.
    // Recorded because proctoring is a CLIENT capability: when a webcam, fullscreen
    // or screen-count check silently never worked, the only question a reviewer can
    // ask afterwards is "what was this sat on?" — and until this column existed the
    // database had no answer. Diagnostic only, never used for scoring or eligibility.
    // NULL on every attempt sat before this column existed.
    userAgent: text("user_agent"),
    submittedAt: integer("submitted_at", { mode: "timestamp_ms" }),
    createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(now),
  },
  (t) => [
    index("attempts_exam_idx").on(t.examId),
    index("attempts_student_idx").on(t.studentId),
    // The background sweeps filter by status alone (`in_progress` for auto-submit,
    // `submitted` for the grading reconcile). Without this index those are full
    // scans of every attempt ever taken, on a timer, forever — the cost grows with
    // history rather than with load. At ~58k stored attempts a single 60s scan
    // consumes an entire 2.5B-row monthly Turso allowance on its own.
    index("attempts_status_idx").on(t.status),
    // One attempt per student per exam, enforced by the DB. Without this, two
    // concurrent /start calls both SELECT nothing and both INSERT, which is how a
    // single student ended up with dozens of rows in the Live Monitor. /start now
    // relies on this constraint (insert -> catch conflict -> re-select).
    uniqueIndex("attempts_exam_student_uq").on(t.examId, t.studentId),
  ],
);

export const answers = sqliteTable(
  "answers",
  {
    id: text("id").primaryKey(),
    attemptId: text("attempt_id").notNull(),
    questionId: text("question_id").notNull(),
    response: text("response", { mode: "json" }).$type<unknown>(),
    score: real("score"),
    maxScore: real("max_score"),
    aiNotes: text("ai_notes"),
    autoGraded: integer("auto_graded", { mode: "boolean" }).notNull().default(false),
  },
  (t) => [
    index("answers_attempt_idx").on(t.attemptId),
    // One answer row per question per attempt. Without this, two concurrent
    // writers (autosave + submit, or submit + the auto-submit sweep) could each
    // insert a row for the same question: the grader sums every row, so a
    // student scored 103/100, and in the worst case a blank duplicate landed
    // beside the real answer and swallowed the marks. Both write paths now
    // upsert against this constraint.
    //
    // Declaring it here is NOT enough to guarantee it exists: `start` is just
    // `bun src/server.ts` with no migrate step, so a database that never had
    // `db:push` run against it would come up without the constraint and the bug
    // would silently return. It is therefore also asserted on every boot by
    // database/invariants.ts — keep REQUIRED_UNIQUE_INDEXES there in sync with
    // the uniqueIndex declarations here.
    uniqueIndex("answers_attempt_question_uq").on(t.attemptId, t.questionId),
  ],
);

export const integrityEvents = sqliteTable(
  "integrity_events",
  {
    id: text("id").primaryKey(),
    attemptId: text("attempt_id").notNull(),
    type: text("type").notNull(), // gaze | phone | multi_face | no_face | tab_switch | fullscreen_exit | paste
    detail: text("detail"),
    photoUrl: text("photo_url"), // webcam snapshot captured at the moment of the event
    at: integer("at", { mode: "timestamp_ms" }).notNull().$defaultFn(now),
  },
  (t) => [
    index("integrity_attempt_idx").on(t.attemptId),
    // Violation counts aggregate per attempt with `type NOT IN (...)`, and the
    // dedupe read on every event flush is a per-attempt range over `at`. Both were
    // scanning every row of an attempt (a 90-minute exam leaves hundreds each, and
    // 1000 students leave hundreds of thousands in the table). Keep these in sync
    // with REQUIRED_PERF_INDEXES in database/invariants.ts — nothing in the deploy
    // path runs a migration, so the boot check is what actually creates them.
    index("integrity_attempt_type_idx").on(t.attemptId, t.type),
    index("integrity_attempt_at_idx").on(t.attemptId, t.at),
  ],
);

/**
 * Durable work queue for background AI grading.
 *
 * WHY THIS TABLE EXISTS
 * ---------------------
 * Grading used to be scheduled entirely in memory: a `Set` of in-flight attempts,
 * a `Map` of retry counts and `setTimeout` backoff. Three things went wrong with
 * that:
 *
 *  1. A deploy mid-batch dropped the schedule. The 60s recovery sweep found the
 *     work again, but `retryCounts` reset to 0 on every restart — so an answer the
 *     AI can never grade was retried forever, and we paid the provider every time.
 *  2. It cannot survive more than one process. The concurrency semaphore and the
 *     in-flight set are per process, so with 2-3 replicas every replica's sweep
 *     picks up the same `submitted` attempts: the same attempt graded 2-3x
 *     concurrently, 2-3x the AI bill, concurrent writes to the same answer rows.
 *     That is what blocks horizontal scaling.
 *  3. Failure was invisible. After the retry cap the ungraded answers were written
 *     `score: 0` with a note and the attempt flipped to `graded`; the only trace
 *     was a `console.error` nobody reads.
 *
 * A row per attempt fixes all three: the schedule survives restarts, replicas
 * claim work atomically instead of racing on it (see claimGradeJobs in
 * lib/grade-jobs.ts), and a terminal failure is a queryable row.
 *
 * As with every other table here, `schema.ts` declaring it does NOT create it on
 * production — there is no migrate step in the deploy path. database/invariants.ts
 * asserts it at boot; keep REQUIRED_TABLES there in sync with this declaration.
 */
export const gradeJobs = sqliteTable(
  "grade_jobs",
  {
    id: text("id").primaryKey(),
    /** One job per attempt, enforced by `grade_jobs_attempt_uq` below. */
    attemptId: text("attempt_id").notNull(),
    examId: text("exam_id").notNull(),
    /** pending | claimed | done | failed */
    status: text("status").notNull().default("pending"),
    /** Consecutive failed grading passes. Persisted, so a restart cannot reset it. */
    tries: integer("tries").notNull().default(0),
    /** Earliest time a worker may claim this job — this is the backoff. */
    nextRunAt: integer("next_run_at", { mode: "timestamp_ms" }).notNull().$defaultFn(now),
    /** When the current claim was taken. Drives lease expiry for a crashed worker. */
    claimedAt: integer("claimed_at", { mode: "timestamp_ms" }),
    /** Which process holds the claim. Diagnostic only — the claim itself is atomic. */
    claimedBy: text("claimed_by"),
    /** Last provider/DB error, kept on terminal failures so an admin can see why. */
    lastError: text("last_error"),
    createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(now),
    updatedAt: integer("updated_at", { mode: "timestamp_ms" }).notNull().$defaultFn(now),
  },
  (t) => [
    // The upsert on submit targets this: a re-submit (reopen) must converge on the
    // SAME job row instead of queueing the attempt twice.
    uniqueIndex("grade_jobs_attempt_uq").on(t.attemptId),
    // The claim query is `WHERE status = ? AND next_run_at <= ? ORDER BY next_run_at
    // LIMIT n`. Without this index that is a full scan of the queue on every tick.
    index("grade_jobs_status_next_idx").on(t.status, t.nextRunAt),
  ],
);

/** Platform-global settings: API keys + usage limits (single row, id = "global"). */
export const settings = sqliteTable("settings", {
  id: text("id").primaryKey().default("global"),
  judge0Key: text("judge0_key"),
  aiProvider: text("ai_provider").notNull().default("anthropic"), // anthropic | google | openai
  claudeKey: text("claude_key"),
  geminiKey: text("gemini_key"),
  openaiKey: text("openai_key"),
  judge0Limit: integer("judge0_limit").notNull().default(1000),
  judge0Used: integer("judge0_used").notNull().default(0),
  aiLimit: integer("ai_limit").notNull().default(1000),
  aiUsed: integer("ai_used").notNull().default(0),
  // Global proctoring rules enforced by the desktop student client. See ProctorConfig.
  proctoring: text("proctoring", { mode: "json" }).$type<ProctorConfig>(),
  // ---- Platform-wide default capacity quotas (see lib/tenant-quota.ts) ----
  // The value a tenant inherits when it has no override of its own. NULL =
  // unlimited, which is the shipped default: until somebody types a number here
  // the quota system issues no queries and changes no decisions.
  maxConcurrentAttempts: integer("max_concurrent_attempts"),
  maxEvidencePerAttempt: integer("max_evidence_per_attempt"),
  updatedAt: integer("updated_at", { mode: "timestamp_ms" }).notNull().$defaultFn(now),
});

/** Global proctoring configuration enforced by the desktop student client. */
export type ProctorConfig = {
  requireWebcam: boolean;          // block exam start until webcam is active
  requireInternet: boolean;        // block exam start until internet is present (after download)
  blockOnCameraLoss: boolean;      // lock the exam if the camera is closed/disabled mid-exam
  cameraLossLockSeconds: number;   // how long to lock after camera loss
  fullscreenRequired: boolean;     // enforce fullscreen lockdown
  blockCopyPaste: boolean;         // disable copy/paste/cut + right-click
  flagTabSwitch: boolean;          // record tab/window switches
  maxTabSwitches: number;          // auto-submit after this many switches (0 = never)
  webcamSnapshots: boolean;        // periodically capture webcam snapshots
  snapshotIntervalSec: number;     // snapshot cadence
  detectCameraBlock: boolean;      // flag a camera that is on but physically covered/blacked out
  requireSingleScreen: boolean;    // block exam if more than one display is connected
  blockScreenshots: boolean;       // trap PrintScreen / Win+Shift+S screenshot shortcuts
  autoSubmitOnTimeout: boolean;    // force-submit the moment the exam timer reaches 0
};

export const DEFAULT_PROCTORING: ProctorConfig = {
  requireWebcam: true,
  requireInternet: true,
  blockOnCameraLoss: true,
  cameraLossLockSeconds: 120,
  fullscreenRequired: true,
  blockCopyPaste: true,
  flagTabSwitch: true,
  maxTabSwitches: 0,
  webcamSnapshots: false,
  snapshotIntervalSec: 27,
  detectCameraBlock: true,
  requireSingleScreen: true,
  blockScreenshots: true,
  autoSubmitOnTimeout: true,
};

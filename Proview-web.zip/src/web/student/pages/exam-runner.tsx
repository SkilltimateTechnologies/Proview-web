import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useLocation, useParams } from "wouter";
import { api, type Bundle, type BundleQuestion, type ProctorConfig, DEFAULT_PROCTORING } from "../lib/api";
import { useSession } from "../lib/session";
import { requestFullscreen, exitFullscreen, startWebcam, getDisplayCount, startProctoring, captureFrame, isCameraActive, createObstructionDetector, isFrameClear, watchCameraPermission, type FrameMetrics, type ProctorEvent, type WebcamHandle } from "../lib/proctor";
import { OBSTRUCTION_LOCK_MS, startLock, isLocked, lockRemainingMs, nextLockState, formatLockClock, type ObstructionLock } from "../lib/obstruction-lock";
import { classifyCameraError, cameraLostFailure, escalateFailure, type CameraFailure } from "../lib/camera-failure";
import { freshEpisode, onLoss, onCameraSeen } from "../lib/camera-episode";
import { Icon, NetBadge, useOnline } from "../components/ui";

type Phase = "brief" | "preflight" | "resume" | "running" | "validating" | "done";

type Alert = { id: number; text: string; tone: "danger" | "warn" };

// In-memory running session (live web exam — nothing cached to disk).
type RunSession = {
  attemptId: string;
  endAt: number; // absolute ms deadline (server-anchored)
  answers: Record<string, unknown>;
  flags: Record<string, boolean>;
  integrityEvents: ProctorEvent[];
};

function fmtClock(ms: number): string {
  const t = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(t / 3600);
  const m = Math.floor((t % 3600) / 60);
  const s = t % 60;
  const pad = (n: number) => String(n).padStart(2, "0");
  return h > 0 ? `${pad(h)}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
}

// localStorage bridge so an in-progress exam survives a forced logout/relogin
// (used when the internet drops mid-exam and we bounce the student to login).
const ACTIVE_EXAM_KEY = "examly:activeExam";
// How often we MEASURE the picture for a covered lens.
//
// Deliberately decoupled from the snapshot upload cadence (snapshotIntervalSec,
// ~27s). Analysis is a local canvas read that never touches the server, so it can
// run often and cheaply; uploading at the same rate would take a 150-candidate
// hall from ~333 to ~900 uploads a minute and grow both R2 and the reviewer's ZIP
// about threefold. Two cadences, one camera: analyzeOnly() samples, the upload
// loop keeps owning the evidence trail.
//
// At 10s and the detector's 3 consecutive bad frames, a covered lens is caught in
// ~30s instead of the ~54-81s the old 27s feed took.
const OBSTRUCTION_SAMPLE_MS = 10_000;
/** Timer-zero auto-submits are spread over this window; see doSubmit. */
const AUTO_SUBMIT_SPREAD_MS = 15_000;
// We persist attemptId + the server-anchored absolute endAt alongside answers so
// that a REFRESH WHILE OFFLINE can rebuild the running session without hitting the
// network. endAt is an absolute wall-clock deadline (not a countdown), so it stays
// honest across a reload; the online heartbeat re-reads the authoritative server
// endAt on reconnect and corrects any drift (admin hold / extra time).
type SavedProgress = { answers: Record<string, unknown>; flags: Record<string, boolean>; cur?: number; attemptId?: string; endAt?: number };
function progressKey(examId: string) { return `examly:progress:${examId}`; }
function saveProgress(examId: string, p: SavedProgress) {
  try {
    // Merge so a partial save (e.g. answers only) never wipes attemptId/endAt.
    const prev = loadProgress(examId) ?? {};
    localStorage.setItem(progressKey(examId), JSON.stringify({ ...prev, ...p }));
  } catch { /* ignore */ }
}
function loadProgress(examId: string): SavedProgress | null {
  try {
    const raw = localStorage.getItem(progressKey(examId));
    return raw ? (JSON.parse(raw) as SavedProgress) : null;
  } catch { return null; }
}
function clearProgress(examId: string) {
  try { localStorage.removeItem(progressKey(examId)); localStorage.removeItem(ACTIVE_EXAM_KEY); localStorage.removeItem(bundleKey(examId)); } catch { /* ignore */ }
}

// Cache the exam bundle locally so a mid-exam refresh works even with no internet
// (the bundle is otherwise fetched fresh from the server on every mount).
function bundleKey(examId: string) { return `examly:bundle:${examId}`; }
function cacheBundle(examId: string, b: Bundle) {
  try { localStorage.setItem(bundleKey(examId), JSON.stringify(b)); } catch { /* ignore */ }
}
function loadCachedBundle(examId: string): Bundle | null {
  try {
    const raw = localStorage.getItem(bundleKey(examId));
    return raw ? (JSON.parse(raw) as Bundle) : null;
  } catch { return null; }
}

/** Why a timed capture produced no uploadable frame. `no_frame`/`capture_error`
 *  mean the camera is not delivering pixels to the page; `upload_failed` means it
 *  is, but the evidence never reached storage. `snapshots_off`/`no_attempt` are not
 *  faults at all, and `offline` is the network — none of those get recorded. */
type FrameFailure = "no_attempt" | "snapshots_off" | "no_frame" | "offline" | "upload_failed" | "capture_error";
type GrabResult = { key: string | null; metrics: FrameMetrics | null; failure: FrameFailure | null };
/** The subset worth a row on the integrity timeline: evidence was expected and did
 *  not arrive. Excludes `offline` — the periodic loop already skips while offline,
 *  and a dropped uplink is not a camera fault. */
const CAMERA_FAILURES = new Set<FrameFailure>(["no_frame", "capture_error", "upload_failed"]);

export function ExamRunner() {
  const { examId } = useParams();
  const [, navigate] = useLocation();
  const { student, logout } = useSession();
  const online = useOnline();

  const [phase, setPhase] = useState<Phase>("brief");
  const [bundle, setBundle] = useState<Bundle | null>(null);
  const [err, setErr] = useState("");
  const [session, setSession] = useState<RunSession | null>(null);
  const [cur, setCur] = useState(0);
  const [now, setNow] = useState(Date.now());
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<{ answered: number; skipped: number; events: number; attemptId: string; score: number | null; gradeAt: number | null } | null>(null);
  // Grading poll: after submit, AI grades subjective/coding in the background.
  // We poll the attempt status until it flips to "graded", then reveal the real
  // final score (the score returned inline at submit is objective-only/partial).
  const [gradeDone, setGradeDone] = useState(false);

  const sessionRef = useRef<RunSession | null>(null);
  sessionRef.current = session;
  const submittedRef = useRef(false);
  // Wall-clock ms when the exam last (re)entered the running phase. Used to
  // suppress an instant auto-submit right after a resume/reopen: if a session
  // is rebuilt with a stale/zero deadline, we must NOT silently resubmit within
  // the first few seconds — that was the submit↔reopen loop.
  const runningSinceRef = useRef(0);
  const curRef = useRef(0);
  curRef.current = cur;
  // Guards the run-once resume-on-mount probe.
  const resumeCheckedRef = useRef(false);

  // Proctoring config comes from the exam bundle (admin-configured); fall back to defaults.
  const proctoring: ProctorConfig = bundle?.proctoring ? { ...DEFAULT_PROCTORING, ...bundle.proctoring } : DEFAULT_PROCTORING;
  const proctoringRef = useRef(proctoring);
  proctoringRef.current = proctoring;

  // Scheme token of the paper currently on screen. Options are shuffled per student,
  // so every index this client sends or receives is a DISPLAY index and the server
  // needs this token to map it back. Kept in a ref because the sync/heartbeat/poll
  // callbacks are memoised with empty dep arrays and would otherwise capture a stale
  // bundle. undefined when the cached bundle predates shuffling — the server then
  // treats the indices as original and leaves them alone.
  const optionOrderRef = useRef<string | undefined>(undefined);
  optionOrderRef.current = bundle?.optionOrder;

  // Offline-first: when the internet drops we KEEP the exam running (answers are
  // saved locally and sync on reconnect). We only show a single toast on drop and
  // flip the network badge — no freeze, no logout. Time credit for a real outage
  // comes only from an admin GLOBAL hold, never from a single student's drop.
  const notifiedOfflineRef = useRef(false);
  // Real-time answer sync: `dirtyRef` holds question ids whose answers changed
  // but haven't reached the server yet. We flush on navigation + a 2s typing
  // debounce + heartbeat + reconnect. A failed flush leaves ids dirty to retry.
  const dirtyRef = useRef<Set<string>>(new Set());
  const syncTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const syncingRef = useRef(false);
  // Admin global hold: when the whole exam is held (venue outage) the heartbeat
  // reports held=true and we freeze behind an overlay until the admin resumes.
  const [held, setHeld] = useState(false);

  // Alerts (violation banners)
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const alertIdRef = useRef(0);
  const pushAlert = useCallback((text: string, tone: "danger" | "warn" = "danger") => {
    const idv = ++alertIdRef.current;
    setAlerts((a) => [...a, { id: idv, text, tone }]);
    setTimeout(() => setAlerts((a) => a.filter((x) => x.id !== idv)), 5000);
  }, []);

  // Webcam
  const webcamRef = useRef<WebcamHandle | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [camReady, setCamReady] = useState(false);
  const [camError, setCamError] = useState("");
  const [locked, setLocked] = useState(false);
  const [lockLeft, setLockLeft] = useState(0);
  const lockTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  // WHY the camera is unavailable, not just that it is. Drives the lock overlay's
  // instructions: inside SEB a blocked permission and an unplugged webcam need
  // completely different remedies, and the generic "allow camera access" text was
  // actionable for neither. Null while the camera is healthy.
  const [camFail, setCamFail] = useState<CameraFailure | null>(null);
  // Set once the exam has been stopped specifically because access is DENIED
  // rather than the device having gone away. `getUserMedia` rejects instantly and
  // silently in that state, so the retry button cannot help and the UI must say so.
  const camDeniedRef = useRef(false);
  // The camera is working again but the lock has NOT lifted yet, because the
  // penalty countdown is still running. Without this the overlay silently fell
  // back to "Your camera was turned off. The exam is paused until it is back."
  // while the camera was demonstrably back — telling a student to fix something
  // they have already fixed, next to a footer promising the exam resumes as soon
  // as they do. Say what is actually being waited on.
  const [camBack, setCamBack] = useState(false);

  // ---- Blocked-lens detection ----
  // A camera with tape/paper/a hand over it reports a perfectly healthy track:
  // `live`, unmuted, delivering frames. No track-level signal can catch it, so we
  // measure the pixels of the frame we already captured (see analyzeFrame). Like
  // the multi-monitor check this FLAGS and warns — it never locks the exam, because
  // an unlit room is a legitimate false positive.
  const obstructionRef = useRef(createObstructionDetector());
  // One camera failure = one violation. See camera-episode.ts: a webcam that can
  // be opened but dies immediately used to write a fresh row every few seconds,
  // because every detector — and every re-acquired handle from the 2.5s recovery
  // poll — carries its own "report once" latch.
  const camEpisodeRef = useRef(freshEpisode());
  const [camBlocked, setCamBlocked] = useState<string | null>(null);
  // A covered lens LOCKS the exam for a strict two minutes (see obstruction-lock.ts
  // for why there is no dismiss and why uncovering early does not release). Held in
  // a ref as well as state because the expiry ticker reads it from inside an
  // interval closure that must not be re-created every second.
  const [obsLock, setObsLock] = useState<ObstructionLock | null>(null);
  const obsLockRef = useRef<ObstructionLock | null>(null);
  obsLockRef.current = obsLock;
  // True only for the few milliseconds it takes to read a fresh frame at expiry.
  // Without it the overlay would blink away mid-decision and then slam back for a
  // candidate who is still covered — which reads as a bug and invites a retry.
  const [lockDeciding, setLockDeciding] = useState(false);
  // Re-renders the countdown once a second. Scoped to the locked period so the
  // rest of the exam is not re-rendered every second for nothing.
  const [lockTick, setLockTick] = useState(0);
  // Preflight frames are captured before the attempt exists (no attemptId yet, so
  // nothing can be signed or uploaded). Buffer the JPEGs here and flush them the
  // moment /start returns an attemptId.
  const preflightFramesRef = useRef<{ blob: Blob; at: number }[]>([]);

  // Multi-monitor state. Extra displays are RECORDED as a violation, never a
  // hard block — home candidates legitimately use a laptop + external monitor,
  // and locking them out of a live exam is worse than flagging it for review.
  const [displayCount, setDisplayCount] = useState(1);
  const displayCountRef = useRef(1);
  displayCountRef.current = displayCount;

  // Fullscreen escape: students must not be able to leave the exam window, so an
  // exit is re-enforced immediately. If the browser refuses to re-enter without a
  // fresh user gesture we show a blocking overlay with a single button.
  const [fsExited, setFsExited] = useState(false);

  // ---- Proctoring evidence pipeline ----
  // Every violation is (a) kept on the session for the submit backstop and
  // (b) pushed to the server immediately, so evidence survives a crash, a
  // force-quit, or an attempt that is never submitted.
  const pendingEventsRef = useRef<ProctorEvent[]>([]);
  const eventSyncingRef = useRef(false);
  const lastEventAtRef = useRef<Record<string, number>>({});
  const lockLeftRef = useRef(0);
  lockLeftRef.current = lockLeft;
  const lockedRef = useRef(false);
  lockedRef.current = locked;

  const attachVideo = useCallback((handle: WebcamHandle) => {
    if (videoRef.current) {
      videoRef.current.srcObject = handle.stream;
      void videoRef.current.play().catch(() => {});
    }
  }, []);

  // Push queued violations to the server. Called the moment an event is recorded,
  // on every heartbeat, on reconnect, and before submit. A failed flush re-queues
  // the batch so nothing is silently dropped; events also ride along in the submit
  // payload as a backstop (the server dedupes on type + timestamp).
  const flushEvents = useCallback(() => {
    const s = sessionRef.current;
    if (!s?.attemptId || eventSyncingRef.current || !navigator.onLine) return;
    if (pendingEventsRef.current.length === 0) return;
    const batch = pendingEventsRef.current.slice(0, 100);
    pendingEventsRef.current = pendingEventsRef.current.slice(batch.length);
    eventSyncingRef.current = true;
    void api.flushEvents(s.attemptId, batch)
      .catch(() => { pendingEventsRef.current = [...batch, ...pendingEventsRef.current]; })
      .finally(() => { eventSyncingRef.current = false; });
  }, []);
  const flushEventsRef = useRef(flushEvents);
  flushEventsRef.current = flushEvents;

  // Capture a webcam frame for the violation that just happened and upload it
  // straight to object storage. Returns the storage key, or null when snapshots
  // are off / the camera can't produce a frame / the upload fails. Used both for
  // violation evidence and for the timed frames below.
  // Sign + PUT one JPEG straight to object storage. Returns the storage key, or
  // null on any failure — the API only signs URLs, images never pass through it.
  const uploadFrame = useCallback(async (attemptId: string, blob: Blob): Promise<string | null> => {
    try {
      const pre = await api.snapshotUrl(attemptId);
      if (!pre.ok || !pre.url || !pre.key) return null;
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), 8000);
      try {
        const res = await fetch(pre.url, { method: "PUT", body: blob, headers: { "Content-Type": "image/jpeg" }, signal: ctrl.signal });
        return res.ok ? pre.key : null;
      } finally { clearTimeout(t); }
    } catch {
      return null;
    }
  }, []);

  // Capture a frame AND its luminance metrics in one pass (same canvas, decoded
  // once), then upload it. Metrics come back even when the upload fails, so
  // blocked-lens detection keeps working on a flaky uplink.
  const grabFrame = useCallback(async (): Promise<GrabResult> => {
    const s = sessionRef.current;
    if (!s?.attemptId) return { key: null, metrics: null, failure: "no_attempt" };
    if (!proctoringRef.current.webcamSnapshots) return { key: null, metrics: null, failure: "snapshots_off" };
    try {
      const { blob, metrics } = await captureFrame(webcamRef.current);
      // A live-but-covered lens still produces a blob (and metrics) — the obstruction
      // detector depends on that. No blob at all means the video element never
      // decoded a frame: the camera is not actually delivering pixels to this page.
      if (!blob) return { key: null, metrics, failure: "no_frame" };
      if (!navigator.onLine) return { key: null, metrics, failure: "offline" };
      const key = await uploadFrame(s.attemptId, blob);
      return { key, metrics, failure: key ? null : "upload_failed" };
    } catch {
      return { key: null, metrics: null, failure: "capture_error" };
    }
  }, [uploadFrame]);

  const grabSnapshotKey = useCallback(async (): Promise<string | null> => {
    return (await grabFrame()).key;
  }, [grabFrame]);

  // Record one violation: keep it on the session (submit backstop + live count),
  // queue it for the server, and optionally attach a webcam snapshot. `minGapMs`
  // throttles chatty event types (blocked keystrokes, focus flapping) so a student
  // hammering Ctrl+C can't generate thousands of rows.
  const recordEvent = useCallback((type: string, detail?: string, opts?: { snapshot?: boolean; minGapMs?: number }) => {
    if (submittedRef.current) return;
    const at = Date.now();
    const gap = opts?.minGapMs ?? 0;
    if (gap > 0 && at - (lastEventAtRef.current[type] ?? 0) < gap) return;
    lastEventAtRef.current[type] = at;
    const ev: ProctorEvent = { type, detail, at };
    setSession((prev) => (prev ? { ...prev, integrityEvents: [...prev.integrityEvents, ev] } : prev));
    if (!opts?.snapshot) {
      pendingEventsRef.current.push(ev);
      flushEventsRef.current();
      return;
    }
    // Snapshot first so the image travels with the event (one server round trip).
    void (async () => {
      const photoKey = await grabSnapshotKey();
      pendingEventsRef.current.push({ ...ev, photoKey });
      if (photoKey) {
        setSession((prev) => (prev
          ? { ...prev, integrityEvents: prev.integrityEvents.map((e) => (e.at === at && e.type === type ? { ...e, photoKey } : e)) }
          : prev));
      }
      flushEventsRef.current();
    })();
  }, [grabSnapshotKey]);
  const recordEventRef = useRef(recordEvent);
  recordEventRef.current = recordEvent;

  // Capture one TIMED webcam frame and queue it as evidence.
  //
  // Deliberately does NOT touch session state: violation events ride along in the
  // submit payload as a backstop, but timed frames would bloat that payload for no
  // benefit — they are already durable on the server the moment they flush. Typed
  // `periodic_snapshot` so it never counts as a violation in the admin UI.
  const capturePeriodic = useCallback(async () => {
    if (submittedRef.current) return;
    const s = sessionRef.current;
    if (!s?.attemptId) return;
    const { key: photoKey, metrics, failure } = await grabFrame();
    if (photoKey) {
      pendingEventsRef.current.push({ type: "periodic_snapshot", detail: "Timed webcam frame", at: Date.now(), photoKey });
      flushEventsRef.current();
    } else if (failure && CAMERA_FAILURES.has(failure)) {
      // WHY THIS EXISTS. This branch used to be absent: when no frame came back we
      // pushed nothing, so "camera dead for the whole exam" and "camera perfectly
      // fine" were byte-identical in the database. One student sat four exams over
      // two months with a webcam that never decoded a single frame, and the platform
      // recorded nothing and alerted nobody — the empty gallery on his review page
      // was the only evidence, and only because someone happened to open it.
      //
      // Throttled to one row every 5 minutes (the `focus_loss` idiom), so a dead
      // camera costs ~18 rows across a 90-minute exam instead of one per 27s tick.
      // Non-scoring by design: it is a device fault, not misconduct — the server
      // keeps `snapshot_failed` in NON_VIOLATION_TYPES so a student with a broken
      // webcam is never marked a cheat for it.
      recordEventRef.current("snapshot_failed", `No webcam frame captured (${failure})`, { minGapMs: 300_000 });
    }
    // NOTE: the blocked-lens detector is deliberately NOT fed from here any more.
    // It is owned by the 10s analysis loop below, and two producers pushing into
    // one detector would make its "3 consecutive bad frames" rule meaningless —
    // frames would arrive from two unrelated clocks and a single covered moment
    // could satisfy the run. This loop now only uploads evidence.
    void metrics;
  }, [grabFrame]);
  const capturePeriodicRef = useRef(capturePeriodic);
  capturePeriodicRef.current = capturePeriodic;

  // ---- Analysis loop: is anything over the lens? ----
  //
  // Captures LOCALLY and never uploads. The camera is healthy in this scenario —
  // the track is live and delivering frames — so nothing at the track level can
  // see the tape/hand/paper; only the pixels can (see analyzeFrame). Runs on its
  // own 10s clock, separate from the 27s evidence upload, and is the SOLE producer
  // feeding obstructionRef so its "3 consecutive bad frames" rule stays honest.
  const analyzeOnly = useCallback(async (): Promise<FrameMetrics | null> => {
    try { return (await captureFrame(webcamRef.current)).metrics; } catch { return null; }
  }, []);

  useEffect(() => {
    if (phase !== "running") return;
    if (!proctoringRef.current.detectCameraBlock) return;
    let stop = false;
    const tick = async () => {
      if (stop || submittedRef.current) return;
      const metrics = await analyzeOnly();
      if (stop) return;
      const { verdict, changed } = obstructionRef.current.push(metrics);
      // Only the TRANSITION is recorded (covered -> ok -> covered), so a lens taped
      // for an hour produces one event, not one every ten seconds.
      if (!changed) return;
      if (verdict.state === "ok") {
        // Recovery is logged so a reviewer can see exactly how long the view was
        // covered. It is NOT misconduct, and it deliberately does NOT end a running
        // lock — the period is the penalty and is always served in full.
        setCamBlocked(null);
        pendingEventsRef.current.push({ type: "camera_restored", detail: "Camera view is clear again", at: Date.now() });
        flushEventsRef.current();
        return;
      }
      setCamBlocked(verdict.reason);
      // Evidence rides with the event (one server round trip); the frame is only
      // uploaded when webcam snapshots are enabled, exactly as before.
      recordEventRef.current("camera_obstructed", verdict.reason, { snapshot: true });
      // A FROZEN feed is flagged and warned about but never locks: the honest
      // failure mode (a driver repeating a frame) would otherwise re-lock a
      // candidate forever, and unlike a covered lens there is nothing they can do
      // about it from their chair. A COVERED lens locks.
      if (verdict.state !== "covered") {
        pushAlert("Your camera feed has stopped changing — this has been recorded for review.", "warn");
        return;
      }
      setObsLock((prev) => (isLocked(prev, Date.now()) ? prev : startLock(Date.now(), verdict.reason)));
    };
    const iv = setInterval(() => { void tick(); }, OBSTRUCTION_SAMPLE_MS);
    void tick();
    return () => { stop = true; clearInterval(iv); };
  }, [phase, analyzeOnly, pushAlert]);

  // ---- The lock itself ----
  // Ticks the countdown once a second and, at expiry, decides between releasing the
  // candidate and serving another period. The decision needs the FRESHEST possible
  // reading — a stale one either strands an honest candidate for two more minutes
  // or hands a cheater a clear exam with the lens still taped — so it takes a new
  // frame at that moment rather than trusting the last 10s sample.
  useEffect(() => {
    if (!obsLock) return;
    let stop = false;
    let deciding = false;
    const iv = setInterval(() => {
      setLockTick((n) => n + 1);
      const cur = obsLockRef.current;
      if (!cur || deciding || stop) return;
      if (Date.now() < cur.until) return;
      deciding = true;
      setLockDeciding(true);
      void (async () => {
        const metrics = await analyzeOnly();
        // A frame we could not capture at all is a DEAD camera, not a covered one —
        // that is the camera-loss path's job (blockOnCameraLoss). Re-locking on it
        // here would punish the same fault twice, so it releases.
        const stillCovered = metrics ? !isFrameClear(metrics) : false;
        const { lock: next, relocked } = nextLockState(obsLockRef.current, Date.now(), stillCovered);
        obsLockRef.current = next;
        setObsLock(next);
        setLockDeciding(false);
        deciding = false;
        if (relocked) {
          recordEventRef.current("camera_obstructed", `Camera still covered when the lock expired — locked for another ${Math.round(OBSTRUCTION_LOCK_MS / 1000)}s`, { snapshot: true });
        }
      })();
    }, 1000);
    return () => { stop = true; clearInterval(iv); };
  }, [obsLock, analyzeOnly]);

  // Read so the countdown recomputes every second while the lock is up.
  void lockTick;
  const camLockActive = isLocked(obsLock, Date.now()) || lockDeciding;
  const camLockLeft = formatLockClock(lockRemainingMs(obsLock, Date.now()));

  // ---- Load bundle for the brief (title/meta + question data) ----
  // Offline-first: hydrate immediately from the local cache (so a refresh works
  // with no internet), then refresh from the server in the background and re-cache.
  useEffect(() => {
    if (!examId) return;
    const cached = loadCachedBundle(examId);
    if (cached) setBundle(cached);
    api.bundle(examId).then((b) => {
      // NEVER change the option order of a paper that is already being sat. Answers
      // are held as indices into the options as displayed, so swapping the order
      // underneath a student would silently repoint every answer they have already
      // given at different text. This is a real case exactly once: a student who
      // started before the shuffling deploy (cached bundle, no scheme token) and
      // refreshes afterwards. Keep their order for the rest of the attempt — their
      // client also sends no token, so the server stores their indices as original
      // and the two halves stay consistent.
      const inFlight = loadProgress(examId);
      if (cached && inFlight?.attemptId && (cached.optionOrder ?? null) !== (b.optionOrder ?? null)) {
        return;
      }
      setBundle(b);
      cacheBundle(examId, b);
    }).catch(() => {
      // Only surface the error if we have nothing cached to fall back to.
      if (!loadCachedBundle(examId)) setErr("Couldn't load the exam. Check your connection and try again.");
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [examId]);

  // ---- Camera-loss lock ----
  const engageLock = useCallback((reason: string, failure?: CameraFailure) => {
    const cfg = proctoringRef.current;
    if (submittedRef.current) return;
    setCamReady(false);
    // Never let a second, vaguer detector talk over a known denial — revoking
    // access also ends the track, so the generic "camera turned off" arrives a
    // beat after the permission watcher has already named the real cause.
    const fail = escalateFailure(camDeniedRef.current, failure ?? cameraLostFailure(reason));
    setCamFail(fail);
    // A denied permission is a separate offence from a camera that died: it can
    // only happen by choice, and it is the one state the retry button cannot fix.
    // Type it distinctly so the admin timeline can tell the two apart, and latch
    // it so the overlay keeps showing the right instructions while locked.
    const denied = fail.code === "permission_denied";
    if (denied) camDeniedRef.current = true;
    setCamBack(false);
    // Persist the violation immediately (with a snapshot attempt) — the overlay
    // tells the student "this has been recorded", so it must actually be recorded.
    //
    // Recorded BEFORE the freeze gate on purpose. "Lock exam if camera is closed"
    // is a decision about interrupting the candidate, not about what the
    // invigilator gets to see: an exam with that toggle off used to swallow a
    // deliberate camera block entirely, leaving no trace in the timeline or the
    // report. Evidence is always kept; only the freeze is optional.
    //
    // ONE row per episode, not one per detection. Three separate detectors watch
    // this (the per-handle track poll, the permission watcher, the 2.5s recovery
    // poll that re-opens the device with a brand-new latch), so a single failing
    // webcam used to bill the same student over and over — 43 rows in one measured
    // exam, enough to outrank the only real copy/paste case in the hall. The
    // episode state machine decides what is new; minGapMs stays as a second belt.
    const loss = onLoss(camEpisodeRef.current, denied ? "camera_blocked" : "camera_lost");
    camEpisodeRef.current = loss.episode;
    if (loss.record) {
      recordEventRef.current(denied ? "camera_blocked" : "camera_lost", fail.eventDetail, { snapshot: true, minGapMs: 3000 });
    }
    if (!cfg.blockOnCameraLoss) {
      // Warn and carry on. The status pill already reads "Camera off".
      pushAlert(denied ? "Camera access is blocked. This has been recorded for review." : `Camera turned off. ${reason}`, "danger");
      return;
    }
    pushAlert(denied ? "Camera access blocked — exam paused. Unblock your camera to continue." : `Camera turned off — exam locked. ${reason}`, "danger");
    setLocked(true);
    // Do NOT re-arm the countdown if we are already locked. Two independent
    // detectors now notice a dead camera — the track-level poll in startWebcam and
    // the permission watcher — and a single incident routinely trips both a few
    // seconds apart. Restarting the clock on the second one would silently extend
    // the penalty for a student who did nothing new, and a student whose webcam
    // reports itself as ended repeatedly could never reach zero at all.
    if (lockedRef.current) return;
    setLockLeft(cfg.cameraLossLockSeconds);
    if (lockTimerRef.current) clearInterval(lockTimerRef.current);
    lockTimerRef.current = setInterval(() => {
      setLockLeft((v) => {
        if (v <= 1) {
          if (lockTimerRef.current) clearInterval(lockTimerRef.current);
          return 0;
        }
        return v - 1;
      });
    }, 1000);
  }, [pushAlert]);

  const enableCamera = useCallback(async () => {
    setCamError("");
    try {
      const handle = await startWebcam((reason) => engageLock(reason));
      webcamRef.current?.stop();
      webcamRef.current = handle;
      setTimeout(() => attachVideo(handle), 50);
      setCamReady(true);
      setCamFail(null);
      camDeniedRef.current = false;
    } catch (e) {
      // Classify instead of printing one catch-all line: at the preflight gate this
      // text is the only thing standing between a candidate with a closed privacy
      // shutter and a raised hand they never needed.
      const fail = classifyCameraError(e);
      setCamFail(fail);
      setCamError(`${fail.title}. ${fail.steps[0]}`);
      setCamReady(false);
    }
  }, [engageLock, attachVideo]);

  const goPreflight = useCallback(() => {
    setErr("");
    setPhase("preflight");
    if (proctoringRef.current.requireWebcam) void enableCamera();
    if (proctoringRef.current.requireSingleScreen) void getDisplayCount().then(setDisplayCount).catch(() => {});
  }, [enableCamera]);

  // Poll the monitor count while on the preflight gate.
  useEffect(() => {
    if (phase !== "preflight" || !proctoringRef.current.requireSingleScreen) return;
    const t = setInterval(() => { void getDisplayCount().then(setDisplayCount).catch(() => {}); }, 1500);
    return () => clearInterval(t);
  }, [phase]);

  // ---- Camera-check capture (preflight) ----
  // The camera check is exactly when a candidate would swap in a photo, cover the
  // lens, or seat a stand-in — but until /start runs there is no attemptId, so
  // nothing can be signed or uploaded yet. Capture into memory here and flush the
  // buffer as soon as the attempt exists (see startExam). Capped at MAX_FRAMES so
  // a student who parks on the gate for 20 minutes can't grow the heap.
  useEffect(() => {
    if (phase !== "preflight" || !camReady) return;
    const cfg = proctoringRef.current;
    if (!cfg.webcamSnapshots || !cfg.requireWebcam) return;
    const MAX_FRAMES = 4;
    // Faster confirmation than the in-exam detector: the student is sitting at the
    // gate and can fix a covered lens before the timer ever starts.
    const gate = createObstructionDetector(2, { detectFrozen: false });
    let stopped = false;

    const tick = async () => {
      if (stopped || !isCameraActive(webcamRef.current)) return;
      try {
        const { blob, metrics } = await captureFrame(webcamRef.current);
        if (stopped) return;
        if (blob && preflightFramesRef.current.length < MAX_FRAMES) {
          preflightFramesRef.current.push({ blob, at: Date.now() });
        }
        if (!cfg.detectCameraBlock) return;
        const { verdict, changed } = gate.push(metrics);
        if (changed) setCamBlocked(verdict.state === "ok" ? null : verdict.reason);
      } catch { /* a failed camera-check frame must never block starting */ }
    };

    void tick();
    const t = setInterval(() => { void tick(); }, 6000);
    return () => { stopped = true; clearInterval(t); };
  }, [phase, camReady]);

  const startExam = useCallback(async () => {
    if (!examId || !student || !bundle) return;
    if (proctoringRef.current.requireWebcam && !camReady) { setCamError("Enable your camera to start."); return; }
    if (!online) { setErr("An internet connection is required to start this exam."); return; }
    let startDisplays = 1;
    if (proctoringRef.current.requireSingleScreen) {
      // Never let the display check block the start flow — cap it so a hung
      // permission prompt (seen inside SEB kiosk) can't freeze "Start secure exam".
      // An extra monitor is FLAGGED, not blocked (home candidates commonly use a
      // laptop plus an external display).
      startDisplays = await Promise.race([
        getDisplayCount().catch(() => 1),
        new Promise<number>((r) => setTimeout(() => r(1), 1500)),
      ]);
      setDisplayCount(startDisplays);
    }
    try {
      const start = await api.start(examId, optionOrderRef.current);
      // Restore any answers saved locally (offline-first: survives a crash/reload).
      const saved = loadProgress(examId);
      // Merge server-saved answers UNDER local ones: on a fresh browser (cleared
      // cache / different machine / SEB kiosk that wipes storage) local is empty,
      // so the server copy repopulates the exam instead of showing blank. On the
      // same browser, local is the latest autosave and wins per-question.
      const mergedAnswers = { ...(start.answers ?? {}), ...(saved?.answers ?? {}) };
      // /start returns the server-anchored deadline already folding in any admin
      // hold time + extra minutes, so we use it directly.
      const endAt = new Date(start.endAt).getTime();
      setSession({
        attemptId: start.attemptId,
        endAt,
        answers: mergedAnswers,
        flags: saved?.flags ?? {},
        integrityEvents: [],
      });
      // Persist attemptId + absolute deadline so an offline refresh can resume.
      saveProgress(examId, { attemptId: start.attemptId, endAt, answers: mergedAnswers, flags: saved?.flags ?? {}, cur: curRef.current });
      setHeld(!!start.held);
      enterRunning();
      // Flush the camera-check frames now that an attempt exists to hang them on.
      // Fire-and-forget: the exam must start instantly, never wait on uploads.
      const gateFrames = preflightFramesRef.current.splice(0);
      if (gateFrames.length) {
        void (async () => {
          for (const f of gateFrames) {
            const key = await uploadFrame(start.attemptId, f.blob);
            if (key) pendingEventsRef.current.push({ type: "preflight_snapshot", detail: "Camera check frame", at: f.at, photoKey: key });
          }
          flushEventsRef.current();
        })();
      }
      // Fresh detector state for the exam itself — gate readings must not carry over.
      obstructionRef.current.reset();
      camEpisodeRef.current = freshEpisode();
      setCamBlocked(null);
      // Record the setup we started with, so the report shows the conditions.
      if (startDisplays > 1) {
        recordEventRef.current("multi_monitor", `${startDisplays} displays connected at start`, { snapshot: true });
        pushAlert(`${startDisplays} displays detected — this has been recorded for review.`, "warn");
      }
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Could not start exam");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [examId, student, bundle, camReady, online, pushAlert, uploadFrame]);

  function enterRunning() {
    runningSinceRef.current = Date.now();
    setPhase("running");
    // Mark this exam as the active in-progress attempt so a forced logout
    // (e.g. internet loss) can bounce the student straight back to it on relogin.
    if (examId) { try { localStorage.setItem(ACTIVE_EXAM_KEY, examId); } catch { /* ignore */ } }
    if (proctoringRef.current.fullscreenRequired) void requestFullscreen();
  }

  // ---- Refresh-resume: detect an already-running attempt on mount ----
  // A mid-exam browser refresh must land the student back in the running exam
  // (same question, answers, server-anchored timer) — not on the brief/start
  // page. We probe the READ-ONLY status endpoint (never /start, which would
  // wrongly transition a not_started attempt to in_progress). Runs once, after
  // the bundle loads so the proctoring config is known.
  useEffect(() => {
    if (!examId || !bundle || resumeCheckedRef.current) return;
    resumeCheckedRef.current = true;
    // OFFLINE refresh: the server is unreachable, so rebuild the running session
    // purely from local storage (attemptId + saved absolute endAt + answers). The
    // heartbeat will re-read the authoritative server endAt once we're back online.
    const resumeOffline = () => {
      const saved = loadProgress(examId);
      if (!saved?.attemptId || !saved.endAt) return false;
      setSession({
        attemptId: saved.attemptId,
        endAt: saved.endAt,
        answers: saved.answers ?? {},
        flags: saved.flags ?? {},
        integrityEvents: [],
      });
      if (typeof saved.cur === "number" && Number.isFinite(saved.cur)) setCur(saved.cur);
      const cfg = proctoringRef.current;
      if (cfg.requireWebcam || cfg.fullscreenRequired || cfg.requireSingleScreen) {
        setPhase("resume");
        if (cfg.requireWebcam) void enableCamera();
        if (cfg.requireSingleScreen) void getDisplayCount().then(setDisplayCount).catch(() => {});
      } else {
        enterRunning();
      }
      return true;
    };
    if (!navigator.onLine) { resumeOffline(); return; }
    void (async () => {
      try {
        const st = await api.status(examId, optionOrderRef.current);
        if (st.status === "submitted" || st.status === "graded") {
          // Already finished elsewhere — clear any stale local progress + go home.
          clearProgress(examId);
          return;
        }
        if (st.status !== "in_progress" || !st.endAt || !st.attemptId) return;
        // Rebuild the running session from server (attemptId + deadline) + local
        // progress (answers/flags/current question). Merge server answers UNDER
        // local so a fresh-browser resume repopulates prior work instead of blank.
        const saved = loadProgress(examId);
        const merged = { ...(st.answers ?? {}), ...(saved?.answers ?? {}) };
        const endAt = new Date(st.endAt).getTime();
        setSession({
          attemptId: st.attemptId,
          endAt,
          answers: merged,
          flags: saved?.flags ?? {},
          integrityEvents: [],
        });
        // Refresh the persisted attemptId + deadline from the authoritative server.
        saveProgress(examId, { attemptId: st.attemptId, endAt, answers: merged, flags: saved?.flags ?? {}, cur: saved?.cur });
        if (typeof saved?.cur === "number" && Number.isFinite(saved.cur)) setCur(saved.cur);
        setHeld(!!st.held);
        const cfg = proctoringRef.current;
        // Fullscreen re-entry (and camera) need a user gesture on reload, so if any
        // lockdown gate is on we show a one-click "Resume exam" screen. Otherwise
        // drop straight back into the running exam.
        if (cfg.requireWebcam || cfg.fullscreenRequired || cfg.requireSingleScreen) {
          setPhase("resume");
          if (cfg.requireWebcam) void enableCamera();
          if (cfg.requireSingleScreen) void getDisplayCount().then(setDisplayCount).catch(() => {});
        } else {
          enterRunning();
        }
      } catch {
        // Network died during the probe — try rebuilding from local storage so a
        // refresh mid-outage still resumes; otherwise leave on brief.
        resumeOffline();
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [examId, bundle]);

  // Try to restore the camera while locked, and auto-unlock once the lock time
  // has elapsed AND the camera is back.
  const tryRestoreCamera = useCallback(async () => {
    try {
      const handle = await startWebcam((reason) => engageLock(reason));
      webcamRef.current?.stop();
      webcamRef.current = handle;
      attachVideo(handle);
      setCamReady(true);
      setCamError("");
      setCamFail(null);
      camDeniedRef.current = false;
      // The unlock poll decides when the overlay actually lifts; until it does,
      // the overlay must show the countdown as the reason it is still up.
      setCamBack(true);
      return true;
    } catch (e) {
      // Keep the overlay's instructions in step with the CURRENT cause: a student
      // who reconnects a webcam while permission is still denied moves from
      // "no camera" to "blocked", and must be told the remedy has changed.
      const fail = classifyCameraError(e);
      setCamFail(fail);
      if (fail.code === "permission_denied") camDeniedRef.current = true;
      setCamError(fail.steps[0] ?? fail.message);
      setCamBack(false);
      return false;
    }
  }, [engageLock, attachVideo]);

  // Unlock as soon as BOTH conditions hold: the penalty countdown has elapsed and
  // the camera is live again. This runs on a repeating poll (not once when the
  // countdown hits zero) so a student whose camera comes back later — or who
  // reconnects it with the "Re-enable camera now" button — is never left stranded
  // behind the overlay with a working camera.
  useEffect(() => {
    if (!locked) return;
    let stopped = false;
    const tick = async () => {
      if (stopped || submittedRef.current) return;
      if (lockLeftRef.current > 0) return;
      const ok = isCameraActive(webcamRef.current) || (await tryRestoreCamera());
      if (stopped || !ok) return;
      setLocked(false);
      setCamReady(true);
      setCamError("");
      setCamBack(false);
      // NOTE: the camera episode is deliberately NOT reset here. Reaching this line
      // means the poll got ONE live reading, which a camera that dies a moment after
      // every open supplies on every attempt — resetting here billed a fresh
      // `camera_lost` once per lock period. The episode ends only after the camera
      // has stayed continuously live (camera-episode.ts), which a working camera
      // does within seconds of this point anyway.
      recordEventRef.current("camera_restored", "Camera restored — exam resumed");
      pushAlert("Camera restored — exam resumed. This was recorded.", "warn");
      if (proctoringRef.current.fullscreenRequired) void requestFullscreen();
    };
    void tick();
    const t = setInterval(() => void tick(), 2500);
    return () => { stopped = true; clearInterval(t); };
  }, [locked, tryRestoreCamera, pushAlert]);

  // ---- Camera permission watcher ----
  // Stops the exam the moment access is REVOKED, which the track-level signals in
  // startWebcam cannot be relied on for. Revoking permission does not always end
  // or mute an existing track — in some Chromium versions the old stream keeps
  // delivering frames — so without this a student could block the camera and carry
  // on with the proctor none the wiser until the next frame upload failed.
  //
  // It is also the ONLY thing that notices access being granted again while the
  // exam is locked, so the student is not left behind an overlay after fixing the
  // very thing it asked them to fix.
  useEffect(() => {
    if (phase !== "running" && phase !== "preflight" && phase !== "resume") return;
    if (!proctoringRef.current.requireWebcam) return;
    let stopped = false;
    const off = watchCameraPermission((state) => {
      if (stopped || submittedRef.current) return;
      if (state === "denied") {
        camDeniedRef.current = true;
        const fail = classifyCameraError({ name: "NotAllowedError" });
        setCamReady(false);
        setCamFail(fail);
        // Only the running exam gets locked. At the preflight/resume gates there is
        // nothing to interrupt — the student simply cannot pass the camera check,
        // and the gate already shows the failure text.
        if (phase === "running") engageLock(fail.eventDetail, fail);
      } else if (state === "granted" && camDeniedRef.current) {
        camDeniedRef.current = false;
        // Re-acquire immediately rather than waiting for the 2.5s unlock poll, so
        // the exam comes back the instant the block is lifted.
        void tryRestoreCamera();
      }
    });
    return () => { stopped = true; off(); };
  }, [phase, engageLock, tryRestoreCamera]);

  // ---- Offline-first network handling (no freeze, no logout) ----
  // On the FIRST drop we save progress locally + show ONE toast, then stay quiet.
  // The exam keeps running; answers buffer on this device and sync on reconnect.
  useEffect(() => {
    if (phase !== "running" || submittedRef.current || !examId) return;
    if (!online) {
      if (!notifiedOfflineRef.current) {
        notifiedOfflineRef.current = true;
        const s = sessionRef.current;
        if (s) saveProgress(examId, { answers: s.answers, flags: s.flags, cur: curRef.current });
        try { localStorage.setItem(ACTIVE_EXAM_KEY, examId); } catch { /* ignore */ }
        pushAlert("You're offline — keep going, your answers are saved on this device and will sync when the connection returns.", "warn");
      }
    } else if (notifiedOfflineRef.current) {
      // Reconnected: sync buffered answers quietly (no toast), reset the flag.
      notifiedOfflineRef.current = false;
      const s = sessionRef.current;
      if (s) saveProgress(examId, { answers: s.answers, flags: s.flags, cur: curRef.current });
      // Flush every answer edited during the offline window (all still dirty),
      // plus any violations recorded while the connection was down.
      flushSyncRef.current();
      flushEventsRef.current();
    }
  }, [online, phase, examId, pushAlert]);

  // ---- Heartbeat + admin hold poll ----
  // Every ~15s while running + online: ping the server (drives the Live Monitor
  // online dot) and read back the current hold state + up-to-date deadline. This
  // is how an admin GLOBAL hold / resume / extra-time reaches every student
  // without a reload.
  useEffect(() => {
    if (phase !== "running" || !examId) return;
    let stopped = false;
    const beat = () => {
      if (stopped || submittedRef.current || !navigator.onLine) return;
      // Piggyback a sync on every heartbeat so any answer left dirty (e.g. the
      // student is idle on one question) reaches the server within ~15s, plus a
      // flush of any proctoring evidence still queued.
      flushSyncRef.current();
      flushEventsRef.current();
      void api.heartbeat(examId)
        .then((info) => {
          if (stopped) return;
          setHeld(!!info.held);
          const newEnd = new Date(info.endAt).getTime();
          if (Number.isFinite(newEnd)) {
            setSession((prev) => (prev && newEnd !== prev.endAt ? { ...prev, endAt: newEnd } : prev));
            // Persist the latest server deadline so an offline refresh honours
            // any admin extra-time / hold that landed earlier.
            saveProgress(examId, { endAt: newEnd });
          }
        })
        .catch(() => {});
    };
    beat();
    const t = setInterval(beat, 15_000);
    return () => { stopped = true; clearInterval(t); };
  }, [phase, examId]);

  // ---- Grading poll after submit ----
  // Once the exam is submitted (phase "done"), poll the attempt status until it
  // flips to "graded", then reveal the real final score. The score returned
  // inline at submit is objective-only/partial, so we don't show it.
  useEffect(() => {
    if (phase !== "done" || !result || !examId || gradeDone) return;
    let stop = false;
    let polls = 0;
    // DEFERRED GRADING. When the server holds AI grading until after the exam
    // closes it returns `gradeAt`. Fast-polling for a score that provably cannot
    // arrive for another hour is pure waste — 40 status reads per student, times
    // the whole cohort, exactly the load this deferral exists to remove. So when
    // grading is deferred we slow the poll right down. It is NOT switched off:
    // the same poll is what detects an admin RESET and bounces the student back
    // into the exam, and that has to keep working while they sit on this screen.
    const deferred = !!result.gradeAt && result.gradeAt > Date.now();
    const FIRST_DELAY_MS = deferred ? 60_000 : 1500;
    const INTERVAL_MS = deferred ? 60_000 : 2500;
    // Backstop so idle post-submit clients never poll forever: ~16 min at the
    // fast cadence, ~15 min of reset-detection at the slow one.
    const MAX_POLLS = deferred ? 15 : 40;
    const poll = async () => {
      try {
        const st = await api.status(examId, optionOrderRef.current);
        if (stop) return;
        // Admin RESET: the attempt was flipped back to in_progress (e.g. submitted
        // by accident, or reopened with leftover time). Drop the score screen and
        // bounce the student straight back into the exam — resume screen if any
        // lockdown gate is on, otherwise straight into running — carrying their
        // saved answers and the fresh server-anchored deadline.
        if (st.status === "in_progress" && st.endAt && st.attemptId) {
          submittedRef.current = false;
          setResult(null);
          setGradeDone(false);
          const saved = loadProgress(examId);
          const endAt = new Date(st.endAt).getTime();
          const merged = { ...(st.answers ?? {}), ...(saved?.answers ?? {}) };
          setSession({
            attemptId: st.attemptId,
            endAt,
            answers: merged,
            flags: saved?.flags ?? {},
            integrityEvents: [],
          });
          saveProgress(examId, { attemptId: st.attemptId, endAt, answers: merged, flags: saved?.flags ?? {}, cur: saved?.cur });
          if (typeof saved?.cur === "number" && Number.isFinite(saved.cur)) setCur(saved.cur);
          setHeld(!!st.held);
          const cfg = proctoringRef.current;
          if (cfg.requireWebcam || cfg.fullscreenRequired || cfg.requireSingleScreen) {
            setPhase("resume");
            if (cfg.requireWebcam) void enableCamera();
            if (cfg.requireSingleScreen) void getDisplayCount().then(setDisplayCount).catch(() => {});
          } else {
            enterRunning();
          }
          return;
        }
        if (st.status === "graded") {
          setGradeDone(true);
          return;
        }
      } catch { /* ignore, retry */ }
      if (!stop && ++polls < MAX_POLLS) timer = window.setTimeout(poll, INTERVAL_MS);
    };
    let timer = window.setTimeout(poll, FIRST_DELAY_MS);
    return () => { stop = true; window.clearTimeout(timer); };
  }, [phase, result, examId, gradeDone]);

  // ---- Proctoring while running ----
  // Real exams run inside Safe Exam Browser (SEB), which enforces lockdown at the
  // OS level; this layer records the EVIDENCE (and re-enforces fullscreen) so an
  // admin can review what happened. Tab/focus loss is recorded but NEVER
  // auto-submits — SEB already blocks tab switching, and a home candidate must not
  // lose their exam to a stray notification.
  useEffect(() => {
    if (phase !== "running") return;
    const cfg = proctoringRef.current;
    const stop = startProctoring((ev) => {
      const rec = recordEventRef.current;
      switch (ev.type) {
        case "fullscreen_exit":
          rec("fullscreen_exit", ev.detail, { snapshot: true, minGapMs: 3000 });
          pushAlert("You left fullscreen — the exam must stay in fullscreen. This has been recorded.", "danger");
          // Re-enforce immediately. If the browser refuses without a fresh user
          // gesture, the overlay below forces the student to click to come back.
          void requestFullscreen().then(() => {
            setTimeout(() => { if (!document.fullscreenElement) setFsExited(true); }, 400);
          });
          break;
        case "tab_switch":
          rec("tab_switch", ev.detail, { snapshot: true, minGapMs: 3000 });
          pushAlert("You switched away from the exam window. This has been recorded.", "danger");
          break;
        case "focus_loss":
          // An external focus stealer (OS notification, antivirus popup) fires blur on a
          // ~60s cadence on some machines, so an 8s gap logged one row a minute for the
          // whole exam. 5 minutes collapses that into a handful of context rows. Genuine
          // app switching is recorded by `tab_switch` above, which is the scored signal.
          rec("focus_loss", ev.detail, { snapshot: true, minGapMs: 300_000 });
          break;
        case "copy":
        case "paste":
        case "cut":
          rec(ev.type, ev.detail, { minGapMs: 2000 });
          pushAlert("Copying from the exam is disabled. This has been recorded.", "warn");
          break;
        case "copy_in_answer":
        case "paste_in_answer":
        case "cut_in_answer":
          // Allowed inside the student's own answer field — recorded silently.
          rec(ev.type, ev.detail, { minGapMs: 5000 });
          break;
        default:
          // context_menu / shortcut / screenshot / Electron kiosk events.
          rec(ev.type, ev.detail, { minGapMs: 2000 });
          break;
      }
    }, cfg);
    return stop;
  }, [phase, pushAlert]);

  // Clear the "return to fullscreen" overlay the moment fullscreen is back.
  useEffect(() => {
    const onFs = () => { if (document.fullscreenElement) setFsExited(false); };
    document.addEventListener("fullscreenchange", onFs);
    return () => document.removeEventListener("fullscreenchange", onFs);
  }, []);

  // Drain queued violations on a timer too, so evidence recorded while offline
  // (or before the attempt id existed) still reaches the server.
  useEffect(() => {
    if (phase !== "running") return;
    const t = setInterval(() => flushEventsRef.current(), 10_000);
    return () => clearInterval(t);
  }, [phase]);

  // ---- Periodic webcam snapshots while running ----
  // A candidate sitting still with a phone in their lap trips NO violation, so
  // violation-only capture would leave an empty record for exactly the case an
  // admin most wants to review. These timed frames give a reviewable trail of what
  // the camera saw across the whole attempt.
  //
  // Load SHAPE matters more than volume here. Images go straight from the browser
  // to object storage (the API only signs a URL — it never handles image bytes), so
  // the risk isn't server CPU, it's 150 clients uploading on the same wall-clock
  // tick and saturating home uplinks at once. Each client therefore jitters its own
  // period by +/-25% and delays its FIRST capture by a random slice of one full
  // interval, so uploads spread out instead of spiking. A failed capture is skipped
  // silently and retried on the next tick — never in a tight loop, and never
  // allowed to interrupt the exam.
  useEffect(() => {
    if (phase !== "running") return;
    const cfg = proctoringRef.current;
    if (!cfg.webcamSnapshots || !cfg.requireWebcam) return;
    // Floor the interval so a mistyped setting can't turn into an upload storm.
    const baseMs = Math.max(20, cfg.snapshotIntervalSec || 27) * 1000;
    // Per-tick jitter is only ±10%: at a 27s cadence a wider band would push
    // frames outside the intended 25-30s window. The heavy de-synchronising is
    // done by the random first-capture offset below (0..one full interval), which
    // is what actually stops 150 machines uploading on the same wall-clock tick.
    const nextDelay = () => baseMs * (0.9 + Math.random() * 0.2);
    let timer: ReturnType<typeof setTimeout> | null = null;
    let stopped = false;

    const tick = async () => {
      if (stopped) return;
      // Skip (don't stop) while the exam is locked, offline, or the camera is down
      // — the next tick tries again once conditions recover.
      const ready =
        !submittedRef.current &&
        !lockedRef.current &&
        navigator.onLine &&
        isCameraActive(webcamRef.current);
      if (ready) {
        try { await capturePeriodicRef.current(); } catch { /* never break the exam */ }
      }
      if (!stopped) timer = setTimeout(tick, nextDelay());
    };

    timer = setTimeout(tick, Math.random() * baseMs);
    return () => { stopped = true; if (timer) clearTimeout(timer); };
  }, [phase]);

  // ---- Webcam lifecycle while running ----
  useEffect(() => {
    if (phase !== "running" || !proctoringRef.current.requireWebcam) return;
    if (webcamRef.current) attachVideo(webcamRef.current);
  }, [phase, attachVideo]);

  // ---- Camera-health feeder: when is a camera incident actually OVER? ----
  //
  // Deliberately its own loop rather than a line inside an existing one. The
  // snapshot tick skips while `lockedRef` is set and the obstruction loop is
  // gated on detectCameraBlock — but the state machine needs an unbroken stream
  // of readings precisely while the exam IS locked, since that is when a flapping
  // camera is being re-acquired every 2.5s. Track state is read straight off the
  // handle (no capture, no upload), so 2s costs nothing.
  useEffect(() => {
    if (phase !== "running" || !proctoringRef.current.requireWebcam) return;
    const t = setInterval(() => {
      if (submittedRef.current) return;
      camEpisodeRef.current = onCameraSeen(camEpisodeRef.current, isCameraActive(webcamRef.current), Date.now());
    }, 2000);
    return () => clearInterval(t);
  }, [phase]);

  // Cleanup webcam + lock timer on unmount.
  useEffect(() => {
    return () => {
      webcamRef.current?.stop();
      webcamRef.current = null;
      if (lockTimerRef.current) clearInterval(lockTimerRef.current);
    };
  }, []);

  // ---- Timer tick ----
  useEffect(() => {
    if (phase !== "running") return;
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, [phase]);

  // ---- Single-screen watchdog while running ----
  // Records an extra display as a violation (with a snapshot) and warns the
  // student — it does NOT lock them out. Home candidates often have a second
  // monitor attached; the admin decides what to do with the evidence afterwards.
  useEffect(() => {
    if (phase !== "running" || !proctoringRef.current.requireSingleScreen) return;
    const check = () => void getDisplayCount().then((n) => {
      setDisplayCount(n);
      if (n > 1) {
        recordEventRef.current("multi_monitor", `${n} displays connected`, { snapshot: true, minGapMs: 60_000 });
        pushAlert(`${n} displays detected — only one is allowed. This has been recorded.`, "warn");
      }
    }).catch(() => {});
    const t = setInterval(check, 5000);
    check();
    return () => clearInterval(t);
  }, [phase, pushAlert]);

  // Live server-anchored countdown.
  const remaining = session ? session.endAt - now : 0;

  // ---- Timed "minutes left" warnings (10 min + 5 min) ----
  // A big blinking banner appears below the question when the countdown crosses
  // each threshold, then auto-hides after 10 seconds. Fires exactly once on the
  // downward crossing (a baseline is established on the first sample so resuming
  // an exam already below a threshold never triggers a false warning).
  const [timeAlert, setTimeAlert] = useState<number | null>(null);
  const prevRemRef = useRef<number>(Infinity);
  useEffect(() => {
    if (phase !== "running" || submittedRef.current) return;
    const prev = prevRemRef.current;
    prevRemRef.current = remaining;
    if (!Number.isFinite(prev)) return; // first sample: establish baseline only
    for (const th of [10, 5]) {
      const mark = th * 60_000;
      if (prev > mark && remaining <= mark) {
        setTimeAlert(th);
        window.setTimeout(() => setTimeAlert((v) => (v === th ? null : v)), 10_000);
      }
    }
  }, [remaining, phase]);

  // ---- Submit ----
  // `spreadMs`: wait a random 0..spreadMs AFTER locking the screen and capturing
  // the answers, before sending. Only the timer-reaches-zero auto-submit uses it:
  // there every candidate's clock hits zero in the same second, and ~1,100 submits
  // landing at once queued the whole server (measured on a stand-in database:
  // every request, students and the admin console alike, stalled up to 15 s).
  // Spread over 15 s, submit p95 fell from 14.7 s to 4.8 s and the slowest admin
  // page from 11.8 s to 1.4 s. Nothing can be answered during the
  // wait — the paper is already captured and the screen already shows
  // "Submitting" — and the server accepts a submit for minutes after the bell
  // (the auto-submit sweep's grace is 3 minutes), so no work is lost.
  const doSubmit = useCallback(async (opts?: { spreadMs?: number }) => {
    const s = sessionRef.current;
    if (!s || submittedRef.current || !bundle) return;
    // Push any queued violations before we flip the submitted flag (after which
    // recording stops). They also ride along in the payload as a backstop.
    flushEventsRef.current();
    submittedRef.current = true;
    setSubmitting(true);

    const answers = bundle.questions
      .filter((q) => s.answers[q.id] != null && String(s.answers[q.id]).length > 0)
      .map((q) => ({ questionId: q.id, response: s.answers[q.id] }));
    const answered = answers.length;
    const skipped = bundle.questions.length - answered;
    const payload = { answers, integrityEvents: s.integrityEvents, optionOrder: bundle.optionOrder };

    try {
      // Stop the camera / fullscreen immediately; show the "validating" screen
      // while the server auto-grades (AI grades coding + short answers on submit).
      webcamRef.current?.stop();
      webcamRef.current = null;
      if (lockTimerRef.current) clearInterval(lockTimerRef.current);
      setLocked(false);
      void exitFullscreen();
      setPhase("validating");
      if (opts?.spreadMs && opts.spreadMs > 0) {
        await new Promise((r) => setTimeout(r, Math.random() * opts.spreadMs!));
      }
      const res = await api.submit(s.attemptId, payload);
      if (examId) clearProgress(examId);
      setResult({ answered, skipped, events: s.integrityEvents.length, attemptId: s.attemptId, score: res.score ?? null, gradeAt: res.gradeAt ?? null });
      setSubmitting(false);
      setPhase("done");
    } catch (e) {
      // We got here only AFTER api.submit exhausted its own retries (4 attempts
      // with backoff), so this is a real, persistent failure — not a blip.
      submittedRef.current = false;
      setSubmitting(false);
      setPhase("running");
      // The old copy always said "connection lost", which blamed the student's
      // wifi even when the server had returned a 500. Distinguish the two: a
      // status means we reached the server and it refused.
      const status = (e as { status?: number } | null)?.status;
      setErr(
        status && status >= 500
          ? `Couldn't submit — the server returned an error (${status}) after several retries. Your answers are safe on this device. Tell your invigilator, then press Submit again.`
          : status
            ? `Couldn't submit — ${(e as Error).message} Your answers are safe on this device. Tell your invigilator before pressing Submit again.`
            : "Couldn't submit — we couldn't reach the server after several attempts. Check your connection and press Submit again. Your answers are safe on this device.",
      );
    }
  }, [bundle, examId]);

  const doSubmitRef = useRef<typeof doSubmit | null>(null);
  doSubmitRef.current = doSubmit;

  useEffect(() => {
    // Auto-submit on timeout — only when the admin left the grace toggle on,
    // online, and NOT during an admin global hold (timer is frozen while held).
    // Guard: never fire within the first few seconds of (re)entering running.
    // After an admin reopen the session is rebuilt with a fresh deadline; if that
    // deadline is momentarily stale/zero we must not instantly resubmit — that
    // was the submit↔reopen loop. A genuine end-of-exam timeout still fires once
    // this short settle window passes.
    const settled = Date.now() - runningSinceRef.current > 5_000;
    if (phase === "running" && session && online && !held && remaining <= 0 && settled && proctoringRef.current.autoSubmitOnTimeout) void doSubmit({ spreadMs: AUTO_SUBMIT_SPREAD_MS });
  }, [phase, session, remaining, online, held, doSubmit]);

  // Persist answers/flags locally on every change while running, so a forced
  // logout (internet drop) never loses work.
  useEffect(() => {
    if (phase === "running" && examId && session) {
      saveProgress(examId, { answers: session.answers, flags: session.flags, cur: curRef.current });
    }
  }, [phase, examId, session]);

  // ---- Real-time answer sync ----
  // Push every dirty answer to the server. Called on navigation, on a 2s typing
  // debounce, on each heartbeat, and on reconnect. Snapshots the dirty set so
  // concurrent edits aren't lost, and re-queues everything on failure to retry.
  const flushSync = useCallback(() => {
    if (syncingRef.current || submittedRef.current) return;
    const s = sessionRef.current;
    if (!s?.attemptId || !navigator.onLine || dirtyRef.current.size === 0) return;
    const ids = Array.from(dirtyRef.current);
    dirtyRef.current.clear();
    const answers = ids.map((questionId) => ({ questionId, response: s.answers[questionId] ?? null }));
    syncingRef.current = true;
    void api.syncAnswers(s.attemptId, answers, optionOrderRef.current)
      .catch(() => { for (const q of ids) dirtyRef.current.add(q); })
      .finally(() => { syncingRef.current = false; });
  }, []);
  const flushSyncRef = useRef(flushSync);
  flushSyncRef.current = flushSync;
  // Navigate to a question index, flushing any pending answer first so the DB is
  // always current the instant a student moves off a question.
  const navTo = useCallback((next: number | ((c: number) => number)) => {
    if (syncTimerRef.current) { clearTimeout(syncTimerRef.current); syncTimerRef.current = null; }
    flushSyncRef.current();
    setCur(next);
  }, []);

  // ---- Answer handlers ----
  function setAnswer(qId: string, value: unknown) {
    setSession((prev) => (prev ? { ...prev, answers: { ...prev.answers, [qId]: value } } : prev));
    dirtyRef.current.add(qId);
    if (syncTimerRef.current) clearTimeout(syncTimerRef.current);
    syncTimerRef.current = setTimeout(() => flushSyncRef.current(), 2000);
  }
  function toggleFlag(qId: string) {
    setSession((prev) => (prev ? { ...prev, flags: { ...prev.flags, [qId]: !prev.flags[qId] } } : prev));
  }

  const questions = bundle?.questions ?? [];
  const answeredCount = useMemo(() => (session ? questions.filter((q) => session.answers[q.id] != null && String(session.answers[q.id]).length > 0).length : 0), [session, questions]);
  const flagCount = useMemo(() => (session ? questions.filter((q) => session.flags[q.id]).length : 0), [session, questions]);

  // Manual submit — warn if questions are still flagged for review so the
  // student gets a chance to unflag/revisit before finishing. Auto-submit on
  // timeout never runs through here (it calls doSubmit directly, silently).
  function handleSubmitClick() {
    if (flagCount > 0) {
      const ok = window.confirm(
        `You still have ${flagCount} question${flagCount > 1 ? "s" : ""} flagged for review.\n\n` +
          `Press Cancel to go back and review them, or OK to submit anyway.`,
      );
      if (!ok) return;
    }
    void doSubmit();
  }

  if (!examId) return null;

  // ===== BRIEF =====
  if (phase === "brief") {
    return (
      <div className="runner">
        <div className="runner-top">
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <button className="btn btn-ghost btn-sm" onClick={() => navigate("/")}><Icon name="arrow-left" /> Back</button>
            <span style={{ fontWeight: 700 }}>{bundle?.exam.title || "Exam"}</span>
          </div>
          <NetBadge online={online} />
        </div>
        <div style={{ maxWidth: 640, margin: "0 auto", padding: 40, width: "100%" }}>
          <div className="card" style={{ padding: 30 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
              <div style={{ width: 40, height: 40, borderRadius: 10, background: "var(--color-brand-soft)", display: "flex", alignItems: "center", justifyContent: "center", color: "var(--brand)" }}><Icon name="shield-check" size={20} /></div>
            </div>
            <h1 style={{ fontFamily: "var(--font-serif)", fontSize: 26, margin: "10px 0 4px" }}>{bundle?.exam.title || "Loading exam…"}</h1>
            {bundle && <p style={{ color: "var(--color-ink2)", marginBottom: 20 }}>{bundle.questions.length} questions · {bundle.exam.durationMin} minutes · {bundle.exam.totalPoints} points</p>}

            <div style={{ display: "grid", gap: 10, marginBottom: 24 }}>
              {[
                ["monitor", "Fullscreen lockdown for the whole exam"],
                ["timer", "One timer for the whole exam — auto-submits at zero"],
                ["flag", "Flag questions to revisit, jump freely between them"],
              ].map(([ic, txt]) => (
                <div key={txt} style={{ display: "flex", gap: 10, alignItems: "center", fontSize: 14, color: "var(--color-ink2)" }}>
                  <Icon name={ic!} size={16} /> {txt}
                </div>
              ))}
            </div>

            {err && <div style={{ display: "flex", gap: 8, color: "var(--color-danger)", background: "var(--color-danger-bg)", padding: "10px 12px", borderRadius: 10, fontSize: 13, marginBottom: 16 }}><Icon name="triangle-alert" size={15} /> {err}</div>}

            <button className="btn btn-primary" style={{ width: "100%", padding: 13, fontSize: 14 }} disabled={!bundle} onClick={goPreflight}>
              <Icon name="play" /> Start exam
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ===== RESUME (after a mid-exam refresh) =====
  // The attempt is already running server-side; we just need a user gesture to
  // re-enter fullscreen / confirm the camera before dropping back in. The timer
  // keeps counting from the server-anchored deadline (no reset, no /start call).
  if (phase === "resume" && session) {
    const needCam = proctoring.requireWebcam;
    const needSingle = proctoring.requireSingleScreen;
    const camOk = !needCam || camReady;
    const screenOk = !needSingle || displayCount <= 1;
    // Extra displays are flagged, not blocking — only the camera gates a resume.
    const canResume = camOk;
    return (
      <div className="runner" style={{ alignItems: "center", justifyContent: "center" }}>
        <div className="card" style={{ padding: 32, maxWidth: 520, width: "100%" }}>
          <div style={{ textAlign: "center", marginBottom: 20 }}>
            <div style={{ width: 52, height: 52, borderRadius: 14, background: "var(--color-brand-soft)", color: "var(--brand)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 14px" }}><Icon name="rotate-ccw" size={26} /></div>
            <h2 style={{ fontFamily: "var(--font-serif)", fontSize: 22, marginBottom: 4 }}>Resume your exam</h2>
            <p style={{ color: "var(--color-ink2)", fontSize: 14 }}>Your exam is still in progress. Your answers were saved on this device.</p>
            <div style={{ marginTop: 14, fontFamily: "var(--font-mono, monospace)", fontSize: 30, fontWeight: 700, color: remaining < 60_000 ? "var(--color-danger)" : "var(--color-ink)" }}>{fmtClock(remaining)}</div>
            <p style={{ color: "var(--color-ink2)", fontSize: 12 }}>time remaining</p>
          </div>

          {needCam && (
            <div style={{ marginBottom: 16 }}>
              <video ref={videoRef} autoPlay playsInline muted style={{ width: "100%", maxHeight: 200, borderRadius: 12, background: "#0b1220", objectFit: "cover", transform: "scaleX(-1)" }} />
            </div>
          )}

          <div style={{ display: "grid", gap: 10, marginBottom: 20 }}>
            {needCam && <CheckRow ok={camOk} label="Webcam" detail={camOk ? "Camera active" : camError || "Camera not detected — click Enable camera"} />}
            {needSingle && <CheckRow ok={screenOk} label="Single display" detail={screenOk ? "One monitor detected" : `${displayCount} displays detected — this will be recorded for review`} />}
          </div>

          {camError && needCam && (
            <div style={{ display: "flex", gap: 8, color: "var(--color-danger)", background: "var(--color-danger-bg)", padding: "10px 12px", borderRadius: 10, fontSize: 13, marginBottom: 14 }}><Icon name="triangle-alert" size={15} /> {camError}</div>
          )}

          {needCam && !camReady && (
            <button className="btn btn-ghost" style={{ width: "100%", padding: 11, marginBottom: 10 }} onClick={() => void enableCamera()}>
              <Icon name="video" /> Enable camera
            </button>
          )}
          <button className="btn btn-primary" style={{ width: "100%", padding: 13 }} disabled={!canResume} onClick={() => { if (proctoringRef.current.fullscreenRequired) void requestFullscreen(); enterRunning(); }}>
            <Icon name="play" /> {canResume ? "Resume exam" : "Enable your camera to resume"}
          </button>
        </div>
      </div>
    );
  }

  // ===== PREFLIGHT (webcam + internet gate) =====
  if (phase === "preflight") {
    const needCam = proctoring.requireWebcam;
    const needSingle = proctoring.requireSingleScreen;
    const netOk = online;
    const camOk = !needCam || camReady;
    const screenOk = !needSingle || displayCount <= 1;
    // Extra displays are recorded as a violation, not a hard block — a candidate
    // sitting at home must still be able to begin the exam.
    const canStart = netOk && camOk;
    return (
      <div className="runner" style={{ alignItems: "center", justifyContent: "center" }}>
        <div className="card" style={{ padding: 32, maxWidth: 520, width: "100%" }}>
          <div style={{ textAlign: "center", marginBottom: 20 }}>
            <div style={{ width: 52, height: 52, borderRadius: 14, background: "var(--color-brand-soft)", color: "var(--brand)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 14px" }}><Icon name="shield-check" size={26} /></div>
            <h2 style={{ fontFamily: "var(--font-serif)", fontSize: 22, marginBottom: 4 }}>System check</h2>
            <p style={{ color: "var(--color-ink2)", fontSize: 14 }}>We need to verify your setup before the exam begins.</p>
          </div>

          {needCam && (
            <div style={{ marginBottom: 16 }}>
              <video ref={videoRef} autoPlay playsInline muted style={{ width: "100%", maxHeight: 220, borderRadius: 12, background: "#0b1220", objectFit: "cover", transform: "scaleX(-1)" }} />
            </div>
          )}

          <div style={{ display: "grid", gap: 10, marginBottom: 20 }}>
            {needCam && <CheckRow ok={camOk} label="Webcam" detail={camOk ? "Camera active" : camError || "Camera not detected — click Enable camera"} />}
            <CheckRow ok={netOk} label="Internet connection" detail={netOk ? "Connected" : "Waiting for a connection to start the exam"} />
            {needSingle && <CheckRow ok={screenOk} label="Single display" detail={screenOk ? "One monitor detected" : `${displayCount} displays detected — disconnect extras if you can; this is recorded for review`} />}
            {needCam && camOk && <CheckRow ok={!camBlocked} label="Camera view" detail={camBlocked ? camBlocked : "Your face is clearly visible"} />}
          </div>

          {camBlocked && needCam && camOk && (
            <div style={{ display: "flex", gap: 8, color: "var(--color-warn)", background: "#fdf3e2", padding: "10px 12px", borderRadius: 10, fontSize: 13, marginBottom: 14 }}>
              <Icon name="triangle-alert" size={15} />
              <span>Uncover your camera and make sure the room is well lit. You can still start, but a blocked camera view is recorded for review.</span>
            </div>
          )}

          {camError && needCam && (
            <div style={{ display: "flex", gap: 8, color: "var(--color-danger)", background: "var(--color-danger-bg)", padding: "10px 12px", borderRadius: 10, fontSize: 13, marginBottom: 14 }}><Icon name="triangle-alert" size={15} /> {camError}</div>
          )}
          {err && (
            <div style={{ display: "flex", gap: 8, color: "var(--color-danger)", background: "var(--color-danger-bg)", padding: "10px 12px", borderRadius: 10, fontSize: 13, marginBottom: 14 }}><Icon name="triangle-alert" size={15} /> {err}</div>
          )}

          {needCam && !camReady && (
            <button className="btn btn-ghost" style={{ width: "100%", padding: 11, marginBottom: 10 }} onClick={() => void enableCamera()}>
              <Icon name="video" /> Enable camera
            </button>
          )}
          <button className="btn btn-primary" style={{ width: "100%", padding: 13 }} disabled={!canStart} onClick={() => void startExam()}>
            <Icon name="play" /> {canStart ? "Start secure exam" : needCam && !camOk ? "Enable your camera to start" : "Waiting for connection…"}
          </button>
          <button className="btn btn-ghost btn-sm" style={{ width: "100%", marginTop: 10 }} onClick={() => { webcamRef.current?.stop(); webcamRef.current = null; setCamReady(false); navigate("/"); }}>Cancel</button>
        </div>
      </div>
    );
  }

  // ===== VALIDATING (submitting) =====
  if (phase === "validating") {
    return (
      <div className="runner" style={{ alignItems: "center", justifyContent: "center" }}>
        <div className="card" style={{ padding: 36, maxWidth: 440, width: "100%", textAlign: "center" }}>
          <div style={{ width: 58, height: 58, borderRadius: 999, background: "var(--color-brand-soft)", color: "var(--brand)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px" }}><Icon name="loader-circle" size={28} className="animate-spin" /></div>
          <h1 style={{ fontFamily: "var(--font-serif)", fontSize: 24, marginBottom: 6 }}>Submitting your exam</h1>
          <p style={{ color: "var(--color-ink2)" }}>Your answers are being submitted. This only takes a moment — please don't close this window.</p>
        </div>
      </div>
    );
  }

  // ===== DONE =====
  // At submit time only objective questions are graded inline; subjective/coding
  // are graded by AI in the background afterward. We poll the attempt status and
  // only show the real final score once grading finishes (gradeDone). Until then
  // we show a "grading in progress" state — never the partial submit-time score.
  if (phase === "done" && result) {
    return (
      <div className="runner" style={{ alignItems: "center", justifyContent: "center" }}>
        <div className="card" style={{ padding: 40, maxWidth: 460, width: "100%", textAlign: "center" }}>
          <div style={{ width: 62, height: 62, borderRadius: 999, background: "#e7f5ee", color: "var(--color-success)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px" }}><Icon name="check" size={32} /></div>
          <h1 style={{ fontFamily: "var(--font-serif)", fontSize: 26, marginBottom: 12 }}>Thank you for taking the exam</h1>
          <p style={{ color: "var(--color-ink2)", marginBottom: 28, lineHeight: 1.6, fontSize: 15 }}>
            {result.gradeAt && result.gradeAt > Date.now()
              // Deferred grading: the paper is safely stored, but marking only
              // starts after the exam closes for everyone, so promise a window
              // instead of "soon" — students otherwise sit here refreshing.
              ? "Your answers were submitted successfully. Evaluation begins after the exam closes for all students — please check back for your result within 2 hours."
              : "Your answers were submitted successfully. Your score will be updated soon."}
          </p>

          <button
            className="btn btn-primary"
            style={{ width: "100%", padding: 12 }}
            onClick={() => {
              if (examId) clearProgress(examId);
              logout();
              window.location.replace(window.location.origin + "/px9k2m7/exit");
            }}
          >
            <Icon name="log-out" /> Logout
          </button>
        </div>
      </div>
    );
  }

  // ===== RUNNING =====
  if (phase !== "running" || !session || questions.length === 0) {
    return (
      <div className="runner" style={{ alignItems: "center", justifyContent: "center" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, color: "var(--color-ink2)" }}>
          <Icon name="loader-circle" className="animate-spin" /> Preparing…
        </div>
        {err && <button className="btn btn-primary" style={{ marginTop: 16 }} onClick={startExam}>Retry start</button>}
      </div>
    );
  }

  const q = questions[cur];
  if (!q) return null;
  const danger = remaining < 60_000;

  return (
    <div className="runner">
      {/* Violation alerts */}
      {alerts.length > 0 && (
        <div style={{ position: "fixed", top: 16, left: "50%", transform: "translateX(-50%)", zIndex: 60, display: "grid", gap: 8, width: "min(560px, 92vw)" }}>
          {alerts.map((a) => (
            <div key={a.id} style={{ display: "flex", alignItems: "center", gap: 10, padding: "11px 14px", borderRadius: 10, fontSize: 13.5, fontWeight: 500, color: "#fff", boxShadow: "0 8px 24px rgba(0,0,0,.25)", background: a.tone === "danger" ? "var(--color-danger)" : "var(--color-warn)" }}>
              <Icon name="triangle-alert" size={16} /> {a.text}
            </div>
          ))}
        </div>
      )}

      {/* Fullscreen-escape overlay — the student must return to fullscreen to
          continue. Shown only when the browser refused to re-enter fullscreen
          automatically (it needs a fresh user gesture). The exit itself is already
          recorded as a violation with a snapshot. */}
      {fsExited && !locked && (
        <div style={{ position: "fixed", inset: 0, zIndex: 85, background: "rgba(8,12,20,.94)", display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(4px)" }}>
          <div className="card" style={{ padding: 34, maxWidth: 440, textAlign: "center" }}>
            <div style={{ width: 58, height: 58, borderRadius: 999, background: "var(--color-danger-bg)", color: "var(--color-danger)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px" }}><Icon name="monitor-x" size={28} /></div>
            <h2 style={{ fontFamily: "var(--font-serif)", fontSize: 22, marginBottom: 6 }}>Return to fullscreen</h2>
            <p style={{ color: "var(--color-ink2)", fontSize: 14, marginBottom: 18 }}>This exam must stay in fullscreen. Leaving it has been recorded. Click below to go back — the timer keeps running.</p>
            <button className="btn btn-primary" style={{ width: "100%", padding: 11 }} onClick={() => { void requestFullscreen(); setFsExited(false); }}>
              <Icon name="monitor" /> Back to fullscreen
            </button>
          </div>
        </div>
      )}

      {/* Extra-display warning strip — recorded, never blocking. */}
      {proctoring.requireSingleScreen && displayCount > 1 && (
        <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 45, background: "var(--color-warn)", color: "#fff", padding: "8px 14px", fontSize: 12.5, fontWeight: 600, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
          <Icon name="monitor-x" size={14} /> {displayCount} displays detected — only one is allowed. This has been recorded for review.
        </div>
      )}

      {/* Camera-loss lock overlay */}
      {locked && (
        <div style={{ position: "fixed", inset: 0, zIndex: 80, background: "rgba(8,12,20,.92)", display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(4px)" }}>
          <div className="card" style={{ padding: 34, maxWidth: 440, textAlign: "center" }}>
            <div style={{ width: 58, height: 58, borderRadius: 999, background: camBack ? "var(--color-warn-bg, #3a2c0a)" : "var(--color-danger-bg)", color: camBack ? "var(--color-warn, #f0b429)" : "var(--color-danger)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px" }}><Icon name={camBack ? "video" : "video-off"} size={28} /></div>
            <h2 style={{ fontFamily: "var(--font-serif)", fontSize: 22, marginBottom: 6 }}>{camBack ? "Camera is back" : camFail?.title ?? "Exam paused"}</h2>
            <p style={{ color: "var(--color-ink2)", fontSize: 14, marginBottom: 14 }}>
              {camBack
                ? "Your camera is working again. The exam unlocks when the countdown below reaches zero."
                : camFail?.message ?? "Your camera was turned off. The exam is paused until it is back."} This has been recorded for review.
            </p>

            {/* The remedies. This is the whole point of the overlay: inside SEB
                there is no address bar to click, so the student needs steps that
                work from their seat. Ordered hardware-first — a privacy shutter is
                far more common than a genuine permission block, and it is the one
                thing they can fix without an invigilator.
                Hidden once the camera is back: instructions for a problem that no
                longer exists are just noise in front of a running clock.

                listStyle is set explicitly because Tailwind's preflight resets
                `ol` to list-style:none, which silently turned these numbered
                steps into an unordered wall of text. A candidate under pressure
                needs to see "try 1, then 2, then 3", not a paragraph. */}
            {!camBack && camFail && camFail.steps.length > 0 && (
              <ol style={{ textAlign: "left", margin: "0 0 16px", padding: "14px 16px 14px 32px", background: "var(--color-danger-bg)", borderRadius: 10, color: "var(--color-ink)", fontSize: 13, lineHeight: 1.65, listStyle: "decimal outside" }}>
                {camFail.steps.map((s, i) => <li key={i} style={{ marginBottom: i === camFail.steps.length - 1 ? 0 : 6 }}>{s}</li>)}
              </ol>
            )}

            {/* A denied permission never recovers by waiting, so showing a
                countdown there would promise something that cannot happen. Show the
                penalty clock only while it is genuinely the thing being waited on. */}
            {(camBack || camFail?.code !== "permission_denied") && lockLeft > 0 && (
              <div className="timer-big timer-danger" style={{ justifyContent: "center", marginBottom: 18 }}><Icon name="lock" size={20} /> {fmtClock(lockLeft * 1000)}</div>
            )}

            {/* Nothing left to retry once the camera is live — the only thing
                standing between the student and the exam is the countdown. */}
            {!camBack && (
              <button className="btn btn-primary" style={{ width: "100%", padding: 11 }} onClick={() => void tryRestoreCamera()}><Icon name="video" /> I've turned my camera back on</button>
            )}
            {!camBack && camError && <div style={{ marginTop: 12, fontSize: 12.5, color: "var(--color-danger)" }}>{camError}</div>}
            <p style={{ marginTop: 14, fontSize: 12, color: "#8ba0bd" }}>
              {camBack
                ? "The exam unlocks by itself — do not close this window."
                : "The exam resumes as soon as your camera is back and the lock time has elapsed."}{" "}
              <strong>Your exam timer keeps running.</strong>
            </p>
          </div>
        </div>
      )}

      {/* Covered-lens lock. A HARD stop: no dismiss button, and uncovering the
          lens does not end it — the two minutes are always served in full (see
          obstruction-lock.ts). The exam timer keeps running underneath, which is
          what makes covering the camera cost more than leaving it alone. Ranks
          below camera-loss / fullscreen / hold, which are stronger conditions. */}
      {phase === "running" && camLockActive && !locked && !held && !fsExited && (
        <div style={{ position: "fixed", inset: 0, zIndex: 78, background: "rgba(8,12,20,.94)", display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(4px)" }}>
          <div className="card" style={{ padding: 34, maxWidth: 460, textAlign: "center" }}>
            <div style={{ width: 58, height: 58, borderRadius: 999, background: "var(--color-warn-bg, #3a2c0a)", color: "var(--color-warn, #f0b429)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px" }}><Icon name="eye-off" size={28} /></div>
            <h2 style={{ fontFamily: "var(--font-serif)", fontSize: 22, marginBottom: 6 }}>We can't see you</h2>
            <p style={{ color: "var(--color-ink2)", fontSize: 14, marginBottom: 12 }}>
              Your camera is on, but the picture is blank. Your exam is locked for two minutes. If something is covering the lens, remove it now. If your room is dark, switch on a light.
            </p>
            <div className="timer-big" style={{ justifyContent: "center", marginBottom: 10 }}>
              <Icon name="lock" size={20} /> {camLockLeft}
            </div>
            <p style={{ color: "var(--color-ink2)", fontSize: 13.5, marginBottom: 12 }}>
              The full two minutes are served even if you uncover the camera straight away, and <strong>your exam timer keeps running</strong>. If the view is still blocked when this ends, another two minutes start.
            </p>
            <p style={{ fontSize: 11.5, color: "var(--color-ink2)" }}>This has been recorded for review.</p>
          </div>
        </div>
      )}

      {/* Admin global-hold overlay — freezes the exam for everyone during a
          venue-wide outage until the administrator resumes it. Held time is
          added back to the deadline automatically. */}
      {held && (
        <div style={{ position: "fixed", inset: 0, zIndex: 90, background: "rgba(8,12,20,.94)", display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(4px)" }}>
          <div className="card" style={{ padding: 34, maxWidth: 440, textAlign: "center" }}>
            <div style={{ width: 58, height: 58, borderRadius: 999, background: "var(--color-warn-bg, #3a2c0a)", color: "var(--color-warn, #f0b429)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px" }}><Icon name="pause" size={28} /></div>
            <h2 style={{ fontFamily: "var(--font-serif)", fontSize: 22, marginBottom: 6 }}>Exam paused by the administrator</h2>
            <p style={{ color: "var(--color-ink2)", fontSize: 14, marginBottom: 18 }}>The exam has been paused for everyone. Your answers are saved and the timer is frozen — the paused time will be added back automatically. Please wait, do not close this window.</p>
            <div className="timer-big" style={{ justifyContent: "center", marginBottom: 6 }}><Icon name="loader-circle" size={20} className="animate-spin" /> Waiting for the administrator to resume…</div>
          </div>
        </div>
      )}

      <div className="runner-top">
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <span style={{ fontWeight: 700 }}>{bundle?.exam.title}</span>
          <span className="mono-label" style={{ color: "#8ba0bd" }}>Q{cur + 1} / {questions.length}</span>
        </div>
        <div className={`timer-big ${danger ? "timer-danger" : ""}`}>
          <Icon name="timer" size={20} /> {fmtClock(remaining)}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          {proctoring.requireWebcam && (
            <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, fontWeight: 600, color: !camReady ? "var(--color-danger)" : camBlocked ? "var(--color-warn)" : "var(--color-success)" }}>
              <Icon name={camReady ? (camBlocked ? "triangle-alert" : "video") : "video-off"} size={15} /> {!camReady ? "Camera off" : camBlocked ? "Camera blocked" : "Camera on"}
            </div>
          )}
          <NetBadge online={online} />
        </div>
      </div>

      {/* Blocked-lens notice. Persistent (not a 5s toast) because it is actionable:
          the candidate can uncover the lens or turn on a light and clear it. Stays up
          after a lock has been served, while the view is still blocked, so a
          candidate who does nothing is not surprised by the next lock. */}
      {proctoring.requireWebcam && camReady && camBlocked && !camLockActive && (
        <div style={{ display: "flex", alignItems: "center", gap: 8, background: "#fdf3e2", color: "var(--color-warn)", padding: "9px 16px", fontSize: 13, fontWeight: 600, borderBottom: "1px solid #eccf9a" }}>
          <Icon name="triangle-alert" size={15} />
          <span>Your camera view is still blocked. Uncover the lens and make sure the room is lit, or your exam will be locked again — this has been recorded for review.</span>
        </div>
      )}

      {/* Live webcam preview */}
      {proctoring.requireWebcam && (
        <video ref={videoRef} autoPlay playsInline muted style={{ position: "fixed", bottom: 16, right: 16, width: 150, height: 112, borderRadius: 10, objectFit: "cover", background: "#0b1220", border: camBlocked ? "2px solid var(--color-warn)" : "2px solid rgba(255,255,255,.15)", transform: "scaleX(-1)", zIndex: camBlocked ? 79 : 40, boxShadow: "0 6px 18px rgba(0,0,0,.3)" }} />
      )}

      <div className="runner-body">
        <div className="q-main">
          <div style={{ maxWidth: 760, margin: "0 auto" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <span className="pill" style={{ textTransform: "uppercase" }}>{q.type} · {q.points} pt</span>
              <button className={`btn btn-sm ${session.flags[q.id] ? "btn-danger" : "btn-ghost"}`} onClick={() => toggleFlag(q.id)}>
                <Icon name="flag" size={13} /> {session.flags[q.id] ? "Flagged for review" : "Flag for review"}
              </button>
            </div>
            <div style={{ fontSize: 19, fontWeight: 600, lineHeight: 1.5, marginBottom: 22 }}>{q.prompt}</div>

            <QuestionInput q={q} value={session.answers[q.id]} onChange={(v) => setAnswer(q.id, v)} online={online} />

            <div style={{ display: "flex", justifyContent: "space-between", marginTop: 30 }}>
              <button className="btn btn-ghost" disabled={cur === 0} onClick={() => navTo((c) => Math.max(0, c - 1))}><Icon name="arrow-left" /> Previous</button>
              <button className="btn btn-ghost" disabled={cur === questions.length - 1} onClick={() => navTo((c) => Math.min(questions.length - 1, c + 1))}>Next <Icon name="arrow-right" /></button>
            </div>

            {/* Big blinking "minutes left" alert (fires at 10 min + 5 min, auto-hides after 10s) */}
            {timeAlert != null && (
              <div className="time-alert-banner" role="alert">
                <Icon name="alarm-clock" size={30} />
                <span>{timeAlert} minute{timeAlert > 1 ? "s" : ""} left</span>
              </div>
            )}

            {/* End-of-exam actions — only on the last question so Submit sits at the very end */}
            {cur === questions.length - 1 && (
              <div style={{ marginTop: 36, paddingTop: 24, borderTop: "1px solid var(--color-line)", display: "grid", gap: 14 }}>
                <div style={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 8, fontSize: 13.5, color: "var(--color-ink2)" }}>
                  <span><strong>{answeredCount}</strong> of {questions.length} answered</span>
                  {flagCount > 0 && <span style={{ color: "var(--color-warn)" }}><Icon name="flag" size={13} /> {flagCount} flagged for review</span>}
                </div>
                <button className="btn btn-primary" style={{ padding: 14, fontSize: 15 }} onClick={handleSubmitClick} disabled={submitting}>
                  {submitting ? <Icon name="loader-circle" className="animate-spin" /> : <Icon name="send" />} Submit exam
                </button>
              </div>
            )}
          </div>
        </div>

        <aside className="q-side">
          <div className="side-finish">
            <div className="side-finish-stats">
              <span><strong>{answeredCount}</strong>/{questions.length} answered</span>
              {flagCount > 0 && <span style={{ color: "var(--color-warn)" }}><Icon name="flag" size={12} /> {flagCount} flagged</span>}
            </div>
            <div style={{ fontSize: 12.5, color: "var(--color-ink2)", lineHeight: 1.5 }}>
              Use <strong>Previous</strong> and <strong>Next</strong> to move through the exam. Submit becomes available on the last question.
            </div>
          </div>
          <div className="mono-label" style={{ marginBottom: 12 }}>Question palette</div>
          <div className="palette-grid" style={{ marginBottom: 18 }}>
            {questions.map((qq, i) => {
              const answered = session.answers[qq.id] != null && String(session.answers[qq.id]).length > 0;
              const flagged = session.flags[qq.id];
              return (
                <div key={qq.id} className={`pal-cell ${i === cur ? "cur" : ""} ${flagged ? "pal-flag" : answered ? "pal-answered" : ""}`} style={{ cursor: "default" }} aria-current={i === cur ? "true" : undefined}>
                  {i + 1}
                  {flagged && <span className="pal-flag-dot" />}
                </div>
              );
            })}
          </div>
          <div style={{ display: "grid", gap: 8, marginBottom: 20 }}>
            <div className="legend-row"><span className="legend-sw pal-answered" /> Answered · {answeredCount}</div>
            <div className="legend-row"><span className="legend-sw" /> Unanswered · {questions.length - answeredCount}</div>
            <div className="legend-row"><span className="legend-sw pal-flag" /> Review later · {flagCount}</div>
          </div>
          {flagCount > 0 && (
            <div>
              <div className="mono-label" style={{ marginBottom: 8 }}>Flagged for review</div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                {questions.map((qq, i) => session.flags[qq.id] ? (
                  <span key={qq.id} className="btn btn-sm btn-ghost" style={{ cursor: "default", pointerEvents: "none" }}>Q{i + 1}</span>
                ) : null)}
              </div>
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}

function CheckRow({ ok, label, detail }: { ok: boolean; label: string; detail: string }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 14px", borderRadius: 10, border: "1px solid var(--color-line)", background: ok ? "#e7f5ee" : "#fdf3e2" }}>
      <div style={{ width: 30, height: 30, borderRadius: 999, display: "flex", alignItems: "center", justifyContent: "center", background: ok ? "var(--color-success)" : "var(--color-warn)", color: "#fff", flex: "none" }}>
        <Icon name={ok ? "check" : "clock"} size={16} />
      </div>
      <div style={{ minWidth: 0 }}>
        <div style={{ fontWeight: 600, fontSize: 14 }}>{label}</div>
        <div style={{ fontSize: 12.5, color: "var(--color-ink2)" }}>{detail}</div>
      </div>
    </div>
  );
}

const LETTERS = ["A", "B", "C", "D", "E", "F"];

function QuestionInput({ q, value, onChange, online }: { q: BundleQuestion; value: unknown; onChange: (v: unknown) => void; online: boolean }) {
  if ((q.type === "mcq" || q.type === "fillblank") && q.options) {
    const sel = value as number | undefined;
    return (
      <div style={{ display: "grid", gap: 10 }}>
        {q.options.map((opt, i) => (
          <div key={i} className={`opt-row ${sel === i ? "sel" : ""}`} onClick={() => onChange(i)}>
            <span className="opt-letter">{LETTERS[i]}</span>
            <span style={{ paddingTop: 2 }}>{opt}</span>
          </div>
        ))}
      </div>
    );
  }
  if (q.type === "multi" && q.options) {
    const arr = (Array.isArray(value) ? value : []) as number[];
    const toggle = (i: number) => onChange(arr.includes(i) ? arr.filter((x) => x !== i) : [...arr, i].sort());
    return (
      <div style={{ display: "grid", gap: 10 }}>
        {q.options.map((opt, i) => (
          <div key={i} className={`opt-row ${arr.includes(i) ? "sel" : ""}`} onClick={() => toggle(i)}>
            <span className="opt-letter" style={{ borderRadius: 6 }}>{arr.includes(i) ? "✓" : LETTERS[i]}</span>
            <span style={{ paddingTop: 2 }}>{opt}</span>
          </div>
        ))}
      </div>
    );
  }
  if (q.type === "truefalse") {
    const sel = value as boolean | undefined;
    return (
      <div style={{ display: "grid", gap: 10 }}>
        {[["True", true], ["False", false]].map(([lbl, val]) => (
          <div key={String(val)} className={`opt-row ${sel === val ? "sel" : ""}`} onClick={() => onChange(val)}>
            <span className="opt-letter">{val ? "T" : "F"}</span>
            <span style={{ paddingTop: 2 }}>{lbl as string}</span>
          </div>
        ))}
      </div>
    );
  }
  if (q.type === "coding") {
    return <CodingInput q={q} value={value} onChange={onChange} online={online} />;
  }
  return (
    <textarea className="input" style={{ minHeight: 160, resize: "vertical", fontFamily: "var(--font-sans)", lineHeight: 1.6 }} value={(value as string) ?? ""} onChange={(e) => onChange(e.target.value)} placeholder="Type your answer…" />
  );
}

// ---- Lightweight syntax highlighter (no deps) ----
const CODE_KEYWORDS: Record<string, Set<string>> = {
  python: new Set(["False","None","True","and","as","assert","async","await","break","class","continue","def","del","elif","else","except","finally","for","from","global","if","import","in","is","lambda","nonlocal","not","or","pass","raise","return","try","while","with","yield","self","print","range","len","str","int","float","list","dict","set","tuple","bool","input","enumerate","zip","map","filter","sum","min","max","abs","sorted","open"]),
  javascript: new Set(["var","let","const","function","return","if","else","for","while","do","switch","case","break","continue","default","class","extends","super","new","this","typeof","instanceof","in","of","try","catch","finally","throw","async","await","yield","import","export","from","as","null","undefined","true","false","void","delete","console","log"]),
  java: new Set(["abstract","assert","boolean","break","byte","case","catch","char","class","const","continue","default","do","double","else","enum","extends","final","finally","float","for","goto","if","implements","import","instanceof","int","interface","long","native","new","package","private","protected","public","return","short","static","strictfp","super","switch","synchronized","this","throw","throws","transient","try","void","volatile","while","true","false","null","String","System","out","println","print"]),
  c: new Set(["auto","break","case","char","const","continue","default","do","double","else","enum","extern","float","for","goto","if","inline","int","long","register","restrict","return","short","signed","sizeof","static","struct","switch","typedef","union","unsigned","void","volatile","while","printf","scanf","include","define","std","cout","cin","endl","using","namespace","class","public","private","new","delete","bool","true","false"]),
};
function langKeywords(lang: string): Set<string> {
  const l = lang.toLowerCase();
  if (l.startsWith("py")) return CODE_KEYWORDS.python;
  if (l === "js" || l === "javascript" || l === "node" || l === "ts" || l === "typescript") return CODE_KEYWORDS.javascript;
  if (l === "java" || l === "kotlin") return CODE_KEYWORDS.java;
  if (l === "c" || l === "cpp" || l === "c++" || l === "csharp" || l === "c#" || l === "go" || l === "rust") return CODE_KEYWORDS.c;
  return CODE_KEYWORDS.python;
}
function escHtml(s: string) { return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
function highlightCode(code: string, lang: string): string {
  const kw = langKeywords(lang);
  const re = /(#[^\n]*|\/\/[^\n]*|\/\*[\s\S]*?\*\/)|("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`)|(\b\d[\d_.eExXbBoOaAfF]*\b)|([A-Za-z_$][\w$]*)/g;
  let out = "", last = 0, m: RegExpExecArray | null;
  while ((m = re.exec(code))) {
    out += escHtml(code.slice(last, m.index));
    if (m[1]) out += `<span class="tk-com">${escHtml(m[1])}</span>`;
    else if (m[2]) out += `<span class="tk-str">${escHtml(m[2])}</span>`;
    else if (m[3]) out += `<span class="tk-num">${escHtml(m[3])}</span>`;
    else {
      const w = m[4];
      const rest = code.slice(m.index + w.length);
      if (kw.has(w)) out += `<span class="tk-kw">${escHtml(w)}</span>`;
      else if (/^\s*\(/.test(rest)) out += `<span class="tk-fn">${escHtml(w)}</span>`;
      else if (/^[A-Z]/.test(w)) out += `<span class="tk-type">${escHtml(w)}</span>`;
      else out += escHtml(w);
    }
    last = m.index + m[0].length;
  }
  out += escHtml(code.slice(last));
  return out + "\n";
}

function CodeEditor({ code, language, onChange }: { code: string; language: string; onChange: (v: string) => void }) {
  const taRef = useRef<HTMLTextAreaElement>(null);
  const preRef = useRef<HTMLPreElement>(null);
  const gutRef = useRef<HTMLDivElement>(null);
  const lineCount = Math.max(1, code.split("\n").length);

  function syncScroll() {
    const ta = taRef.current; if (!ta) return;
    if (preRef.current) { preRef.current.scrollTop = ta.scrollTop; preRef.current.scrollLeft = ta.scrollLeft; }
    if (gutRef.current) gutRef.current.scrollTop = ta.scrollTop;
  }

  function onKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    const ta = e.currentTarget;
    const start = ta.selectionStart, end = ta.selectionEnd;
    if (e.key === "Tab") {
      e.preventDefault();
      if (e.shiftKey) {
        // dedent line start
        const lineStart = code.lastIndexOf("\n", start - 1) + 1;
        const removed = code.slice(lineStart).match(/^( {1,4}|\t)/);
        if (removed) {
          const n = removed[0].length;
          const next = code.slice(0, lineStart) + code.slice(lineStart + n);
          onChange(next);
          requestAnimationFrame(() => { ta.selectionStart = ta.selectionEnd = Math.max(lineStart, start - n); });
        }
      } else {
        const next = code.slice(0, start) + "    " + code.slice(end);
        onChange(next);
        requestAnimationFrame(() => { ta.selectionStart = ta.selectionEnd = start + 4; });
      }
    } else if (e.key === "Enter") {
      e.preventDefault();
      const lineStart = code.lastIndexOf("\n", start - 1) + 1;
      const curLine = code.slice(lineStart, start);
      const indent = (curLine.match(/^[ \t]*/) || [""])[0];
      const extra = /[:{[(]\s*$/.test(curLine.trimEnd()) ? "    " : "";
      const insert = "\n" + indent + extra;
      const next = code.slice(0, start) + insert + code.slice(end);
      onChange(next);
      requestAnimationFrame(() => { ta.selectionStart = ta.selectionEnd = start + insert.length; });
    }
  }

  return (
    <div className="ide">
      <div className="ide-gutter" ref={gutRef}>
        {Array.from({ length: lineCount }, (_, i) => <div key={i}>{i + 1}</div>)}
      </div>
      <div className="ide-code">
        <pre className="ide-hl" ref={preRef} aria-hidden="true"><code dangerouslySetInnerHTML={{ __html: highlightCode(code, language) }} /></pre>
        <textarea
          ref={taRef}
          className="ide-input"
          value={code}
          spellCheck={false}
          autoCapitalize="off"
          autoCorrect="off"
          onScroll={syncScroll}
          onKeyDown={onKeyDown}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Write your solution here…"
        />
      </div>
    </div>
  );
}

function CodingInput({ q, value, onChange, online }: { q: BundleQuestion; value: unknown; onChange: (v: unknown) => void; online: boolean }) {
  const code = (value as string) ?? q.meta.starter ?? "";
  const language = q.meta.language || "python";
  const languageId = q.meta.languageId;
  const languageLabel = q.meta.languageLabel || language;
  const [stdin, setStdin] = useState("");
  const [running, setRunning] = useState(false);
  const [out, setOut] = useState<{ ok: boolean; text: string; status?: string } | null>(null);

  async function run() {
    setRunning(true);
    setOut(null);
    try {
      const res = await api.runCode(code, language, stdin, languageId);
      const parts = [res.compileOutput, res.stderr, res.stdout].map((x) => (x || "").trim()).filter(Boolean);
      setOut({ ok: !(res.stderr || res.compileOutput), text: parts.join("\n\n") || "(no output)", status: res.status });
    } catch (e) {
      setOut({ ok: false, text: e instanceof Error ? e.message : "Couldn't run your code." });
    } finally {
      setRunning(false);
    }
  }

  // Program tried to read input but the stdin box was empty → surface a clear hint
  // instead of the cryptic EOFError / NoSuchElementException from the runner.
  const needsInput =
    !!out &&
    !out.ok &&
    !stdin.trim() &&
    /EOFError|EOF when reading|NoSuchElementException|InputMismatchException|unexpected end of input|end of file|Scanner|no line found/i.test(out.text);

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
        <div className="mono-label">{languageLabel} · your solution</div>
        <button className="btn btn-ghost btn-sm" onClick={() => void run()} disabled={running || !online || !code.trim()}>
          {running ? <Icon name="loader-circle" className="animate-spin" size={14} /> : <Icon name="play" size={14} />} {running ? "Running…" : "Run code"}
        </button>
      </div>
      <CodeEditor code={code} language={language} onChange={(v) => onChange(v)} />
      <div style={{ marginTop: 12 }}>
        <div className="mono-label" style={{ marginBottom: 4 }}>Custom input (stdin)</div>
        <div style={{ fontSize: 12, color: "var(--color-text-dim, #8ba0b8)", marginBottom: 6, lineHeight: 1.5 }}>
          If your program reads input (e.g. <code style={{ fontFamily: "var(--font-mono)" }}>input()</code>, <code style={{ fontFamily: "var(--font-mono)" }}>Scanner</code>, <code style={{ fontFamily: "var(--font-mono)" }}>scanf</code>), type the values here — one per line — before you press Run.
        </div>
        <textarea className="code-area" style={{ minHeight: 60 }} value={stdin} spellCheck={false} onChange={(e) => setStdin(e.target.value)} placeholder={"Type the input your program expects, e.g.\n5"} />
      </div>
      {!online && <div style={{ marginTop: 8, fontSize: 12.5, color: "var(--color-warn)" }}>Reconnect to run your code.</div>}
      {needsInput && (
        <div style={{ marginTop: 12, display: "flex", gap: 9, alignItems: "flex-start", background: "rgba(245,183,66,.12)", border: "1px solid rgba(245,183,66,.4)", borderRadius: 11, padding: "11px 13px" }}>
          <Icon name="info" size={15} style={{ marginTop: 1, color: "var(--color-warn, #f5b742)", flexShrink: 0 }} />
          <div style={{ fontSize: 12.8, lineHeight: 1.55 }}>
            Your program is waiting for input but none was provided. Type the value(s) it expects in the <b>Custom input (stdin)</b> box above, then press <b>Run code</b> again.
          </div>
        </div>
      )}
      {out && !needsInput && (
        <div style={{ marginTop: 12 }}>
          <div className="mono-label" style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 6 }}>
            <Icon name={out.ok ? "terminal" : "triangle-alert"} size={13} /> Output{out.status ? ` · ${out.status}` : ""}
          </div>
          <pre style={{ whiteSpace: "pre-wrap", fontFamily: "var(--font-mono)", fontSize: 13, background: "#0f1b2b", color: out.ok ? "#b7f7c8" : "#ffb4b4", padding: 14, borderRadius: 11, lineHeight: 1.55, margin: 0, maxHeight: 240, overflow: "auto" }}>{out.text}</pre>
        </div>
      )}
    </div>
  );
}

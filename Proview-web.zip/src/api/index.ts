import { Hono } from "hono";
import { cors } from "hono/cors";
import { compress } from "hono/compress";
import { eq, ne, and, or, desc, gte, inArray, like, sql as dsql } from "drizzle-orm";
import { auth } from "./auth";
import { hashPassword, verifyPassword } from "better-auth/crypto";
import { db, dbConfig, dbStats, runInLane } from "./database";
import * as schema from "./database/schema";
import { INDEX_STATE, REQUIRED_COLUMNS, REQUIRED_PERF_INDEXES, REQUIRED_UNIQUE_INDEXES } from "./database/invariants";
import { authCache, authMiddleware, requireAuth, requireSuperAdmin, requirePermission } from "./middleware/auth";
import type { SessionUser, ProfileCtx } from "./middleware/auth";
import { id, displayId, computeYear, effectiveEndMs } from "./lib/util";
import { generateQuestions, gradeSubjective } from "./lib/ai";
import { finalizeAttempt, hasContent } from "./lib/grade-queue";
import { presignPut, presignGetCached, getObject } from "./lib/s3";
import { signStudentToken, verifyStudentToken } from "./lib/student-token";
import { normalizeRoll, rollNoProblem, isDuplicateRollError } from "./lib/students";
import { recordMonitorBuild, monitorTiming, recentExamChecks, failingExamChecks, checkExamData, MONITOR_POLL_MS, MONITOR_BUDGET_MS } from "./lib/watchdog";
import { OPTION_ORDER_TOKEN, optionTranslator, tokenIsCurrent } from "./lib/option-order";
import { judge0Queue, resolveJudge0Config } from "./lib/judge0-queue";
import { isEligible, matchesCohort, loadRoster, loadRosters, ensureOptInOnlyLoaded, invalidateOptInOnlyCache, isOptInOnlyCode } from "./lib/roster";
import { TtlCache } from "./lib/ttl-cache";
import { heartbeats } from "./lib/heartbeat-queue";
import { integrityRollup } from "./lib/integrity-rollup";
import { attemptOwners } from "./lib/attempt-owner";
import { attemptTenants, concurrencyGate, evidenceMeter, resolveLimit, tenantQuotas } from "./lib/tenant-quota";
import { EMPTY_ROLLUP, loadAttemptRollups, rollupAvg } from "./lib/report-rollup";
import { TenantDirectory } from "./lib/tenant-directory";
import { createBulkStudentPasswords } from "./lib/bulk-student-passwords";
import { bulkResetHandler } from "./routes/bulk-student-passwords";
import { examEffStatus, isConcluded, isReportable, toMs, type StatusExam } from "./lib/exam-status";

type Vars = { user: SessionUser | null; profile: ProfileCtx | null };

/* ---------------------------------------------------------------------------
 * Read caches for the rows that 1000 students read simultaneously.
 *
 * The database is remote (Turso over HTTP), so every `await db.…` is a network
 * round trip. During an exam the client fleet re-reads the same handful of
 * admin-authored rows over and over — the exam row on every 15s heartbeat, the
 * exam's question list on every autosave, the single global settings row on every
 * bundle fetch and code run. At 1000 students that is hundreds of identical
 * queries a second for rows that change a couple of times an hour, and it is
 * what stopped pages from loading.
 *
 * TtlCache also coalesces concurrent misses, so a thundering herd on one exam id
 * collapses into ONE query rather than 67. Only admin-authored data is cached;
 * per-attempt state a student is actively mutating (answers, attempt status) is
 * always read live. Writes invalidate their key so an admin action still lands
 * immediately instead of waiting out the TTL.
 * ------------------------------------------------------------------------- */
/** Settings are edited from one admin screen; 5s stale is invisible there. */
const SETTINGS_CACHE_MS = 5_000;
/** Holds/extra time must reach students fast, and the heartbeat is 15s anyway. */
const EXAM_CACHE_MS = 3_000;
/** An exam's question set is frozen for the duration of the exam in practice. */
const EXAM_QUESTIONS_CACHE_MS = 30_000;

type SettingsRow = typeof schema.settings.$inferSelect;
type ExamRow = typeof schema.exams.$inferSelect;
type TranslatorQuestion = { id: string; type: string; options: unknown };

const settingsCache = new TtlCache<SettingsRow>(SETTINGS_CACHE_MS);
const examCache = new TtlCache<ExamRow | null>(EXAM_CACHE_MS);
const examQuestionsCache = new TtlCache<{ questionIds: string[]; questions: TranslatorQuestion[] }>(
  EXAM_QUESTIONS_CACHE_MS,
);

/**
 * The admin side has the same round-trip problem the student side had, for a
 * different reason: nine staff endpoints (/dashboard, /reports, /reports/:examId,
 * /monitor, the roster pickers) each OPENED by reading the tenant's entire
 * students table plus the entire classes table, just to turn a studentId into a
 * name and a classId into a section code. Measured on prod that was 7.9 SQL
 * statements per admin request against 2.23 for the tuned student path.
 *
 * Students and classes are admin-authored and change on a human timescale, and
 * every write below invalidates its tenant, so the only staleness a real operator
 * can observe is a concurrent edit by a DIFFERENT admin landing up to 15s late on
 * a dashboard. Worth it to stop re-reading 1,124 rows per page load.
 */
const DIRECTORY_CACHE_MS = 15_000;

type StudentRow = typeof schema.students.$inferSelect;
type ClassRow = typeof schema.classes.$inferSelect;

const directory = new TenantDirectory<StudentRow, ClassRow>({
  ttlMs: DIRECTORY_CACHE_MS,
  loadStudents: (tid) => db.select().from(schema.students).where(eq(schema.students.tenantId, tid)),
  loadClasses: (tid) => db.select().from(schema.classes).where(eq(schema.classes.tenantId, tid)),
});

/** Platform-global settings live in a single row (id = "global"). */
const GLOBAL_SETTINGS = "global";
async function getGlobalSettings() {
  return settingsCache.load(GLOBAL_SETTINGS, async () => {
    let [s] = await db.select().from(schema.settings).where(eq(schema.settings.id, GLOBAL_SETTINGS));
    if (!s) [s] = await db.insert(schema.settings).values({ id: GLOBAL_SETTINGS }).returning();
    return s;
  });
}
/** Call after writing the settings row so the next read is authoritative. */
function invalidateGlobalSettings() {
  settingsCache.invalidate(GLOBAL_SETTINGS);
}

/**
 * Exam row for the student polling paths (heartbeat / status).
 *
 * Deliberately NOT used by /start, /submit or any admin write: those must decide
 * against live state. Returns null (a cached negative) for an unknown id so a bogus
 * examId cannot be used to hammer the database.
 */
async function getExamForPolling(eid: string): Promise<ExamRow | null> {
  return examCache.load(eid, async () => {
    const [exam] = await db.select().from(schema.exams).where(eq(schema.exams.id, eid)).limit(1);
    return exam ?? null;
  });
}
/** Call whenever an exam row changes (hold, resume, extra time, edit, delete). */
function invalidateExam(eid: string) {
  examCache.invalidate(eid);
  invalidateStudentExamLists();
}

/**
 * The exam's question ids plus the fields option-order translation needs.
 *
 * One cached read now serves what used to be three separate queries per autosave
 * (the valid-question check, and the translator's own two reads).
 */
async function getExamQuestionSet(examId: string) {
  return examQuestionsCache.load(examId, async () => {
    const eqs = await db
      .select({ questionId: schema.examQuestions.questionId })
      .from(schema.examQuestions)
      .where(eq(schema.examQuestions.examId, examId));
    const questionIds = eqs.map((e) => e.questionId);
    const questions = questionIds.length
      ? await db
          .select({ id: schema.questions.id, type: schema.questions.type, options: schema.questions.options })
          .from(schema.questions)
          .where(inArray(schema.questions.id, questionIds))
      : [];
    return { questionIds, questions };
  });
}
/** Call when an exam's question set or a question's options change. */
function invalidateExamQuestions(examId: string) {
  examQuestionsCache.invalidate(examId);
  examPaperCache.invalidate(examId);
}

/**
 * The full paper for one exam: its exam_questions rows in order plus the question
 * rows. Identical for every student, and read by /bundle (every student at the
 * start bell) and by submit (every student at the final bell) — 2 statements each,
 * ~2,200 times inside a couple of minutes, for data that does not change during an
 * exam. Server-side only: it contains the answer key and is never sent as-is.
 * Same 30s TTL and invalidation as the question-set cache above.
 */
type ExamQuestionRow = typeof schema.examQuestions.$inferSelect;
type QuestionRow = typeof schema.questions.$inferSelect;
const examPaperCache = new TtlCache<{ eqs: ExamQuestionRow[]; qs: QuestionRow[] }>(EXAM_QUESTIONS_CACHE_MS);
async function getExamPaper(examId: string) {
  return examPaperCache.load(examId, async () => {
    const eqs = await db.select().from(schema.examQuestions).where(eq(schema.examQuestions.examId, examId)).orderBy(schema.examQuestions.order);
    const qids = eqs.map((q) => q.questionId);
    const qs = qids.length ? await db.select().from(schema.questions).where(inArray(schema.questions.id, qids)) : [];
    return { eqs, qs };
  });
}

/**
 * Tenant-wide half of the student dashboard (/student/exams): the tenant's exams,
 * their roster overrides and question counts. Every waiting student polls this
 * every 15s and ALL of them refetch at the exam's start time, and it is identical
 * for everyone in the college — 3 of the endpoint's 5 statements. Cached 5s;
 * dropped on any exam or roster write so an admin change still shows at once.
 */
const STUDENT_EXAM_LIST_CACHE_MS = 5_000;
type ExamListBase = { exams: ExamRow[]; rosters: Map<string, import("./lib/roster").Roster>; questionCounts: Map<string, number> };
const studentExamListCache = new TtlCache<ExamListBase>(STUDENT_EXAM_LIST_CACHE_MS);
async function getStudentExamListBase(tenantId: string): Promise<ExamListBase> {
  return studentExamListCache.load(tenantId, async () => {
    const exams = await db
      .select()
      .from(schema.exams)
      .where(and(eq(schema.exams.tenantId, tenantId), inArray(schema.exams.status, ["scheduled", "live", "finished"])))
      .orderBy(desc(schema.exams.createdAt));
    const ids = exams.map((e) => e.id);
    const rosters = await loadRosters(ids);
    const counts = ids.length
      ? await db
          .select({ examId: schema.examQuestions.examId, n: dsql<number>`count(*)` })
          .from(schema.examQuestions)
          .where(inArray(schema.examQuestions.examId, ids))
          .groupBy(schema.examQuestions.examId)
      : [];
    return { exams, rosters, questionCounts: new Map(counts.map((r) => [r.examId, Number(r.n)])) };
  });
}
/** Call after any write to exams or exam_roster. Rare, so it simply drops all tenants. */
function invalidateStudentExamLists() {
  studentExamListCache.clear();
}

/**
 * One finalize per attempt at a time in this process. When the database is slow
 * the client's 20s timeout fires while the server is still grading, and the client
 * retries — so a single student could have two or three identical finalizes
 * running, each paying the full statement cost, exactly when the database can
 * least afford it. A repeat now waits for the one already running and returns its
 * answer. (Across processes the existing idempotent upserts still apply.)
 */
const submitsInFlight = new Map<string, Promise<{ score: number; status: "submitted" | "graded"; gradeAt: number | null }>>();

// Resolve the tenant for the public registration page from a URL code.
// Accepts (case-insensitive) the college short code (shortName), the slug, or the raw tenant id.
async function resolveRegisterTenant(codeRaw: string) {
  const code = String(codeRaw ?? "").trim();
  if (!code) return null;
  const lower = code.toLowerCase();
  const [byCode] = await db
    .select()
    .from(schema.tenants)
    .where(
      and(
        eq(schema.tenants.enabled, true),
        or(
          dsql`lower(${schema.tenants.shortName}) = ${lower}`,
          dsql`lower(${schema.tenants.slug}) = ${lower}`,
          eq(schema.tenants.id, code),
        ),
      ),
    );
  return byCode ?? null;
}

// ---- Proctoring evidence ----
// Persist integrity/violation events reported by the running student client
// (camera loss, tab switch, fullscreen exit, blocked copy/paste, extra monitor…).
// The client flushes events the moment they happen AND resends the full list at
// submit as a backstop, so we dedupe on (type, at) against what's already stored.
// `photoKey` is the object-storage key of the webcam snapshot captured at that
// moment; it is only accepted inside this attempt's own prefix.
const INTEGRITY_PREFIX = (attemptId: string) => `integrity/${attemptId}/`;

// Timed camera frames: evidence, not misconduct. They belong in the Snapshots
// trail and must never inflate a violation count.
const FRAME_EVENT_TYPES = ["periodic_snapshot", "preflight_snapshot"] as const;
const isFrameEvent = (t: string) => (FRAME_EVENT_TYPES as readonly string[]).includes(t);
// Informational rows that belong on the integrity timeline (a reviewer wants to
// see when a blocked camera view cleared) but are not themselves violations.
// `camera_block_dismissed` is retired: it was the student's own claim that the room
// was merely dim, written when a covered lens was dismissable after 60s. Covering the
// lens now locks the exam outright and nothing emits this type any more. It stays in
// this set so the rows already in the table keep scoring the way they did when they
// were written — it was context for the `camera_obstructed` row that always precedes
// it, not a second offence, and counting it now would retroactively double-count a
// single episode for students who sat the exam under the old rule.
// `focus_loss` is window.blur, which fires for things the student does not control:
// an OS/antivirus/notification toast stealing focus. Measured live, 36 attempts logged
// it on a near-perfect 60s cadence (median gap 60.0s, each machine with its own fixed
// second-offset) while `tab_switch` fired only twice overall — i.e. the tab never left
// the foreground. Counting it produced ~15 phantom violations an hour for students who
// did nothing wrong, so it stays on the timeline as context but no longer scores.
// Real tab/app switching is still caught by `tab_switch` (visibilitychange).
// `snapshot_failed` is the client reporting that a timed capture produced no frame —
// a dead/absent webcam, a permission the browser never really granted, or an upload
// that never landed. It exists so a camera that never worked leaves a trail instead of
// silence (before it, "camera dead all exam" and "camera fine" were byte-identical in
// this table). It must NEVER score: it is a device fault the student may not even be
// able to see, and counting it would mark a broken laptop as cheating — roughly 18 rows
// per 90-minute exam at its 5-minute throttle, which would swamp every real violation.
// "evidence_capped" is the single marker written when a tenant's stored-evidence
// ceiling stops further frames (lib/tenant-quota.ts). It is a platform decision,
// not student behaviour, so like snapshot_failed it must never score.
const NON_VIOLATION_TYPES = new Set<string>([...FRAME_EVENT_TYPES, "camera_restored", "camera_block_dismissed", "focus_loss", "snapshot_failed", "evidence_capped"]);

type RawIntegrityEvent = { type?: unknown; detail?: unknown; at?: unknown; photoKey?: unknown; photoUrl?: unknown };

async function persistIntegrityEvents(attemptId: string, raw: unknown): Promise<number> {
  if (!Array.isArray(raw) || raw.length === 0) return 0;
  const incoming = (raw as RawIntegrityEvent[]).slice(0, 300);

  // Existing (type|at) keys for this attempt so a resend can't double-insert.
  //
  // Bounded to `at >= the oldest incoming event`: nothing older than that can
  // possibly collide with this batch, and by the end of a 90-minute exam an attempt
  // has hundreds of rows (a snapshot every 27s) that the every-10s flush was
  // re-reading in full. `integrity_attempt_at_idx` makes this a narrow range scan.
  const incomingAtMs = incoming
    .map((ev) => Number(ev?.at))
    .filter((ms) => Number.isFinite(ms) && ms > 0);
  const sinceMs = incomingAtMs.length ? Math.min(...incomingAtMs) : 0;
  const existing = await db
    .select({ type: schema.integrityEvents.type, at: schema.integrityEvents.at })
    .from(schema.integrityEvents)
    .where(
      sinceMs > 0
        ? and(eq(schema.integrityEvents.attemptId, attemptId), gte(schema.integrityEvents.at, new Date(sinceMs)))
        : eq(schema.integrityEvents.attemptId, attemptId),
    );
  const seen = new Set(existing.map((e) => `${e.type}|${new Date(e.at).getTime()}`));

  const rows: { id: string; attemptId: string; type: string; detail: string | null; photoUrl: string | null; at: Date }[] = [];
  for (const ev of incoming) {
    const type = String(ev?.type ?? "").trim().slice(0, 40);
    if (!type) continue;
    const atMs = Number(ev?.at);
    const at = Number.isFinite(atMs) && atMs > 0 ? atMs : Date.now();
    const key = `${type}|${at}`;
    if (seen.has(key)) continue;
    seen.add(key);
    const detailRaw = ev?.detail == null ? "" : String(ev.detail).trim().slice(0, 300);
    const photoRaw = String(ev?.photoKey ?? ev?.photoUrl ?? "").trim();
    const photoUrl = photoRaw.startsWith(INTEGRITY_PREFIX(attemptId)) ? photoRaw.slice(0, 300) : null;
    rows.push({ id: id("iev"), attemptId, type, detail: detailRaw || null, photoUrl, at: new Date(at) });
  }
  if (rows.length === 0) return 0;

  // ---- Per-tenant stored-evidence ceiling (lib/tenant-quota.ts) ----
  // Bounds the one table that is kept forever by decision. VIOLATIONS ARE NEVER
  // TRIMMED — only periodic frames and device-fault rows are, and a single
  // `evidence_capped` marker records why they stop, so the silence §34 was
  // written to eliminate does not come back through the quota door.
  //
  // The whole block is skipped, at zero query cost, unless a ceiling is actually
  // configured: the settings row is already cached in-process, and the
  // "any tenant override at all?" question is one cached count a minute.
  let toInsert = rows;
  const gsQuota = await getGlobalSettings();
  const capPossible =
    resolveLimit(gsQuota.maxEvidencePerAttempt, null) !== null || (await tenantQuotas.overridesExist(db));
  if (capPossible) {
    const capTenant = await attemptTenants.load(db, attemptId);
    const cap = capTenant ? (await tenantQuotas.load(db, capTenant, gsQuota)).maxEvidencePerAttempt : null;
    if (cap !== null) {
      const room = await evidenceMeter.room(db, attemptId, cap, NON_VIOLATION_TYPES);
      const kept: typeof rows = [];
      let evidenceKept = 0;
      let dropped = 0;
      for (const r of rows) {
        if (!NON_VIOLATION_TYPES.has(r.type)) {
          kept.push(r); // misconduct: stored regardless of any ceiling
          continue;
        }
        if (evidenceKept < room) {
          kept.push(r);
          evidenceKept += 1;
          continue;
        }
        dropped += 1;
      }
      // One marker per attempt per process. It is itself an evidence type, so a
      // later reseed counts it and the ceiling engages one row earlier — a
      // one-row drift, deliberately not worth a second counter.
      if (dropped > 0 && evidenceMeter.noticeOnce(attemptId)) {
        kept.push({ id: id("iev"), attemptId, type: "evidence_capped", detail: `stored-evidence ceiling ${cap} reached`, photoUrl: null, at: new Date() });
      }
      evidenceMeter.add(attemptId, evidenceKept);
      toInsert = kept;
    }
  }
  if (toInsert.length === 0) return 0;
  // Chunked insert — SQLite/libSQL caps bound variables per statement.
  for (let i = 0; i < toInsert.length; i += 50) {
    await db.insert(schema.integrityEvents).values(toInsert.slice(i, i + 50));
  }
  return toInsert.length;
}

/**
 * Build the per-student option-order translator for one exam.
 *
 * `clientToken` is the scheme token the client reports (it came from the bundle it
 * rendered). When it is missing or from an older build, the translator is inert
 * and every index is passed through unchanged — that client is looking at the
 * ORIGINAL option order, so its indices are already original.
 *
 * Only loads the question rows when translation is actually active, so the
 * autosave path (called on every single answer) costs nothing extra for clients
 * that don't need it.
 */
async function answerTranslator(examId: string, studentId: string, clientToken: unknown) {
  if (!tokenIsCurrent(clientToken)) return optionTranslator(studentId, examId, [], false);
  const { questions } = await getExamQuestionSet(examId);
  return optionTranslator(studentId, examId, questions, true);
}

/** Find a student in a tenant by roll number, ignoring case and padding. */
async function findStudentByRoll(tid: string, roll: string) {
  const [row] = await db
    .select({ id: schema.students.id, rollNo: schema.students.rollNo, name: schema.students.name })
    .from(schema.students)
    .where(and(eq(schema.students.tenantId, tid), dsql`upper(trim(${schema.students.rollNo})) = ${roll}`))
    .limit(1);
  return row ?? null;
}

/**
 * Live Monitor payload, built once per tenant and shared between callers.
 *
 * Extracted from the route handler so the result can be cached and so concurrent
 * invigilators coalesce onto a single build. See getMonitorSnapshot below.
 */
async function buildMonitorSnapshot(tid: string) {
  const now = Date.now();
  // An exam is effectively live when its DB status is "live", OR when it is
  // still "scheduled" but its start time has already passed (students can start
  // it at that point). This mirrors the "LIVE / In progress" badge on the
  // Schedule Assessment list, which is derived the same way. Without this, a
  // scheduled exam whose start time passed would show as live on the list but
  // never appear in the Live Monitor.
  const startMs = (e: { startAt: Date | number | string | null }) => {
    if (e.startAt == null) return null;
    const ms = typeof e.startAt === "number" ? e.startAt : new Date(e.startAt).getTime();
    return Number.isNaN(ms) ? null : ms;
  };
  const dbLive = await db.select().from(schema.exams).where(and(eq(schema.exams.tenantId, tid), eq(schema.exams.status, "live")));
  const scheduled = await db
    .select()
    .from(schema.exams)
    .where(and(eq(schema.exams.tenantId, tid), eq(schema.exams.status, "scheduled")))
    .orderBy(schema.exams.startAt);
  const startedScheduled = scheduled.filter((e) => {
    const ms = startMs(e);
    return ms !== null && now >= ms;
  });
  // An exam is OVER once its window (endAt + any admin extra time + total hold
  // time) has fully elapsed. A currently-held exam is paused, not over. Over
  // exams must drop off the Live Monitor entirely — there is nothing live.
  const isOver = (e: { endAt: number | string | Date | null; extraMin?: number | null; holdMs?: number | null; heldAt?: number | string | Date | null }) => {
    if (e.heldAt) return false;
    if (e.endAt == null) return false;
    const end = e.endAt instanceof Date ? e.endAt.getTime() : typeof e.endAt === "number" ? e.endAt : new Date(e.endAt).getTime();
    if (Number.isNaN(end)) return false;
    const extra = (e.extraMin ?? 0) * 60_000 + (e.holdMs ?? 0);
    return now > end + extra;
  };
  const liveExams = [...dbLive, ...startedScheduled].filter((e) => !isOver(e));

  // Next scheduled exam (for empty-state messaging when nothing is live).
  let nextScheduled: { examId: string; title: string; startAt: number | null } | null = null;
  if (!liveExams.length) {
    const upcoming = scheduled
      .filter((e) => {
        const ms = startMs(e);
        return ms !== null && ms >= now;
      })
      .sort((a, b) => startMs(a)! - startMs(b)!)[0];
    if (upcoming) nextScheduled = { examId: upcoming.id, title: upcoming.title, startAt: startMs(upcoming) };
  }

  // Students and classes for the tenant, served from the shared directory cache
  // (see TenantDirectory above) so a 5s monitor poll does not re-read ~1200 rows:
  //   * `studentById` resolves an attempt's student name/roll. It must include
  //     disabled students because someone can be disabled mid-term while their
  //     attempt still exists. Resolving from this map instead of querying per
  //     attempt turns ~1200 round trips into one.
  //   * `allStudents` (enabled only) is the assignable cohort, used to work out
  //     who has not started yet.
  const studentIdx = await directory.studentIndex(tid);
  const studentById = studentIdx.byId;
  const allStudents = studentIdx.enabled;
  // Resolve a student's classId to a readable section code (e.g. "CSE-C").
  const classCodeById = (await directory.classIndex(tid)).codeById;
  const sectionOf = (classId: string | null) => (classId ? classCodeById.get(classId) ?? "" : "");
  const liveRosters = await loadRosters(liveExams.map((e) => e.id));
  const assignedStudents = (e: { id: string; classId: string | null; sectionIds: string[] | null }) =>
    allStudents.filter((stu) => isEligible(e, stu, liveRosters.get(e.id)));

  const out = await Promise.all(
    liveExams.map(async (ex) => {
      // Only the columns this view uses. A full attempt row carries the 300-char
      // user agent and more; at 1,100 students on a 5s poll that was ~0.5 MB read
      // from the database per build for nothing.
      const atts = await db
        .select({
          id: schema.attempts.id,
          studentId: schema.attempts.studentId,
          status: schema.attempts.status,
          lastSeenAt: schema.attempts.lastSeenAt,
          startedAt: schema.attempts.startedAt,
          submittedAt: schema.attempts.submittedAt,
          score: schema.attempts.score,
        })
        .from(schema.attempts)
        .where(eq(schema.attempts.examId, ex.id));
      // Everyone who has engaged with the exam (in progress or already submitted/graded).
      const engaged = atts.filter((a) => a.status !== "not_started");
      // Proctoring evidence per attempt: violation count + newest snapshot key.
      //
      // PERFORMANCE — this is what used to hang the Live Monitor, twice over.
      // First it SELECTed every integrity_events row for every engaged attempt and
      // aggregated in JS: 27,153 rows (~1.7 MB of photo keys) per 5s poll on "Elite
      // Assessment - 1", doubled with two exams live, so a poll outlasted the poll
      // interval and the page froze. That became two grouped statements, which was
      // far better but still TOUCHED every event row of every engaged attempt on
      // every build - a cost that grows with exam duration x watch time.
      //
      // Now the aggregate is carried forward and only rows inserted since the last
      // build are read, off the `rowid` watermark. Evidence is monotonic, so that is
      // exact; see lib/integrity-rollup.ts for why the watermark lives in the
      // database rather than in a counter here, and what deletes do to it.
      const evAgg = await integrityRollup.load(db, ex.id, NON_VIOLATION_TYPES, now);
      const enriched = await Promise.all(
        engaged.map(async (a) => {
          const stu = studentById.get(a.studentId);
          const status = a.status === "in_progress" ? "in_progress" : "finished";
          // Online = a heartbeat within the last 40s (heartbeat interval is ~15s).
          // Heartbeats are coalesced and written every 5s, so the freshest ping for
          // this attempt may not be in the row we just read — overlay whatever is
          // still pending in this process, which makes the dot MORE accurate than
          // the database (zero staleness) rather than less.
          const pendingSeen = heartbeats.peekSeen(a.id);
          const lastSeenMs = Math.max(
            a.lastSeenAt ? new Date(a.lastSeenAt).getTime() : 0,
            pendingSeen ?? 0,
          );
          const online = a.status === "in_progress" && lastSeenMs > 0 && now - lastSeenMs < 40_000;
          const agg = evAgg.get(a.id);
          // `snapshot` is kept in the payload for compatibility but no longer
          // signed: the Live Monitor page never displays it (the drawer loads
          // evidence from the reports endpoint), and signing a fresh URL for every
          // student's newest frame cost ~0.35 ms of CPU each — on the single
          // thread that also answers students — plus ~460 bytes per row.
          const snapshot: string | null = null;
          return {
            attemptId: a.id,
            examId: ex.id,
            student: stu?.name ?? "—",
            rollNo: stu?.rollNo ?? "",
            section: sectionOf(stu?.classId ?? null),
            status,
            online,
            lastSeenAt: lastSeenMs > 0 ? new Date(lastSeenMs) : a.lastSeenAt,
            startedAt: a.startedAt,
            submittedAt: a.submittedAt,
            score: a.status === "graded" ? a.score : null,
            graded: a.status === "graded",
            snapshot,
            violations: agg?.violations ?? 0,
          };
        }),
      );
      // Assigned students who have not started. If the exam window has closed
      // (now > endAt) they never showed up → "absent"; otherwise they can still
      // begin → "not_started".
      const endMs = ex.endAt ? new Date(ex.endAt).getTime() : null;
      const windowClosed = endMs !== null && !Number.isNaN(endMs) && now > endMs;
      const engagedStudentIds = new Set(engaged.map((a) => a.studentId));
      const notStarted = assignedStudents(ex)
        .filter((stu) => !engagedStudentIds.has(stu.id))
        .map((stu) => ({
          attemptId: `ns-${stu.id}`,
          examId: ex.id,
          student: stu.name ?? "—",
          rollNo: stu.rollNo ?? "",
          section: sectionOf(stu.classId ?? null),
          status: (windowClosed ? "absent" : "not_started") as "absent" | "not_started",
          online: false,
          lastSeenAt: null as string | null,
          startedAt: null as string | null,
          submittedAt: null as string | null,
          snapshot: null as string | null,
          violations: 0,
        }));
      const absentCount = windowClosed ? notStarted.length : 0;
      return {
        examId: ex.id,
        title: ex.title,
        held: !!ex.heldAt,
        heldAt: ex.heldAt,
        extraMin: ex.extraMin ?? 0,
        active: engaged.filter((a) => a.status === "in_progress").length,
        online: enriched.filter((s) => s.online).length,
        submitted: engaged.filter((a) => a.status !== "in_progress").length,
        notStarted: windowClosed ? 0 : notStarted.length,
        absent: absentCount,
        students: [...enriched, ...notStarted],
      };
    }),
  );
  return { live: out, nextScheduled };
}

/** How long a built snapshot may be reused. Well under the 5s client poll. */
const MONITOR_CACHE_MS = 3000;
type MonitorSnapshot = Awaited<ReturnType<typeof buildMonitorSnapshot>>;
const monitorCache = new Map<string, { at: number; data: MonitorSnapshot }>();
const monitorInFlight = new Map<string, Promise<MonitorSnapshot>>();

async function getMonitorSnapshot(tid: string): Promise<MonitorSnapshot> {
  const cached = monitorCache.get(tid);
  if (cached && Date.now() - cached.at < MONITOR_CACHE_MS) return cached.data;

  // A build is already running for this tenant: join it instead of starting a
  // second identical one. Without this, five open monitor tabs meant five
  // concurrent full scans of attempts + integrity_events every 5 seconds.
  const running = monitorInFlight.get(tid);
  if (running) return running;

  // Time every real build. This is the freeze early-warning: the incident was a
  // build that grew past the 5s poll interval until polls stacked. The watchdog
  // logs it and flags the payload as soon as builds cross half the interval, so
  // it is visible on the invigilator's own screen during the exam.
  const startedAt = Date.now();
  const task = buildMonitorSnapshot(tid)
    .then((data) => {
      const rows = data.live.reduce((n, ex) => n + ex.students.length, 0);
      recordMonitorBuild(Date.now() - startedAt, rows);
      monitorCache.set(tid, { at: Date.now(), data });
      return data;
    })
    .finally(() => {
      monitorInFlight.delete(tid);
    });
  monitorInFlight.set(tid, task);
  return task;
}

const bulkStudentPasswords = createBulkStudentPasswords({
  db,
  secret: () => process.env.BETTER_AUTH_SECRET ?? "",
  invalidate: (tenantId) => directory.invalidateStudents(tenantId),
});

/**
 * Which database lane a request runs on (see database/lanes.ts). The exam client's
 * own calls, student login and public self-registration ride the student lane;
 * everything else is the staff console. Background work (grading, sweeps, the
 * heartbeat flusher) runs outside any request and lands on the background lane.
 */
const STUDENT_LANE_PATH = /^\/api\/(student\/|students\/verify-login$|register\/)/;

const app = new Hono<{ Variables: Vars }>()
  .use((c, next) => runInLane(STUDENT_LANE_PATH.test(c.req.path) ? "student" : "admin", next))
  .use(cors({ origin: (origin) => origin ?? "*", credentials: true, exposeHeaders: ["set-auth-token"] }))
  // gzip JSON responses over 1 KB. The Live Monitor answered every 5s poll with
  // ~294 KB of uncompressed JSON per open tab (~22 KB gzipped), and the student
  // list ~281 KB (~25 KB). Small student calls stay under the threshold untouched.
  .use(compress({ encoding: "gzip" }))
  .on(["GET", "POST"], "/api/auth/*", (c) => {
    // A sign-out must not stay honoured by the identity cache for its TTL.
    if (/sign-out|revoke/.test(c.req.path)) authCache.invalidate();
    return auth.handler(c.req.raw);
  })
  .basePath("api")
  .use("*", authMiddleware)
  // Any write to an exam, its roster or a registration can change what a student's
  // dashboard should show; drop the short exam-list cache after every such write
  // (see getStudentExamListBase). One rule here instead of a call in each handler,
  // so a future roster endpoint cannot forget it.
  .use("*", async (c, next) => {
    await next();
    if (c.req.method !== "GET" && /^\/api\/(exams|reports\/[^/]+\/roster|register\/)/.test(c.req.path)) {
      invalidateStudentExamLists();
    }
  })
  .all("/rpc/*", requireAuth, requirePermission("users"), async (c) => {
    const result = await bulkResetHandler.handle(c.req.raw, {
      prefix: "/api/rpc",
      context: { profile: c.get("profile"), service: bulkStudentPasswords },
    });
    return result.response ?? c.json({ message: "Not found" }, 404);
  })
  // Health doubles as the visibility surface for the database uniqueness
  // guarantees asserted at boot. If a required unique index could not be put in
  // place, duplicate rows can silently corrupt scores again — so that must be
  // observable from outside the process, not buried in a startup log. Returns
  // 503 in that state so uptime monitoring actually catches it.
  .get("/health", (c) => {
    const inv = INDEX_STATE;
    const monitor = monitorTiming();
    const badExams = failingExamChecks();
    if (inv.checkedAt && !inv.ok) {
      return c.json({ status: "degraded", invariants: inv, monitor, examChecks: badExams }, 503);
    }
    // A slow Live Monitor or an exam that finished with bad data is reported but
    // does NOT 503: the exam server is still serving students correctly and must
    // stay in the load balancer. It shows up as "warn" for whoever is looking.
    const warn = monitor.degraded || badExams.length > 0;
    return c.json(
      {
        status: warn ? "warn" : "ok",
        invariants: { ok: inv.ok, checkedAt: inv.checkedAt },
        monitor,
        examChecks: badExams,
        // Statements sent to the remote database since boot, plus what the read
        // caches are holding. The scale incident was a round-trip problem, so this
        // is the number to watch during an exam: divide the delta by the requests
        // served and you have the cost per request.
        db: {
          queries: dbStats.queries,
          // Connection layer: per-lane statements in flight (running + queued),
          // the peak since boot, statements that hit the deadline, and the slowest
          // statement in the last minute. A lane whose `pending` keeps climbing is
          // the database falling behind; `timeouts` rising means it stopped answering.
          lanes: dbStats.lanes,
          config: dbConfig,
          cached: {
            settings: settingsCache.size,
            exams: examCache.size,
            examQuestions: examQuestionsCache.size,
            // Tenants whose student/class directory is warm. Admin pages used to
            // re-read the whole students table per request; these two counters are
            // how you tell the directory cache is actually being hit.
            directoryStudents: directory.stats().students,
            directoryClasses: directory.stats().classes,
          },
        },
      },
      200,
    );
  })

  // Full uniqueness/consistency audit of the live database. Admin-only, run on
  // demand or from a scheduled check: confirms the unique indexes exist AND that
  // no duplicate rows or impossible scores have appeared. Cheap enough to poll.
  .get("/admin/invariants", requireAuth, requireSuperAdmin, async (c) => {
    const indexes = await Promise.all(
      REQUIRED_UNIQUE_INDEXES.map(async (spec) => {
        // GROUP BY every column in the spec, not the first two. This used to be
        // `const [a, b] = spec.columns`, which assumed every unique index was a
        // two-column one; a single-column spec (grade_jobs_attempt_uq) made `b`
        // undefined, and `dsql.raw(undefined)` throws — 500ing this whole audit
        // endpoint. Same fix as countDuplicateGroups in invariants.ts.
        const groupBy = spec.columns.join(", ");
        const present = (await db.all<{ name: string }>(
          dsql`SELECT name FROM sqlite_master WHERE type='index' AND name=${spec.name}`,
        )).length > 0;
        const dupes = Number((await db.all<{ c: number }>(
          dsql`SELECT COUNT(*) AS c FROM (SELECT 1 FROM ${dsql.raw(spec.table)} GROUP BY ${dsql.raw(groupBy)} HAVING COUNT(*) > 1)`,
        ))[0]?.c ?? 0);
        return { index: spec.name, table: spec.table, columns: spec.columns, present, duplicateGroups: dupes, guards: spec.guards };
      }),
    );
    // Additive columns `schema.ts` depends on. A missing one is worse than a missing
    // index — every query on the table would fail — so it is reported alongside them.
    const columns = await Promise.all(
      REQUIRED_COLUMNS.map(async (spec) => {
        const present = Number((await db.all<{ c: number }>(
          dsql`SELECT COUNT(*) AS c FROM pragma_table_info(${spec.table}) WHERE name = ${spec.column}`,
        ))[0]?.c ?? 0) > 0;
        return { table: spec.table, column: spec.column, type: spec.type, present, guards: spec.guards };
      }),
    );
    // Performance indexes. Informational: a missing one makes the app slow, not
    // wrong, so it is reported but deliberately kept out of `ok`. It still has to be
    // verifiable from outside the process — nothing in the deploy path runs a
    // migration, so this is how we confirm a deploy actually created them.
    const perfIndexes = await Promise.all(
      REQUIRED_PERF_INDEXES.map(async (spec) => {
        const present = (await db.all<{ name: string }>(
          dsql`SELECT name FROM sqlite_master WHERE type='index' AND name=${spec.name}`,
        )).length > 0;
        return { index: spec.name, table: spec.table, columns: spec.columns, present, guards: spec.guards };
      }),
    );
    const impossible = Number((await db.all<{ c: number }>(
      dsql`SELECT COUNT(*) AS c FROM attempts WHERE score > 100 OR score < 0`,
    ))[0]?.c ?? 0);
    // A graded attempt whose answer max_score total differs from its paper total
    // is the signature of the duplicate bug (inflated) or of lost rows (deflated).
    const denomMismatch = Number((await db.all<{ c: number }>(
      dsql`SELECT COUNT(*) AS c FROM attempts a JOIN exams e ON e.id = a.exam_id
           WHERE a.status IN ('graded','submitted')
             AND (SELECT COALESCE(SUM(COALESCE(x.max_score,0)),0) FROM answers x WHERE x.attempt_id = a.id) <> e.total_points`,
    ))[0]?.c ?? 0);
    // HEURISTIC (informational, does not affect `ok`): the same person entered twice
    // under two different roll numbers. The unique index cannot catch this — the roll
    // numbers genuinely differ, usually by one mistyped character — so the only signal
    // is an identical name inside the same section. Surfaced so a TPO can review and
    // merge instead of finding out when a student appears twice in a report.
    const suspects = await db.all<{ classId: string; name: string; rolls: string; n: number }>(dsql`
      SELECT class_id AS classId, lower(trim(name)) AS name,
             group_concat(roll_no) AS rolls, COUNT(*) AS n
      FROM students
      GROUP BY tenant_id, class_id, lower(trim(name))
      HAVING COUNT(*) > 1
      ORDER BY n DESC
      LIMIT 50
    `);
    // Roll numbers that cannot be right — a pasted email is the usual culprit.
    const malformedRolls = await db.all<{ id: string; rollNo: string; name: string }>(dsql`
      SELECT id, roll_no AS rollNo, name FROM students
      WHERE roll_no LIKE '%@%'
         OR roll_no <> trim(roll_no)
         OR roll_no <> upper(roll_no)
      LIMIT 50
    `);
    const ok = indexes.every((i) => i.present && i.duplicateGroups === 0) && columns.every((c2) => c2.present) && impossible === 0 && denomMismatch === 0;
    return c.json({
      ok,
      bootCheck: INDEX_STATE,
      indexes,
      perfIndexes,
      columns,
      attemptsWithImpossibleScore: impossible,
      attemptsWithDenominatorMismatch: denomMismatch,
      duplicateStudentSuspects: suspects.map((s) => ({ ...s, n: Number(s.n) })),
      malformedRollNumbers: malformedRolls,
      // Runtime self-monitoring, so one page answers "is it healthy right now?"
      // as well as "is the stored data sound?".
      liveMonitor: { ...monitorTiming(), pollMs: MONITOR_POLL_MS, budgetMs: MONITOR_BUDGET_MS },
      examChecks: recentExamChecks(),
    }, ok ? 200 : 500);
  })

  // Re-run the per-exam data check on demand. The automatic run happens when an
  // exam finishes grading; this is for re-checking an older exam (e.g. after a
  // manual score edit) without waiting for anything.
  .post("/admin/exam-check/:examId", requireAuth, requireSuperAdmin, async (c) => {
    const examId = c.req.param("examId");
    const [exam] = await db.select().from(schema.exams).where(eq(schema.exams.id, examId)).limit(1);
    if (!exam) return c.json({ error: "Exam not found" }, 404);
    const result = await checkExamData(examId);
    if (!result) return c.json({ error: "Check failed; see server logs" }, 500);
    return c.json(result, 200);
  })

  // ---- TEMP diagnostic: verify DB connectivity + env presence ----
  // Super-admin only: it reports which secrets are set and the start of the
  // database URL, which must not be readable by anyone on the internet.
  .get("/__diag", requireAuth, requireSuperAdmin, async (c) => {
    const env = {
      DATABASE_URL: process.env.DATABASE_URL
        ? `${process.env.DATABASE_URL.slice(0, 14)}… (len ${process.env.DATABASE_URL.length})`
        : "MISSING",
      DATABASE_AUTH_TOKEN: process.env.DATABASE_AUTH_TOKEN
        ? `set (len ${process.env.DATABASE_AUTH_TOKEN.length})`
        : "MISSING",
      BETTER_AUTH_SECRET: process.env.BETTER_AUTH_SECRET ? "set" : "MISSING",
      WEBSITE_URL: process.env.WEBSITE_URL ?? "MISSING",
    };
    try {
      const [u] = await db.select().from(schema.user).limit(1);
      return c.json({ db: "ok", userFound: !!u, env }, 200);
    } catch (e) {
      return c.json(
        { db: "error", error: e instanceof Error ? e.message : String(e), env },
        500,
      );
    }
  })

  // ---- current session context ----
  .get("/me", requireAuth, async (c) => {
    const user = c.get("user")!;
    const profile = c.get("profile")!;
    let tenant = null;
    if (profile.tenantId) {
      const [t] = await db.select().from(schema.tenants).where(eq(schema.tenants.id, profile.tenantId));
      tenant = t ?? null;
    }
    return c.json({ user, profile, tenant }, 200);
  })

  // ---- file upload presign (client -> tigris directly) ----
  .post("/upload/presign", requireAuth, async (c) => {
    const { name, contentType } = await c.req.json();
    const key = `uploads/${Date.now()}-${id()}-${(name ?? "file").replace(/[^\w.-]/g, "_")}`;
    const url = await presignPut(key, contentType ?? "application/octet-stream");
    // Tigris objects are not public-read (raw endpoint URL returns 403), so we
    // serve uploads through our own same-origin proxy route below.
    return c.json({ url, key, publicUrl: `/api/files/${key}` }, 200);
  })

  // ---- authenticated file proxy (streams object from S3) ----
  // Deliberately NOT public. Objects under `integrity/` are student webcam
  // photos, so an unauthenticated reader holding (or guessing) a key could pull
  // faces straight out of the bucket. Every read requires a signed-in staff
  // session; snapshot keys additionally require the `reports` permission and are
  // scoped to the caller's own college, so a TPO cannot read another college's
  // evidence by key alone.
  .get("/files/*", requireAuth, async (c) => {
    const key = c.req.path.replace(/^\/api\/files\//, "");
    if (!key) return c.text("Not found", 404);
    // Reject traversal / absolute keys before they reach storage.
    if (key.includes("..") || key.startsWith("/")) return c.text("Not found", 404);

    if (key.startsWith("integrity/")) {
      const profile = c.get("profile");
      if (!profile) return c.json({ message: "Unauthorized" }, 401);
      const staff =
        profile.role === "super_admin" ||
        profile.role === "college_admin" ||
        (profile.role === "tpo" && profile.permissions?.reports === true);
      if (!staff) return c.json({ message: "Forbidden" }, 403);
      // Keys are written as `integrity/<attemptId>/<file>`; confirm the attempt
      // belongs to this college before streaming the frame.
      if (profile.role !== "super_admin") {
        const attemptId = key.split("/")[1] ?? "";
        if (!attemptId) return c.text("Not found", 404);
        const [own] = await db
          .select({ tenantId: schema.exams.tenantId })
          .from(schema.attempts)
          .innerJoin(schema.exams, eq(schema.attempts.examId, schema.exams.id))
          .where(eq(schema.attempts.id, attemptId))
          .limit(1);
        if (!own || own.tenantId !== profile.tenantId) return c.json({ message: "Forbidden" }, 403);
      }
    }

    try {
      const out = await getObject(key);
      if (!out.Body) return c.text("Not found", 404);
      const buf = await out.Body.transformToByteArray();
      // Cast: transformToByteArray gives Uint8Array<ArrayBufferLike>, Hono wants
      // an ArrayBuffer-backed view. Same bytes, no copy.
      return c.body(buf as unknown as Uint8Array<ArrayBuffer>, 200, {
        "Content-Type": out.ContentType ?? "application/octet-stream",
        // `private`: the response is authorised per-session, so shared/proxy
        // caches must never hold a copy. Browser caching is still fine —
        // object keys are content-addressed and never rewritten.
        "Cache-Control": "private, max-age=31536000, immutable",
      });
    } catch {
      return c.text("Not found", 404);
    }
  })

  // =================== PUBLIC SELF-REGISTRATION (no auth) ===================
  // Meta for the public registration page: tenant name + section dropdown list.
  // The URL uses the college short code (e.g. /register/tkr), resolved below.
  .get("/register/:code/meta", async (c) => {
    const t = await resolveRegisterTenant(c.req.param("code"));
    if (!t) return c.json({ message: "Invalid registration link" }, 404);
    const rows = await db
      .select({ id: schema.classes.id, code: schema.classes.code })
      .from(schema.classes)
      .where(eq(schema.classes.tenantId, t.id));
    rows.sort((a, b) => a.code.localeCompare(b.code));
    return c.json({ tenant: { id: t.id, name: t.name, code: t.shortName }, sections: rows }, 200);
  })
  // Check whether a student already exists for this tenant — by roll number OR name.
  .get("/register/:code/check", async (c) => {
    const raw = String(c.req.query("q") ?? c.req.query("rollNo") ?? "").trim();
    if (!raw) return c.json({ message: "Enter a roll number or name" }, 400);
    const t = await resolveRegisterTenant(c.req.param("code"));
    if (!t) return c.json({ message: "Invalid registration link" }, 404);
    const tid = t.id;

    const roll = raw.replace(/\s+/g, "").toUpperCase();
    const nameQ = raw.replace(/\s+/g, " ");
    // A query containing a digit is treated as a roll number; otherwise a name.
    const looksLikeRoll = /\d/.test(raw);

    const rows = await db
      .select({ name: schema.students.name, rollNo: schema.students.rollNo })
      .from(schema.students)
      .where(
        and(
          eq(schema.students.tenantId, tid),
          or(eq(schema.students.rollNo, roll), like(schema.students.name, `%${nameQ}%`)),
        ),
      )
      .limit(6);

    return c.json(
      {
        query: raw,
        looksLikeRoll,
        exists: rows.length > 0,
        matches: rows,
        name: rows[0]?.name ?? null,
        rollNo: looksLikeRoll ? roll : (rows[0]?.rollNo ?? ""),
      },
      200,
    );
  })
  // Register a new student (only if the roll number is not already present).
  .post("/register/:code", async (c) => {
    const rt = await resolveRegisterTenant(c.req.param("code"));
    if (!rt) return c.json({ message: "Invalid registration link" }, 404);
    const tid = rt.id;
    const b = await c.req.json();

    const roll = normalizeRoll(b.rollNo);
    const name = String(b.name ?? "")
      .trim()
      .replace(/\s+/g, " ")
      .toLowerCase()
      .replace(/\b\w/g, (ch) => ch.toUpperCase());
    const email = String(b.email ?? "").trim().toLowerCase();
    const phone = String(b.phone ?? "").trim();
    const gender = String(b.gender ?? "").trim().toLowerCase();
    const classId = b.classId ? String(b.classId) : null;

    const rollBad = rollNoProblem(roll);
    if (rollBad) return c.json({ message: rollBad }, 400);
    if (!name) return c.json({ message: "Name is required" }, 400);
    if (!classId) return c.json({ message: "Please select your section" }, 400);
    if (!email || !/^\S+@\S+\.\S+$/.test(email)) return c.json({ message: "A valid email is required" }, 400);
    if (!/^\d{10}$/.test(phone.replace(/\D/g, "").slice(-10))) return c.json({ message: "A valid phone number is required" }, 400);
    if (gender !== "male" && gender !== "female") return c.json({ message: "Please select gender" }, 400);

    // Section must belong to this tenant.
    const [cls] = await db
      .select({ id: schema.classes.id })
      .from(schema.classes)
      .where(and(eq(schema.classes.id, classId), eq(schema.classes.tenantId, tid)));
    if (!cls) return c.json({ message: "Invalid section" }, 400);

    // Block duplicates by roll number, ignoring case and padding of what is ALREADY
    // stored — an exact match here missed rows saved before normalisation existed.
    const dupRoll = await findStudentByRoll(tid, roll);
    if (dupRoll) return c.json({ message: "This roll number is already registered", exists: true }, 409);

    // Block duplicate email within the tenant.
    const [dupEmail] = await db
      .select({ id: schema.students.id })
      .from(schema.students)
      .where(and(eq(schema.students.tenantId, tid), eq(schema.students.email, email)));
    if (dupEmail) return c.json({ message: "This email is already registered" }, 409);

    const newStuId = id("stu");
    try {
      await db.insert(schema.students).values({
        id: newStuId,
        tenantId: tid,
        classId,
        rollNo: roll,
        name,
        email,
        phone: phone.replace(/\D/g, "").slice(-10),
        gender,
        password: await hashPassword("Welcome@123"),
      });
    } catch (e) {
      // The check above and this insert are two separate statements, so two students
      // submitting the same roll at the same moment both pass the check. The unique
      // index is the real guarantee; translate its error into the same 409 rather
      // than a 500, so the second one just sees "already registered".
      if (isDuplicateRollError(e)) return c.json({ message: "This roll number is already registered", exists: true }, 409);
      throw e;
    }
    // A new student changes the assignable cohort every admin screen reads.
    directory.invalidateStudents(tid);

    // Late-registrant enrolment: a student who registers after exams were set up
    // must still land in the exam meant for their branch. Cohort matching already
    // makes them eligible for section-targeted exams, but we ALSO write an explicit
    // roster "add" so they're concretely enrolled — visible in the assigned count
    // and robust even if the exam uses explicit "students" assignment. Scoped to
    // exams that are running or scheduled and that target this student's section.
    try {
      const activeExams = await db
        .select()
        .from(schema.exams)
        .where(and(eq(schema.exams.tenantId, tid), inArray(schema.exams.status, ["scheduled", "live"])));
      // Make sure opt-in-only cohorts (ELITE) are known before cohort matching, so a
      // student registering into ELITE is not auto-enrolled into regular exams.
      await ensureOptInOnlyLoaded();
      const stu = { id: newStuId, classId };
      const toEnroll = activeExams.filter((e) => {
        const secIds = (e.sectionIds as string[] | null) ?? null;
        // Cohort-mode exam that targets this student's section (or all sections).
        if (e.assignMode !== "students" && matchesCohort({ classId: e.classId, sectionIds: secIds, assignMode: e.assignMode }, stu)) return true;
        // Explicit "students"-mode exam that still carries this section in its scope.
        if (e.assignMode === "students" && Array.isArray(secIds) && classId && secIds.includes(classId)) return true;
        return false;
      });
      if (toEnroll.length) {
        await db
          .insert(schema.examRoster)
          .values(toEnroll.map((e) => ({ id: id("rost"), examId: e.id, studentId: newStuId, mode: "add" as const, createdBy: null })));
      }
    } catch (e) {
      console.error("[register] auto-enrol failed for", roll, e);
    }

    return c.json({ ok: true, name, rollNo: roll }, 201);
  })

  // =================== TENANTS (super admin) ===================
  .get("/tenants", requireAuth, requireSuperAdmin, async (c) => {
    const rows = await db.select().from(schema.tenants).orderBy(desc(schema.tenants.createdAt));
    const withCounts = await Promise.all(
      rows.map(async (t) => {
        const [u] = await db
          .select({ n: dsql<number>`count(*)` })
          .from(schema.profiles)
          .where(eq(schema.profiles.tenantId, t.id));
        return { ...t, userCount: u?.n ?? 0 };
      }),
    );
    return c.json({ tenants: withCounts }, 200);
  })
  .post("/tenants", requireAuth, requireSuperAdmin, async (c) => {
    const b = await c.req.json();
    const tid = id("ten");
    const [t] = await db
      .insert(schema.tenants)
      .values({
        id: tid,
        name: b.name,
        shortName: b.shortName || b.name.slice(0, 2).toUpperCase(),
        slug: (b.slug || b.name).toLowerCase().replace(/[^a-z0-9]+/g, "-"),
        primaryColor: b.primaryColor || "#1e3a5f",
        logoUrl: b.logoUrl ?? null,
      })
      .returning();
    authCache.invalidate();
    return c.json({ tenant: t }, 201);
  })
  .patch("/tenants/:id", requireAuth, requireSuperAdmin, async (c) => {
    const tid = c.req.param("id");
    const b = await c.req.json();
    // Quota overrides are normalised instead of passed through raw: a cleared
    // field or a 0 means "inherit the global default", never "ceiling of zero",
    // which would refuse every student in this college. To stop a tenant
    // deliberately there is already `enabled = false`.
    for (const k of ["maxConcurrentAttempts", "maxEvidencePerAttempt"] as const) {
      if (b[k] === undefined) continue;
      const n = Math.floor(Number(b[k]));
      b[k] = b[k] === null || b[k] === "" || !Number.isFinite(n) || n <= 0 ? null : n;
    }
    const [t] = await db.update(schema.tenants).set(b).where(eq(schema.tenants.id, tid)).returning();
    // Apply the new ceiling immediately rather than at the next cache expiry, and
    // latch "an override exists" so it is honoured even with no global default.
    tenantQuotas.invalidate(tid);
    concurrencyGate.invalidate(tid);
    if (t?.maxConcurrentAttempts != null || t?.maxEvidencePerAttempt != null) tenantQuotas.markTenantOverridesExist();
    return c.json({ tenant: t }, 200);
  })

  // ---- branding (own tenant) ----
  .get("/branding", requireAuth, requirePermission("branding"), async (c) => {
    const p = c.get("profile")!;
    if (!p.tenantId) return c.json({ tenant: null }, 200);
    const [t] = await db.select().from(schema.tenants).where(eq(schema.tenants.id, p.tenantId));
    return c.json({ tenant: t ?? null }, 200);
  })
  .patch("/branding", requireAuth, requirePermission("branding"), async (c) => {
    const p = c.get("profile")!;
    if (!p.tenantId) return c.json({ message: "No tenant" }, 400);
    const b = await c.req.json();
    const [t] = await db
      .update(schema.tenants)
      .set({ name: b.name, shortName: b.shortName, primaryColor: b.primaryColor, logoUrl: b.logoUrl })
      .where(eq(schema.tenants.id, p.tenantId))
      .returning();
    return c.json({ tenant: t }, 200);
  })

  // =================== USERS ===================
  .get("/users", requireAuth, requirePermission("users"), async (c) => {
    const p = c.get("profile")!;
    const tenantFilter = p.role === "super_admin" && c.req.query("tenantId") ? c.req.query("tenantId")! : p.tenantId;
    const profs = tenantFilter
      ? await db.select().from(schema.profiles).where(eq(schema.profiles.tenantId, tenantFilter)).orderBy(desc(schema.profiles.createdAt))
      : await db.select().from(schema.profiles).orderBy(desc(schema.profiles.createdAt));
    const ids = profs.map((x) => x.userId);
    const users = ids.length ? await db.select().from(schema.user).where(inArray(schema.user.id, ids)) : [];
    const umap = new Map(users.map((u) => [u.id, u]));
    const rows = profs
      .filter((x) => x.role !== "student")
      .map((x) => ({
        ...x,
        name: umap.get(x.userId)?.name ?? "",
        email: umap.get(x.userId)?.email ?? "",
      }));
    return c.json({ users: rows }, 200);
  })
  .post("/users", requireAuth, requirePermission("users"), async (c) => {
    const actor = c.get("profile")!;
    const b = await c.req.json();
    const tenantId = actor.role === "super_admin" ? (b.tenantId ?? actor.tenantId) : actor.tenantId;
    // create auth user
    const res = await auth.api.signUpEmail({ body: { email: b.email, password: b.password, name: b.name } });
    const newUserId = (res as { user?: { id: string } }).user?.id;
    if (!newUserId) return c.json({ message: "Failed to create user" }, 400);
    const [cnt] = await db.select({ n: dsql<number>`count(*)` }).from(schema.profiles);
    const defaultPerms =
      b.role === "tpo"
        ? (b.permissions ?? { dashboard: true, liveMonitor: true, reports: true })
        : null;
    const [prof] = await db
      .insert(schema.profiles)
      .values({
        userId: newUserId,
        tenantId,
        role: b.role, // tpo | student (super_admin seeded only)
        displayId: displayId("USR", (cnt?.n ?? 0) + 1),
        phone: b.phone ?? null,
        permissions: defaultPerms,
      })
      .returning();
    return c.json({ user: { ...prof, name: b.name, email: b.email } }, 201);
  })
  .patch("/users/:id", requireAuth, requirePermission("users"), async (c) => {
    const uid = c.req.param("id");
    const b = await c.req.json();
    const patch: Record<string, unknown> = {};
    if (b.enabled !== undefined) patch.enabled = b.enabled;
    if (b.permissions !== undefined) patch.permissions = b.permissions;
    if (b.role !== undefined) patch.role = b.role;
    if (b.phone !== undefined) patch.phone = b.phone;
    if (Object.keys(patch).length) await db.update(schema.profiles).set(patch).where(eq(schema.profiles.userId, uid));
    const userPatch: Record<string, unknown> = {};
    if (b.name !== undefined) userPatch.name = b.name;
    if (b.email !== undefined) userPatch.email = b.email;
    if (Object.keys(userPatch).length) {
      userPatch.updatedAt = new Date();
      await db.update(schema.user).set(userPatch).where(eq(schema.user.id, uid));
    }
    authCache.invalidate();
    const [prof] = await db.select().from(schema.profiles).where(eq(schema.profiles.userId, uid));
    return c.json({ user: prof }, 200);
  })
  .post("/users/:id/reset-password", requireAuth, requirePermission("users"), async (c) => {
    const uid = c.req.param("id");
    const b = await c.req.json();
    const newPassword: string = b.password && String(b.password).length >= 8 ? b.password : "Welcome@123";
    const hash = await hashPassword(newPassword);
    const [acc] = await db.select().from(schema.account).where(and(eq(schema.account.userId, uid), eq(schema.account.providerId, "credential")));
    if (!acc) return c.json({ message: "No credential account" }, 404);
    authCache.invalidate();
    await db.update(schema.account).set({ password: hash, updatedAt: new Date() }).where(eq(schema.account.id, acc.id));
    return c.json({ ok: true, password: newPassword }, 200);
  })
  // Permanently delete a staff user (TPO / college admin) and their auth records.
  .delete("/users/:id", requireAuth, requirePermission("users"), async (c) => {
    const uid = c.req.param("id");
    const me = c.get("profile")!;
    if (uid === me.userId) return c.json({ message: "You cannot delete your own account." }, 400);
    const [target] = await db.select().from(schema.profiles).where(eq(schema.profiles.userId, uid));
    if (!target) return c.json({ message: "User not found" }, 404);
    if (target.role === "super_admin") return c.json({ message: "The super admin account cannot be deleted." }, 403);
    // Non-super-admins can only delete users within their own tenant.
    if (me.role !== "super_admin" && target.tenantId !== me.tenantId) return c.json({ message: "Not allowed" }, 403);
    // Remove auth rows first (session, credential account), then profile, then user.
    await db.delete(schema.session).where(eq(schema.session.userId, uid));
    await db.delete(schema.account).where(eq(schema.account.userId, uid));
    await db.delete(schema.profiles).where(eq(schema.profiles.userId, uid));
    authCache.invalidate();
    await db.delete(schema.user).where(eq(schema.user.id, uid));
    return c.json({ ok: true }, 200);
  })

  // =================== CLASSES ===================
  .get("/classes", requireAuth, async (c) => {
    const p = c.get("profile")!;
    const tid = p.role === "super_admin" && c.req.query("tenantId") ? c.req.query("tenantId")! : p.tenantId;
    if (!tid) return c.json({ classes: [] }, 200);
    const rows = await db.select().from(schema.classes).where(eq(schema.classes.tenantId, tid)).orderBy(desc(schema.classes.createdAt));
    const withYear = rows.map((r) => ({ ...r, year: computeYear(r.batchStartYear) }));
    return c.json({ classes: withYear }, 200);
  })
  .post("/classes", requireAuth, requirePermission("users"), async (c) => {
    const p = c.get("profile")!;
    const b = await c.req.json();
    const tid = p.role === "super_admin" ? (b.tenantId ?? p.tenantId) : p.tenantId;
    // A section letter is optional: branch-wide cohorts (CIVIL, EEE, ELITE) have no
    // letter and their code is just the branch name.
    const sec = String(b.section ?? "").trim();
    const code = sec ? `${b.branch}-${sec}` : String(b.branch).trim();
    const [row] = await db
      .insert(schema.classes)
      .values({ id: id("cls"), tenantId: tid!, branch: b.branch, batchStartYear: b.batchStartYear, section: sec, code })
      .returning();
    // A new ELITE-style cohort changes who is opt-in-only — drop the cache.
    if (isOptInOnlyCode(code) || isOptInOnlyCode(b.branch)) invalidateOptInOnlyCache();
    directory.invalidateClasses(tid);
    return c.json({ class: row }, 201);
  })
  .patch("/classes/:id", requireAuth, requirePermission("users"), async (c) => {
    const cid = c.req.param("id");
    const b = await c.req.json();
    const sec = String(b.section ?? "").trim();
    const code = sec ? `${b.branch}-${sec}` : String(b.branch).trim();
    const [row] = await db
      .update(schema.classes)
      .set({ branch: b.branch, section: sec, batchStartYear: b.batchStartYear, code })
      .where(eq(schema.classes.id, cid))
      .returning();
    // Renaming a class can add/remove ELITE status — always drop the cache.
    invalidateOptInOnlyCache();
    // A renamed section changes the code every report labels rows with.
    directory.invalidateClasses(row?.tenantId);
    return c.json({ class: row }, 200);
  })
  .delete("/classes/:id", requireAuth, requirePermission("users"), async (c) => {
    const cid = c.req.param("id");
    // Unassign any students in this section, then delete it. Students promoted OUT of
    // this section keep their originalClassId pointer, so clear those too to avoid
    // dangling references breaking "restore to original section".
    await db.update(schema.students).set({ classId: null }).where(eq(schema.students.classId, cid));
    await db.update(schema.students).set({ originalClassId: null }).where(eq(schema.students.originalClassId, cid));
    await db.delete(schema.classes).where(eq(schema.classes.id, cid));
    invalidateOptInOnlyCache();
    // Touched BOTH tables (students were unassigned), and the tenant id is not in
    // scope here, so drop every tenant rather than risk serving a dangling classId.
    directory.invalidate();
    return c.json({ ok: true }, 200);
  })

  // =================== STUDENTS ===================
  .get("/students", requireAuth, async (c) => {
    const p = c.get("profile")!;
    const tid = p.role === "super_admin" && c.req.query("tenantId") ? c.req.query("tenantId")! : p.tenantId;
    if (!tid) return c.json({ students: [] }, 200);
    // NOTE: never return the password hash to the client.
    const rows = await db
      .select({
        id: schema.students.id,
        tenantId: schema.students.tenantId,
        classId: schema.students.classId,
        originalClassId: schema.students.originalClassId,
        rollNo: schema.students.rollNo,
        name: schema.students.name,
        email: schema.students.email,
        enabled: schema.students.enabled,
        createdAt: schema.students.createdAt,
      })
      .from(schema.students)
      .where(eq(schema.students.tenantId, tid))
      .orderBy(desc(schema.students.createdAt));
    return c.json({ students: rows }, 200);
  })
  .post("/students", requireAuth, requirePermission("users"), async (c) => {
    const p = c.get("profile")!;
    const b = await c.req.json();
    const tid = p.role === "super_admin" ? (b.tenantId ?? p.tenantId) : p.tenantId;
    const plain = b.password && String(b.password).length >= 6 ? String(b.password) : "Welcome@123";

    // This endpoint used to insert whatever it was given, with NO duplicate check
    // of any kind — the main source of duplicate student records. Normalise, reject
    // obvious junk, and refuse a roll number the tenant already has.
    const roll = normalizeRoll(b.rollNo);
    const rollBad = rollNoProblem(roll);
    if (rollBad) return c.json({ message: rollBad }, 400);
    const name = String(b.name ?? "").trim().replace(/\s+/g, " ");
    if (!name) return c.json({ message: "Name is required" }, 400);
    if (!tid) return c.json({ message: "No tenant" }, 400);
    const clash = await findStudentByRoll(tid, roll);
    if (clash) {
      return c.json({ message: `Roll number ${roll} already exists (${clash.name})`, existingId: clash.id }, 409);
    }

    let row;
    try {
      [row] = await db
      .insert(schema.students)
      .values({
        id: id("stu"),
        tenantId: tid!,
        classId: b.classId ?? null,
        rollNo: roll,
        name,
        email: b.email ?? null,
        password: await hashPassword(plain),
      })
      .returning({
        id: schema.students.id,
        tenantId: schema.students.tenantId,
        classId: schema.students.classId,
        rollNo: schema.students.rollNo,
        name: schema.students.name,
        email: schema.students.email,
        enabled: schema.students.enabled,
        createdAt: schema.students.createdAt,
      });
    } catch (e) {
      // Same select-then-insert race as registration: the unique index has the
      // final say, so surface it as a clean 409.
      if (isDuplicateRollError(e)) return c.json({ message: `Roll number ${roll} already exists` }, 409);
      throw e;
    }
    directory.invalidateStudents(tid);
    return c.json({ student: row }, 201);
  })
  .post("/students/bulk", requireAuth, requirePermission("users"), async (c) => {
    const p = c.get("profile")!;
    const b = await c.req.json(); // { rows: [{name, rollNo, email, classCode}] }
    const tid = p.tenantId!;

    // Normalise a raw class value ("CSE - A", "cse-a", "CSE  A") to canonical "CSE-A".
    const normCode = (raw: string): string => {
      const cleaned = String(raw ?? "").trim().toUpperCase().replace(/\s+/g, " ");
      if (!cleaned) return "";
      // Split branch + section on hyphen or space; rejoin with a single hyphen.
      const m = cleaned.match(/^([A-Z]+)\s*-?\s*([A-Z0-9]*)$/);
      if (m) return m[2] ? `${m[1]}-${m[2]}` : m[1];
      return cleaned.replace(/\s*-\s*/g, "-").replace(/\s+/g, "-");
    };

    const classes = await db.select().from(schema.classes).where(eq(schema.classes.tenantId, tid));
    const codeMap = new Map(classes.map((cl) => [cl.code, cl.id]));

    // Existing roll numbers for this tenant — used to skip already-registered
    // students. Normalised with the SAME function the rows below go through, so a
    // stored "23k91a0491" and an imported " 23K91A0491 " are recognised as one.
    const existing = await db.select({ rollNo: schema.students.rollNo }).from(schema.students).where(eq(schema.students.tenantId, tid));
    const seenRolls = new Set(existing.map((e) => normalizeRoll(e.rollNo)));

    const clean = (b.rows as Array<Record<string, string>>)
      .map((r) => ({
        name: String(r.name ?? "").trim().replace(/\s+/g, " "),
        rollNo: normalizeRoll(r.rollNo),
        email: String(r.email ?? "").trim(),
        code: normCode(r.classCode ?? ""),
      }))
      .filter((r) => r.name && r.rollNo);

    // Hash the default password ONCE — hashing per row (scrypt) would hang the
    // request for large CSVs (hundreds of rows).
    const defaultHash = await hashPassword("Welcome@123");

    let inserted = 0, skipped = 0, createdSections = 0;
    // Rows the import refused to trust, returned to the caller so a TPO can see
    // WHY a row did not land instead of silently ending up with fewer students
    // than the file had. Previously every rejection was an anonymous "skipped".
    const rejected: { rollNo: string; name: string; reason: string }[] = [];
    const values: (typeof schema.students.$inferInsert)[] = [];
    for (const r of clean) {
      const key = r.rollNo;
      // Junk roll numbers (pasted emails, stray punctuation) used to be imported
      // verbatim and then never matched anything.
      const bad = rollNoProblem(key);
      if (bad) { skipped++; rejected.push({ rollNo: r.rollNo, name: r.name, reason: bad }); continue; }
      if (seenRolls.has(key)) { skipped++; rejected.push({ rollNo: r.rollNo, name: r.name, reason: "Already registered" }); continue; }
      seenRolls.add(key); // guard against duplicates within the same file

      // Auto-create the section if the class code is present but unknown.
      let classId: string | null = null;
      if (r.code) {
        classId = codeMap.get(r.code) ?? null;
        if (!classId) {
          const [branch, section] = r.code.includes("-") ? r.code.split("-") : [r.code, ""];
          const [row] = await db
            .insert(schema.classes)
            .values({ id: id("cls"), tenantId: tid, branch, section, code: r.code, batchStartYear: new Date().getFullYear() })
            .returning();
          classId = row.id;
          codeMap.set(r.code, row.id);
          createdSections++;
        }
      }

      values.push({
        id: id("stu"),
        tenantId: tid,
        classId,
        rollNo: r.rollNo,
        name: r.name,
        email: r.email || null,
        password: defaultHash,
      });
      inserted++;
    }
    // Insert in chunks to stay well under SQLite's variable limit. `onConflictDoNothing`
    // targets the roll-number unique index, so a concurrent import of the same file
    // (double-clicked upload) cannot create duplicates — the second one is a no-op
    // instead of a 500 that aborts the whole batch halfway through.
    for (let i = 0; i < values.length; i += 200) {
      await db.insert(schema.students).values(values.slice(i, i + 200)).onConflictDoNothing();
    }
    // An import can create sections as well as students — drop both for the tenant.
    directory.invalidate(tid);
    return c.json({ inserted, skipped, createdSections, rejected }, 201);
  })
  .patch("/students/:id", requireAuth, requirePermission("users"), async (c) => {
    const sid = c.req.param("id");
    const b = await c.req.json();
    const patch: Record<string, unknown> = {};
    for (const k of ["name", "rollNo", "email", "classId", "enabled"]) {
      if (k in b) patch[k] = b[k];
    }

    // Editing a roll number could previously produce a duplicate just as easily as
    // creating one — the edit form was in fact how the pasted-email roll numbers got
    // "fixed" into a second copy of an existing student. Normalise and check.
    const [before] = await db.select().from(schema.students).where(eq(schema.students.id, sid));
    if (!before) return c.json({ message: "Student not found" }, 404);
    if ("rollNo" in patch) {
      const roll = normalizeRoll(patch.rollNo);
      const bad = rollNoProblem(roll);
      if (bad) return c.json({ message: bad }, 400);
      if (roll !== normalizeRoll(before.rollNo)) {
        const clash = await findStudentByRoll(before.tenantId, roll);
        if (clash && clash.id !== sid) {
          return c.json({ message: `Roll number ${roll} already belongs to ${clash.name}`, existingId: clash.id }, 409);
        }
      }
      patch.rollNo = roll;
    }
    if ("name" in patch) {
      const name = String(patch.name ?? "").trim().replace(/\s+/g, " ");
      if (!name) return c.json({ message: "Name is required" }, 400);
      patch.name = name;
    }

    try {
      const [row] = await db.update(schema.students).set(patch).where(eq(schema.students.id, sid)).returning();
      // Name/roll/section/enabled all feed the cached index.
      directory.invalidateStudents(row?.tenantId);
      return c.json({ student: row }, 200);
    } catch (e) {
      if (isDuplicateRollError(e)) return c.json({ message: "Another student already has that roll number" }, 409);
      throw e;
    }
  })
  // ============ SPECIAL COHORTS (ELITE) ============
  // A special cohort is a section that is OPT-IN ONLY: students in it are skipped by
  // every regular-section assessment (including "All sections") and only receive
  // assessments that explicitly target the cohort. Moving a student in records their
  // previous section in originalClassId so the move is fully reversible.

  // Resolve (or create) the tenant's ELITE cohort section.
  .post("/cohorts/elite/ensure", requireAuth, requirePermission("users"), async (c) => {
    const p = c.get("profile")!;
    const tid = p.tenantId;
    if (!tid) return c.json({ message: "No tenant" }, 400);
    const rows = await db.select().from(schema.classes).where(eq(schema.classes.tenantId, tid));
    let elite = rows.find((cl) => isOptInOnlyCode(cl.code) || isOptInOnlyCode(cl.branch));
    if (!elite) {
      const year = new Date().getFullYear();
      [elite] = await db
        .insert(schema.classes)
        .values({ id: id("cls"), tenantId: tid, branch: "ELITE", batchStartYear: year, section: "", code: "ELITE" })
        .returning();
      invalidateOptInOnlyCache();
    }
    return c.json({ class: elite }, 200);
  })

  // Move students INTO the ELITE cohort (bulk, by studentId or rollNo).
  // Their current section is saved to originalClassId (only if not already saved, so
  // repeated moves never lose the true home section).
  .post("/cohorts/elite/add", requireAuth, requirePermission("users"), async (c) => {
    const p = c.get("profile")!;
    const tid = p.tenantId;
    if (!tid) return c.json({ message: "No tenant" }, 400);
    const b = await c.req.json();
    const ids: string[] = Array.isArray(b.studentIds) ? b.studentIds.map(String) : [];
    const rolls: string[] = Array.isArray(b.rollNos) ? b.rollNos.map((r: unknown) => String(r).trim().toUpperCase()) : [];

    const cls = await db.select().from(schema.classes).where(eq(schema.classes.tenantId, tid));
    let elite = cls.find((cl) => isOptInOnlyCode(cl.code) || isOptInOnlyCode(cl.branch));
    if (!elite) {
      const year = new Date().getFullYear();
      [elite] = await db
        .insert(schema.classes)
        .values({ id: id("cls"), tenantId: tid, branch: "ELITE", batchStartYear: year, section: "", code: "ELITE" })
        .returning();
      invalidateOptInOnlyCache();
    }

    const all = await db.select().from(schema.students).where(eq(schema.students.tenantId, tid));
    const byId = new Map(all.map((s) => [s.id, s]));
    const byRoll = new Map(all.map((s) => [s.rollNo.trim().toUpperCase(), s]));

    const moved: { id: string; rollNo: string; name: string; from: string }[] = [];
    const alreadyElite: string[] = [];
    const notFound: string[] = [];

    const targets = new Map<string, typeof all[number]>();
    for (const sidRaw of ids) {
      const s = byId.get(sidRaw);
      if (s) targets.set(s.id, s); else notFound.push(sidRaw);
    }
    for (const roll of rolls) {
      const s = byRoll.get(roll);
      if (s) targets.set(s.id, s); else notFound.push(roll);
    }

    const codeById = new Map(cls.map((cl) => [cl.id, cl.code]));
    for (const s of targets.values()) {
      if (s.classId === elite.id) { alreadyElite.push(s.rollNo); continue; }
      // Preserve the FIRST known home section; don't overwrite on re-moves.
      const keepOriginal = s.originalClassId ?? s.classId ?? null;
      await db.update(schema.students).set({ classId: elite.id, originalClassId: keepOriginal }).where(eq(schema.students.id, s.id));
      moved.push({ id: s.id, rollNo: s.rollNo, name: s.name, from: codeById.get(s.classId ?? "") ?? "(none)" });
    }
    directory.invalidateStudents(tid);
    return c.json({ ok: true, eliteClassId: elite.id, movedCount: moved.length, moved, alreadyElite, notFound }, 200);
  })

  // Remove students FROM the ELITE cohort, restoring their original section.
  .post("/cohorts/elite/remove", requireAuth, requirePermission("users"), async (c) => {
    const p = c.get("profile")!;
    const tid = p.tenantId;
    if (!tid) return c.json({ message: "No tenant" }, 400);
    const b = await c.req.json();
    const ids: string[] = Array.isArray(b.studentIds) ? b.studentIds.map(String) : [];
    // Optional explicit destination; otherwise fall back to originalClassId.
    const toClassId: string | null = b.classId ? String(b.classId) : null;

    const all = await db.select().from(schema.students).where(eq(schema.students.tenantId, tid));
    const byId = new Map(all.map((s) => [s.id, s]));
    const restored: { id: string; rollNo: string; to: string }[] = [];
    const noOriginal: string[] = [];

    const cls = await db.select().from(schema.classes).where(eq(schema.classes.tenantId, tid));
    const codeById = new Map(cls.map((cl) => [cl.id, cl.code]));

    for (const sidRaw of ids) {
      const s = byId.get(sidRaw);
      if (!s) continue;
      const dest = toClassId ?? s.originalClassId;
      if (!dest) { noOriginal.push(s.rollNo); continue; }
      await db.update(schema.students).set({ classId: dest, originalClassId: null }).where(eq(schema.students.id, s.id));
      restored.push({ id: s.id, rollNo: s.rollNo, to: codeById.get(dest) ?? dest });
    }
    directory.invalidateStudents(tid);
    return c.json({ ok: true, restoredCount: restored.length, restored, noOriginal }, 200);
  })

  // Current ELITE roster + each student's original section.
  .get("/cohorts/elite", requireAuth, async (c) => {
    const p = c.get("profile")!;
    const tid = p.tenantId;
    if (!tid) return c.json({ eliteClassId: null, students: [] }, 200);
    const cls = await db.select().from(schema.classes).where(eq(schema.classes.tenantId, tid));
    const elite = cls.find((cl) => isOptInOnlyCode(cl.code) || isOptInOnlyCode(cl.branch));
    if (!elite) return c.json({ eliteClassId: null, students: [] }, 200);
    const codeById = new Map(cls.map((cl) => [cl.id, cl.code]));
    const rows = await db.select().from(schema.students).where(and(eq(schema.students.tenantId, tid), eq(schema.students.classId, elite.id)));
    const out = rows
      .map((s) => ({ id: s.id, rollNo: s.rollNo, name: s.name, enabled: s.enabled, originalSection: s.originalClassId ? codeById.get(s.originalClassId) ?? "" : "" }))
      .sort((a, b) => a.rollNo.localeCompare(b.rollNo));
    return c.json({ eliteClassId: elite.id, students: out }, 200);
  })

  .post("/students/:id/reset-password", requireAuth, requirePermission("users"), async (c) => {
    const sid = c.req.param("id");
    const b = await c.req.json();
    const newPassword: string = b.password && String(b.password).length >= 6 ? String(b.password) : "Welcome@123";
    await db.update(schema.students).set({ password: await hashPassword(newPassword), mustChangePassword: true }).where(eq(schema.students.id, sid));
    // Only a studentId is in scope, so clear every tenant. Rare enough to be free.
    directory.invalidateStudents();
    // Return the plaintext ONCE so the admin can hand it to the student; never stored/readable after.
    return c.json({ ok: true, password: newPassword }, 200);
  })
  // Permanently delete a student and everything attached to them (attempts,
  // answers, integrity events, roster overrides). Irreversible.
  .delete("/students/:id", requireAuth, requirePermission("users"), async (c) => {
    const sid = c.req.param("id");
    const me = c.get("profile")!;
    const [stu] = await db.select().from(schema.students).where(eq(schema.students.id, sid));
    if (!stu) return c.json({ message: "Student not found" }, 404);
    if (me.role !== "super_admin" && stu.tenantId !== me.tenantId) return c.json({ message: "Not allowed" }, 403);
    // Cascade: answers + integrity events hang off attempts, so clear those first.
    const atts = await db.select({ id: schema.attempts.id }).from(schema.attempts).where(eq(schema.attempts.studentId, sid));
    for (const a of atts) {
      await db.delete(schema.answers).where(eq(schema.answers.attemptId, a.id));
      await db.delete(schema.integrityEvents).where(eq(schema.integrityEvents.attemptId, a.id));
    }
    // Deleting events can free the top rowid, and the monitor's evidence cache reads
    // forward from a rowid watermark - a reused rowid would land below it. Force a
    // full rebuild; see lib/integrity-rollup.ts.
    integrityRollup.invalidateAll();
    // The attempts themselves are gone, so the owner cache must not keep
    // authorizing their former owners; see lib/attempt-owner.ts.
    attemptOwners.invalidateAll();
    // Evidence rows are going with them, so the stored-evidence counters must
    // be dropped too or a re-sit starts life already at its ceiling.
    evidenceMeter.invalidateAll();
    await db.delete(schema.attempts).where(eq(schema.attempts.studentId, sid));
    await db.delete(schema.examRoster).where(eq(schema.examRoster.studentId, sid));
    await db.delete(schema.students).where(eq(schema.students.id, sid));
    directory.invalidateStudents();
    return c.json({ ok: true }, 200);
  })
  // Student login verification for the Phase 2 desktop client. Public (no staff session).
  // Body: { identifier: rollNo|email, password }. Returns student (no hash) on success.
  .post("/students/verify-login", async (c) => {
    const b = await c.req.json().catch(() => ({}));
    const identifier = String(b.identifier ?? "").trim();
    const password = String(b.password ?? "");
    if (!identifier || !password) return c.json({ ok: false, message: "Enter your roll number / email and password." }, 400);
    const [stu] = await db
      .select()
      .from(schema.students)
      .where(or(eq(schema.students.rollNo, identifier), eq(schema.students.email, identifier)))
      .limit(1);
    if (!stu || !stu.enabled) return c.json({ ok: false, message: "No account found for this roll number / email." }, 401);
    const valid = await verifyPassword({ hash: stu.password, password });
    if (!valid) return c.json({ ok: false, message: "Incorrect password. Please try again." }, 401);
    const token = await signStudentToken(stu.id);
    const [tenant] = await db.select().from(schema.tenants).where(eq(schema.tenants.id, stu.tenantId)).limit(1);
    return c.json({
      ok: true,
      token,
      student: {
        id: stu.id,
        tenantId: stu.tenantId,
        classId: stu.classId,
        rollNo: stu.rollNo,
        name: stu.name,
        email: stu.email,
        collegeName: tenant?.name ?? "",
        collegeShort: tenant?.shortName ?? "",
        primaryColor: tenant?.primaryColor ?? "#1e3a5f",
        logoUrl: tenant?.logoUrl ?? null,
        mustChangePassword: !!stu.mustChangePassword,
      },
    }, 200);
  })

  // Student changes their own password (forced on first login, or from Profile).
  // Requires the current password. Clears the must-change flag on success.
  .post("/student/change-password", async (c) => {
    const sid = await verifyStudentToken(c.req.header("x-student-token"));
    if (!sid) return c.json({ message: "Unauthorized" }, 401);
    const [stu] = await db.select().from(schema.students).where(eq(schema.students.id, sid)).limit(1);
    if (!stu || !stu.enabled) return c.json({ message: "Unauthorized" }, 401);
    const b = await c.req.json().catch(() => ({}));
    const currentPassword = String(b.currentPassword ?? "");
    const newPassword = String(b.newPassword ?? "");
    if (newPassword.length < 6) return c.json({ ok: false, message: "New password must be at least 6 characters." }, 400);
    const valid = await verifyPassword({ hash: stu.password, password: currentPassword });
    if (!valid) return c.json({ ok: false, message: "Your current password is incorrect." }, 400);
    if (newPassword === currentPassword) return c.json({ ok: false, message: "Choose a password different from your current one." }, 400);
    await db.update(schema.students).set({ password: await hashPassword(newPassword), mustChangePassword: false }).where(eq(schema.students.id, sid));
    directory.invalidateStudents();
    return c.json({ ok: true }, 200);
  })

  // =================== STUDENT (desktop client) ===================
  // All student routes authenticate via the "X-Student-Token" header (HMAC token
  // minted at /students/verify-login). No Better Auth session involved.

  // List exams visible to the logged-in student (their class/section), with
  // attempt state so the client can show scheduled vs finished.
  .get("/student/exams", async (c) => {
    const sid = await verifyStudentToken(c.req.header("x-student-token"));
    if (!sid) return c.json({ message: "Unauthorized" }, 401);
    const [stu] = await db.select().from(schema.students).where(eq(schema.students.id, sid)).limit(1);
    if (!stu || !stu.enabled) return c.json({ message: "Unauthorized" }, 401);

    // Tenant-wide half (exams, roster overrides, question counts) from a 5s cache:
    // see getStudentExamListBase. Only the per-student reads below are live.
    const base = await getStudentExamListBase(stu.tenantId);
    // The cached list is shared; make sure the opt-in-only (ELITE) set is loaded
    // before eligibility, as loadRosters would have done on a cold path.
    await ensureOptInOnlyLoaded();

    // Only exams targeting the student's class (or all-class exams), matching
    // section if scoped, honouring any ad-hoc roster add/remove overrides.
    const visible = base.exams.filter((e) => isEligible(e, stu, base.rosters.get(e.id)));

    const exIds = visible.map((e) => e.id);
    const myAttempts = exIds.length
      ? await db.select().from(schema.attempts).where(and(inArray(schema.attempts.examId, exIds), eq(schema.attempts.studentId, sid)))
      : [];
    const aMap = new Map(myAttempts.map((a) => [a.examId, a]));
    const qMap = base.questionCounts;

    const now = Date.now();
    const exams = visible.map((e) => {
      const a = aMap.get(e.id);
      const startMs = e.startAt ? new Date(e.startAt).getTime() : null;
      const endMs = e.endAt ? new Date(e.endAt).getTime() : null;
      let phase: string;
      if (a && (a.status === "submitted" || a.status === "graded")) phase = "finished";
      else if (a && a.status === "in_progress") phase = "in_progress";
      // Exam window has closed and the student never submitted → Absent.
      else if (endMs && now > endMs) phase = "absent";
      // Only show the full-screen "live" gate when the exam is actually live:
      // either the admin flipped it to "live", or it's scheduled and its start
      // time has arrived. A scheduled exam with no start time (or a future
      // start) is still just upcoming — never auto-treated as live.
      else if (e.status === "live" || (startMs && now >= startMs)) phase = "available";
      else phase = "upcoming";
      // Results stay locked until the exam closes for everyone — either the
      // admin flipped it to "finished", or its deadline has passed. This stops
      // early finishers from leaking the answer key to students still writing.
      const resultsReady = e.status === "finished" || (endMs != null && now > endMs);
      return {
        id: e.id,
        title: e.title,
        status: e.status,
        durationMin: e.durationMin,
        totalPoints: e.totalPoints,
        questionCount: qMap.get(e.id) ?? 0,
        startAt: e.startAt,
        endAt: e.endAt,
        phase,
        resultsReady,
        attempt: a ? { id: a.id, status: a.status, score: a.score, submittedAt: a.submittedAt } : null,
      };
    });
    return c.json({ exams, student: { id: stu.id, name: stu.name, rollNo: stu.rollNo, email: stu.email } }, 200);
  })

  // Full exam bundle for offline download: all questions with options (no answers).
  .get("/student/exams/:id/bundle", async (c) => {
    const sid = await verifyStudentToken(c.req.header("x-student-token"));
    if (!sid) return c.json({ message: "Unauthorized" }, 401);
    const [stu] = await db.select().from(schema.students).where(eq(schema.students.id, sid)).limit(1);
    if (!stu) return c.json({ message: "Unauthorized" }, 401);
    const eid = c.req.param("id");
    const [exam] = await db.select().from(schema.exams).where(and(eq(schema.exams.id, eid), eq(schema.exams.tenantId, stu.tenantId))).limit(1);
    if (!exam) return c.json({ message: "Not found" }, 404);

    // Cached per exam (see getExamPaper): identical for every student.
    const { eqs, qs } = await getExamPaper(eid);
    const qById = new Map(qs.map((q) => [q.id, q]));
    // Shuffle each question's OPTIONS for this student too. Question order alone
    // left the answer key identical for everyone, so a paper keyed "B" on 55% of
    // its questions rewarded anyone who just pressed B all the way down. The
    // permutation is display-only: answers.response keeps storing the ORIGINAL
    // index, so grading and every already-graded attempt are untouched.
    const optOrder = optionTranslator(stu.id, exam.id, qs, true);
    // Ship only what the client needs to render — never the correct answer.
    const questions = eqs.map((eq2) => {
      const q = qById.get(eq2.questionId);
      const meta = (q?.meta ?? {}) as Record<string, unknown>;
      const safeMeta: Record<string, unknown> = {};
      if (q?.type === "coding") {
        safeMeta.language = meta.language;
        safeMeta.starter = meta.starter;
      }
      return {
        id: eq2.questionId,
        order: eq2.order,
        points: eq2.points,
        type: q?.type ?? "short",
        prompt: q?.prompt ?? "",
        options: optOrder.display(eq2.questionId, (q?.options as string[] | null) ?? null),
        difficulty: q?.difficulty ?? "medium",
        topic: q?.topic ?? null,
        meta: safeMeta,
      };
    });
    // Randomise question order per student — same questions, different sequence.
    // Deterministic seed (student + exam) keeps the order stable across reloads/resume.
    let seed = 0;
    const seedStr = `${stu.id}:${exam.id}`;
    for (let i = 0; i < seedStr.length; i++) seed = (seed * 31 + seedStr.charCodeAt(i)) >>> 0;
    const rand = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 0xffffffff; };
    const shuffled = [...questions];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(rand() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }

    const gs = await getGlobalSettings();
    const proctoring = { ...schema.DEFAULT_PROCTORING, ...(gs.proctoring ?? {}) };
    return c.json({
      exam: { id: exam.id, title: exam.title, durationMin: exam.durationMin, totalPoints: exam.totalPoints, startAt: exam.startAt, endAt: exam.endAt },
      questions: shuffled,
      proctoring,
      // Tells the server which rendering scheme this paper was built with. The
      // client caches the bundle offline and echoes this back on every write, so a
      // paper rendered by an older build (original option order) is still read
      // correctly instead of being un-permuted twice. Not a secret — it identifies
      // the scheme, never the permutation.
      optionOrder: OPTION_ORDER_TOKEN,
    }, 200);
  })

  // Start (or resume) an attempt. Returns a server-anchored absolute endAt so the
  // timer can't be cheated by clock changes or app restarts.
  .post("/student/attempts/:examId/start", async (c) => {
    const sid = await verifyStudentToken(c.req.header("x-student-token"));
    if (!sid) return c.json({ message: "Unauthorized" }, 401);
    const eid = c.req.param("examId");
    const [exam] = await db.select().from(schema.exams).where(eq(schema.exams.id, eid)).limit(1);
    if (!exam) return c.json({ message: "Not found" }, 404);
    // Only eligible students (cohort match or explicitly added, not removed) may start.
    const [startStu] = await db.select().from(schema.students).where(eq(schema.students.id, sid)).limit(1);
    if (!startStu || !startStu.enabled || !isEligible(exam, startStu, await loadRoster(eid))) {
      return c.json({ message: "Not eligible for this exam" }, 403);
    }
    // The scheme token of the bundle the client actually rendered. Parsed up front
    // because it gets STAMPED ONTO THE ATTEMPT: once the exam is over the bundle is
    // gone from the client, so the review endpoint has no other way to know whether
    // this student saw shuffled options or the original order. NULL on every attempt
    // that predates this feature, which is exactly what makes old reviews render
    // byte-for-byte as before.
    const startBody = await c.req.json().catch(() => ({} as Record<string, unknown>));
    const startScheme = tokenIsCurrent(startBody?.optionOrder) ? OPTION_ORDER_TOKEN : null;
    // Which device/browser is this paper being sat on? Proctoring is a CLIENT
    // capability, so when a webcam or fullscreen check silently never worked, this
    // string is the only thing that can answer "what was it running on?". Stamped
    // once, diagnostic only, and truncated because a UA is attacker-controlled text.
    const startUA = (c.req.header("user-agent") ?? "").trim().slice(0, 300) || null;

    // Always resolve to the OLDEST attempt for this (exam, student) pair. A stable
    // deterministic pick means /start /status /heartbeat /resume all agree on the
    // same row even if a legacy duplicate still exists.
    let [attempt] = await db.select().from(schema.attempts)
      .where(and(eq(schema.attempts.examId, eid), eq(schema.attempts.studentId, sid)))
      .orderBy(schema.attempts.createdAt, schema.attempts.id).limit(1);
    if (attempt && (attempt.status === "submitted" || attempt.status === "graded")) {
      return c.json({ message: "Already submitted" }, 409);
    }
    const now = Date.now();

    // ---- Per-tenant concurrency ceiling (lib/tenant-quota.ts) ----
    // Checked ONLY where a new live sitter is admitted: an attempt about to be
    // created, or a not_started roster row about to go in_progress. An attempt
    // that is already in_progress falls straight through, so a reload, a resume
    // or a flaky network retry can never be refused by a quota — ejecting a
    // student from a paper they are halfway through would be worse than the
    // overload the ceiling exists to prevent.
    // Costs nothing until somebody sets a number: the resolved limit is null by
    // default and the count is never taken.
    const admitsNewSitter = !attempt || attempt.status === "not_started";
    if (admitsNewSitter) {
      const quota = await tenantQuotas.load(db, exam.tenantId, await getGlobalSettings());
      if (quota.maxConcurrentAttempts !== null) {
        const gate = await concurrencyGate.check(db, exam.tenantId, quota.maxConcurrentAttempts);
        if (!gate.allowed) {
          return c.json(
            {
              message: "Your college has reached its limit of simultaneous exam attempts. Please wait a moment and press Start again.",
              code: "tenant_concurrency_quota",
              live: gate.live,
              limit: gate.limit,
            },
            429,
          );
        }
      }
    }

    if (!attempt) {
      const startedAt = new Date(now);
      // Freeze the student's section onto the attempt. Reports read this snapshot, so
      // a later section change (e.g. promotion into ELITE) never rewrites history.
      let sectionSnapshot: string | null = null;
      if (startStu.classId) {
        const [snapCls] = await db.select({ code: schema.classes.code }).from(schema.classes).where(eq(schema.classes.id, startStu.classId)).limit(1);
        sectionSnapshot = snapCls?.code ?? null;
      }
      // RACE-SAFE CREATE. A student clicking Start twice, a flaky network retry, or
      // SEB reloading the page fires several /start calls at once. Select-then-insert
      // lets every one of them insert a row (they all see an empty SELECT), which is
      // what produced up to 44 duplicate rows for one student. The unique index on
      // (exam_id, student_id) now makes only the first insert win; the losers catch
      // the conflict and re-read the winning row, so all callers converge on one attempt.
      try {
        [attempt] = await db.insert(schema.attempts)
          .values({ id: id("att"), examId: eid, studentId: sid, status: "in_progress", startedAt, sectionSnapshot, optionOrder: startScheme, userAgent: startUA })
          .returning();
      } catch {
        [attempt] = await db.select().from(schema.attempts)
          .where(and(eq(schema.attempts.examId, eid), eq(schema.attempts.studentId, sid)))
          .orderBy(schema.attempts.createdAt, schema.attempts.id).limit(1);
      }
      // Lost the race AND could not read the winner (should not happen) — fail loudly
      // rather than continue with an undefined attempt.
      if (!attempt) return c.json({ message: "Could not start attempt, please retry" }, 503);
      if (attempt.status === "submitted" || attempt.status === "graded") {
        return c.json({ message: "Already submitted" }, 409);
      }
    } else if (attempt.status === "not_started") {
      [attempt] = await db.update(schema.attempts).set({ status: "in_progress", startedAt: new Date(now), optionOrder: startScheme }).where(eq(schema.attempts.id, attempt.id)).returning();
    }
    // Count this sitter against the cached live total, so a start burst inside one
    // cache window is gated on admissions rather than on a stale count.
    if (admitsNewSitter) concurrencyGate.note(exam.tenantId);
    // Mark the student as seen (drives Live Monitor online/offline). Also record the
    // display scheme if it is not on the attempt yet — an attempt created by an older
    // build, or by a /start that raced this one, still needs the stamp so its review
    // renders in the order the student saw. Only ever written when the client reports
    // the current scheme, and never overwritten with null.
    const stampScheme = startScheme !== null && attempt.optionOrder !== startScheme;
    // Same one-write rule for the user-agent: only ever filled in when the row has
    // none (an attempt created by an older build, or the /start that lost the race),
    // never overwritten — the FIRST device that opened the paper is the useful fact.
    const stampUA = startUA !== null && !attempt.userAgent;
    const startSet: Record<string, unknown> = { lastSeenAt: new Date(now) };
    if (stampScheme) startSet.optionOrder = startScheme;
    if (stampUA) startSet.userAgent = startUA;
    await db.update(schema.attempts).set(startSet).where(eq(schema.attempts.id, attempt.id));
    if (stampScheme) attempt = { ...attempt, optionOrder: startScheme };
    if (stampUA) attempt = { ...attempt, userAgent: startUA };
    // Return the server-saved answers so a resume/reopen on a FRESH browser
    // (cleared cache, different machine, SEB kiosk that wipes local storage)
    // restores the student's prior work instead of showing a blank exam. The
    // client merges these under its own local answers (local wins per-question).
    const startSaved = await db.select().from(schema.answers).where(eq(schema.answers.attemptId, attempt.id));
    // Stored responses are ORIGINAL option indices; the client renders against the
    // shuffled bundle, so translate them into ITS display order. Only when the
    // client reports the current scheme token — a client on an older cached bundle
    // sees the original order and must get its answers back untranslated.
    const startTrans = await answerTranslator(attempt.examId, sid, startScheme);
    const startAnswers: Record<string, unknown> = {};
    for (const a of startSaved) if (a.response != null) startAnswers[a.questionId] = startTrans.toDisplay(a.questionId, a.response);
    // Absolute deadline includes admin extra-minutes + global hold time.
    const endAtMs = effectiveEndMs(exam, attempt, now);
    return c.json({ attemptId: attempt.id, startedAt: attempt.startedAt, endAt: new Date(endAtMs), serverNow: new Date(now), durationMin: exam.durationMin, pausedMs: attempt.pausedMs ?? 0, held: !!exam.heldAt, answers: startAnswers }, 200);
  })

  // Read-only status probe. Used by the client on mount to detect an in-progress
  // attempt after a page refresh WITHOUT mutating state (never transitions
  // not_started -> in_progress like /start does). Returns the server-anchored
  // endAt when the attempt is already running, so the timer stays un-cheatable.
  .get("/student/attempts/:examId/status", async (c) => {
    const sid = await verifyStudentToken(c.req.header("x-student-token"));
    if (!sid) return c.json({ message: "Unauthorized" }, 401);
    const eid = c.req.param("examId");
    // Cached read: this is a poll, and the exam row is identical for every student.
    const exam = await getExamForPolling(eid);
    if (!exam) return c.json({ message: "Not found" }, 404);
    const [attempt] = await db.select().from(schema.attempts).where(and(eq(schema.attempts.examId, eid), eq(schema.attempts.studentId, sid))).orderBy(schema.attempts.createdAt, schema.attempts.id).limit(1);
    const now = Date.now();
    if (!attempt) {
      return c.json({ status: "not_started", attemptId: null, startedAt: null, endAt: null, serverNow: new Date(now), held: false }, 200);
    }
    if (attempt.status === "in_progress") {
      // Refresh the seen timestamp (drives the Live Monitor online dot) and
      // return the live deadline. This is the only side effect here.
      await db.update(schema.attempts).set({ lastSeenAt: new Date(now) }).where(eq(schema.attempts.id, attempt.id));
      const endAtMs = effectiveEndMs(exam, attempt, now);
      // Include server-saved answers so a refresh/reopen resume on a fresh
      // browser restores prior work rather than a blank exam (client merges
      // these under its local answers).
      // Two columns, not the whole row: a coding answer's response is the big field
      // and the score/feedback columns are not used here.
      const stSaved = await db
        .select({ questionId: schema.answers.questionId, response: schema.answers.response })
        .from(schema.answers)
        .where(eq(schema.answers.attemptId, attempt.id));
      // Same translation as /start: stored indices are original, the client's screen
      // is in ITS shuffled display order. GET, so the scheme token arrives as a query
      // param rather than in a body.
      const stTrans = await answerTranslator(attempt.examId, sid, c.req.query("optionOrder"));
      const stAnswers: Record<string, unknown> = {};
      for (const a of stSaved) if (a.response != null) stAnswers[a.questionId] = stTrans.toDisplay(a.questionId, a.response);
      return c.json({ status: "in_progress", attemptId: attempt.id, startedAt: attempt.startedAt, endAt: new Date(endAtMs), serverNow: new Date(now), held: !!exam.heldAt, answers: stAnswers }, 200);
    }
    return c.json({ status: attempt.status, attemptId: attempt.id, startedAt: attempt.startedAt, endAt: null, serverNow: new Date(now), held: false, score: attempt.score }, 200);
  })

  // Resume a locked exam after an internet drop. The client reports how long it
  // was offline (offlineMs); we add that to pausedMs so the deadline shifts by the
  // same amount (timer effectively froze during the outage). Returns the new endAt.
  .post("/student/attempts/:examId/resume", async (c) => {
    const sid = await verifyStudentToken(c.req.header("x-student-token"));
    if (!sid) return c.json({ message: "Unauthorized" }, 401);
    const eid = c.req.param("examId");
    const [exam] = await db.select().from(schema.exams).where(eq(schema.exams.id, eid)).limit(1);
    if (!exam) return c.json({ message: "Not found" }, 404);
    const [attempt] = await db.select().from(schema.attempts).where(and(eq(schema.attempts.examId, eid), eq(schema.attempts.studentId, sid))).orderBy(schema.attempts.createdAt, schema.attempts.id).limit(1);
    if (!attempt) return c.json({ message: "No attempt to resume" }, 404);
    if (attempt.status === "submitted" || attempt.status === "graded") return c.json({ message: "Already submitted" }, 409);
    const b = await c.req.json().catch(() => ({}));
    const now = Date.now();
    // Prefer server-measured pause (lastPausedAt) when present; fall back to the
    // client-reported offline duration. Clamp to the exam's total duration.
    let offlineMs = Number(b.offlineMs);
    if (!Number.isFinite(offlineMs) || offlineMs < 0) offlineMs = 0;
    if (attempt.lastPausedAt) {
      const serverGap = now - new Date(attempt.lastPausedAt).getTime();
      if (serverGap > offlineMs) offlineMs = serverGap;
    }
    offlineMs = Math.min(offlineMs, exam.durationMin * 60_000);
    const newPaused = (attempt.pausedMs ?? 0) + Math.round(offlineMs);
    await db.update(schema.attempts).set({ pausedMs: newPaused, lastPausedAt: null }).where(eq(schema.attempts.id, attempt.id));
    const startedMs = attempt.startedAt ? new Date(attempt.startedAt).getTime() : now;
    // Base = startedAt + duration capped by the window; add pausedMs on top so the
    // outage time extends the deadline beyond the window cap.
    let base = startedMs + exam.durationMin * 60_000;
    if (exam.endAt) base = Math.min(base, new Date(exam.endAt).getTime());
    const endAtMs = base + newPaused;
    return c.json({ attemptId: attempt.id, endAt: new Date(endAtMs), serverNow: new Date(now), pausedMs: newPaused }, 200);
  })

  // Mark that an exam was paused (internet lost). Records lastPausedAt so the
  // server can measure the true outage even if the client under-reports.
  .post("/student/attempts/:examId/pause", async (c) => {
    const sid = await verifyStudentToken(c.req.header("x-student-token"));
    if (!sid) return c.json({ message: "Unauthorized" }, 401);
    const eid = c.req.param("examId");
    const [attempt] = await db.select().from(schema.attempts).where(and(eq(schema.attempts.examId, eid), eq(schema.attempts.studentId, sid))).orderBy(schema.attempts.createdAt, schema.attempts.id).limit(1);
    if (!attempt) return c.json({ message: "No attempt" }, 404);
    if (attempt.status === "submitted" || attempt.status === "graded") return c.json({ ok: true }, 200);
    if (!attempt.lastPausedAt) {
      await db.update(schema.attempts).set({ lastPausedAt: new Date() }).where(eq(schema.attempts.id, attempt.id));
    }
    return c.json({ ok: true }, 200);
  })

  // Heartbeat: the running client pings this every ~15s. Records lastSeenAt (for
  // the Live Monitor online/offline dot) and returns the current hold state +
  // the up-to-date absolute deadline (so an admin hold/resume or extra-time grant
  // is picked up by every student without a page reload).
  //
  // This is the highest-volume endpoint during an exam (1000 students / 15s ≈ 67
  // requests a second) and it used to cost three remote round trips each time:
  // read the exam, read the attempt, write lastSeenAt. It now costs ONE, and that
  // one is a READ — the exam row comes from a 3s coalesced cache (every student is
  // reading the same row), the attempt read below doubles as the row that
  // effectiveEndMs needs, and lastSeenAt is handed to the coalescing queue instead
  // of being written here. The queue folds all 67/s into one batched UPDATE every
  // 5s (see lib/heartbeat-queue.ts for the staleness budget); presence is the one
  // thing cheap enough to lose a few seconds of, and writes are both the scarce
  // quota (25M/month vs 2.5B reads) and the serialized resource on Turso.
  // The attempt select matches at most one row because `attempts_exam_student_uq`
  // makes (exam_id, student_id) unique, and that index is asserted on every boot
  // and reported by /api/health.
  .post("/student/heartbeat/:examId", async (c) => {
    const sid = await verifyStudentToken(c.req.header("x-student-token"));
    if (!sid) return c.json({ message: "Unauthorized" }, 401);
    const eid = c.req.param("examId");
    const exam = await getExamForPolling(eid);
    if (!exam) return c.json({ message: "Not found" }, 404);
    const now = Date.now();
    // Narrow on purpose: only what effectiveEndMs and the queue need. Coding
    // attempts carry no wide columns here, but there is no reason to ship any.
    const [attempt] = await db
      .select({
        id: schema.attempts.id,
        startedAt: schema.attempts.startedAt,
        pausedMs: schema.attempts.pausedMs,
      })
      .from(schema.attempts)
      .where(and(eq(schema.attempts.examId, eid), eq(schema.attempts.studentId, sid)))
      .limit(1);
    if (!attempt) return c.json({ message: "No attempt" }, 404);
    heartbeats.markSeen(attempt.id, now);
    const endAtMs = effectiveEndMs(exam, attempt, now);
    return c.json({ held: !!exam.heldAt, endAt: new Date(endAtMs), serverNow: new Date(now) }, 200);
  })

  // Per-answer autosave. The running client calls this the moment a student
  // answers a question and navigates (plus a short debounce while typing), and
  // flushes any offline-buffered answers here on reconnect. Upserts each answer
  // WITHOUT grading — grading happens only at submit / auto-submit. Keeping every
  // answer server-side in real time means a mid-exam disconnect no longer loses
  // work, and `answeredCount` gives reports an accurate "answered N/total".
  .post("/student/attempts/:attemptId/answers", async (c) => {
    const sid = await verifyStudentToken(c.req.header("x-student-token"));
    if (!sid) return c.json({ message: "Unauthorized" }, 401);
    const aid = c.req.param("attemptId");
    const [attempt] = await db.select().from(schema.attempts).where(and(eq(schema.attempts.id, aid), eq(schema.attempts.studentId, sid))).limit(1);
    if (!attempt) return c.json({ message: "Not found" }, 404);
    // Once submitted/graded the answer set is frozen — ignore late autosaves.
    if (attempt.status === "submitted" || attempt.status === "graded") {
      return c.json({ ok: true, frozen: true, answeredCount: attempt.answeredCount }, 200);
    }

    const body = await c.req.json().catch(() => ({}));
    const incoming: { questionId: string; response: unknown }[] = Array.isArray(body.answers)
      ? body.answers
      : body.questionId ? [{ questionId: body.questionId, response: body.response }] : [];

    // Restrict to questions that actually belong to this exam (ignore stray ids).
    // Cached per exam: this list is frozen while the exam runs, and it used to be
    // re-read on every autosave — then read AGAIN inside answerTranslator.
    const { questionIds } = await getExamQuestionSet(attempt.examId);
    const validQ = new Set(questionIds);

    // The client sends the option index it DISPLAYED. Options are shuffled per
    // student, so convert back to the original index before storing — the grader and
    // every report read original indices.
    const saveTrans = await answerTranslator(attempt.examId, sid, body?.optionOrder);

    // Upsert against answers_attempt_question_uq. The old select-then-insert had
    // the same race as /start: two autosaves in flight for one question both saw
    // no existing row and both inserted, and the grader then counted both rows.
    // Only `response` is touched here — never clobber a score the grader wrote.
    // One statement for the whole batch instead of one per answer. A reconnect
    // flush can carry every question in the paper, and each upsert was its own
    // remote round trip. Deduped by questionId first (keeping the latest value):
    // SQLite refuses to apply ON CONFLICT twice to the same row in one statement.
    const byQuestion = new Map<string, unknown>();
    for (const a of incoming) {
      if (!a || !validQ.has(a.questionId)) continue;
      byQuestion.set(a.questionId, a.response == null ? null : saveTrans.toOriginal(a.questionId, a.response));
    }
    const answerRows = [...byQuestion].map(([questionId, stored]) => ({
      id: id("ans"),
      attemptId: aid,
      questionId,
      response: stored,
      score: null,
      maxScore: null,
      autoGraded: false,
    }));
    // Chunked because SQLite/libSQL caps bound variables per statement.
    for (let i = 0; i < answerRows.length; i += 50) {
      await db.insert(schema.answers)
        .values(answerRows.slice(i, i + 50))
        .onConflictDoUpdate({
          target: [schema.answers.attemptId, schema.answers.questionId],
          // `excluded` is the row we just tried to insert — the same value the
          // per-answer upsert used to write, applied row by row by SQLite.
          set: { response: dsql`excluded.response` },
        });
    }

    // Recompute answeredCount from rows that carry real content. Only the response
    // column is read: `hasContent` is the one thing that decides this, and pulling
    // whole rows meant shipping every coding answer back over the wire.
    const rows = await db
      .select({ response: schema.answers.response })
      .from(schema.answers)
      .where(eq(schema.answers.attemptId, aid));
    const answeredCount = rows.filter((r) => hasContent(r.response)).length;
    // Backstop for the review stamp: /start may have run on an older build, or the
    // attempt may have been created by the auto-submit sweep, and the review endpoint
    // has no bundle to consult after the exam. Written at most once (only when it
    // differs) and never cleared, so a client on a stale bundle cannot un-stamp an
    // attempt that is genuinely being sat in shuffled order.
    const saveScheme = saveTrans.active && attempt.optionOrder !== OPTION_ORDER_TOKEN ? OPTION_ORDER_TOKEN : null;
    await db.update(schema.attempts)
      .set(saveScheme ? { answeredCount, lastSeenAt: new Date(), optionOrder: saveScheme } : { answeredCount, lastSeenAt: new Date() })
      .where(eq(schema.attempts.id, aid));

    return c.json({ ok: true, answeredCount }, 200);
  })

  // ---- Proctoring: flush integrity events as they happen ----
  // The running client posts every violation here immediately (camera loss, tab
  // switch, fullscreen exit, extra monitor, blocked copy/paste…) so the evidence
  // survives a crash, a kill-the-app cheat attempt, or a never-submitted attempt.
  // Events are still resent at submit as a backstop; persistIntegrityEvents
  // dedupes on (type, at).
  .post("/student/attempts/:attemptId/events", async (c) => {
    const sid = await verifyStudentToken(c.req.header("x-student-token"));
    if (!sid) return c.json({ message: "Unauthorized" }, 401);
    const aid = c.req.param("attemptId");
    // Authorization is ALL this route needs from the attempt - nothing below reads
    // a single column off it. Answered from memory, because attemptId -> studentId
    // is written once and never updated; see lib/attempt-owner.ts.
    if (!(await attemptOwners.authorize(db, aid, sid))) return c.json({ message: "Not found" }, 404);
    const body = await c.req.json().catch(() => ({}));
    const saved = await persistIntegrityEvents(aid, body.events ?? body.integrityEvents);
    return c.json({ ok: true, saved }, 200);
  })

  // ---- Proctoring: presigned upload URL for a violation snapshot ----
  // The client grabs a JPEG frame from the live webcam at the moment of a
  // violation, PUTs it straight to object storage with this URL, then attaches
  // the returned key to the event. Keys are scoped to the attempt's own prefix.
  .post("/student/attempts/:attemptId/snapshot-url", async (c) => {
    const sid = await verifyStudentToken(c.req.header("x-student-token"));
    if (!sid) return c.json({ message: "Unauthorized" }, 401);
    const aid = c.req.param("attemptId");
    // Authorization is ALL this route needs from the attempt - nothing below reads
    // a single column off it. Answered from memory, because attemptId -> studentId
    // is written once and never updated; see lib/attempt-owner.ts.
    if (!(await attemptOwners.authorize(db, aid, sid))) return c.json({ message: "Not found" }, 404);
    const key = `${INTEGRITY_PREFIX(aid)}${Date.now()}-${id()}.jpg`;
    try {
      const url = await presignPut(key, "image/jpeg");
      return c.json({ ok: true, url, key }, 200);
    } catch {
      // Storage misconfigured — never block the exam over a snapshot.
      return c.json({ ok: false, url: null, key: null }, 200);
    }
  })

  // Submit an attempt: persist answers, auto-grade objective questions
  // immediately, and AI-grade subjective/coding on submit.
  .post("/student/attempts/:attemptId/submit", async (c) => {
    const sid = await verifyStudentToken(c.req.header("x-student-token"));
    if (!sid) return c.json({ message: "Unauthorized" }, 401);
    const aid = c.req.param("attemptId");
    const [attempt] = await db.select().from(schema.attempts).where(and(eq(schema.attempts.id, aid), eq(schema.attempts.studentId, sid))).limit(1);
    if (!attempt) return c.json({ message: "Not found" }, 404);
    if (attempt.status === "submitted" || attempt.status === "graded") return c.json({ ok: true, alreadySubmitted: true }, 200);

    const body = await c.req.json().catch(() => ({}));
    const rawResp: { questionId: string; response: unknown }[] = Array.isArray(body.answers) ? body.answers : [];
    // Convert displayed option indices back to original indices before grading — the
    // same translation the autosave path applies, so a submit and an autosave of the
    // same click always store the identical value.
    const submitTrans = await answerTranslator(attempt.examId, sid, body?.optionOrder);
    const respArr = rawResp.map((a) => (
      a && typeof a.questionId === "string" && a.response != null
        ? { ...a, response: submitTrans.toOriginal(a.questionId, a.response) }
        : a
    ));

    // Last chance to stamp the display scheme on the attempt: after this the client
    // clears its bundle, so if it is not recorded now the review can never know the
    // student sat a shuffled paper. Write-once, never cleared (see autosave).
    if (submitTrans.active && attempt.optionOrder !== OPTION_ORDER_TOKEN) {
      try {
        await db.update(schema.attempts).set({ optionOrder: OPTION_ORDER_TOKEN }).where(eq(schema.attempts.id, aid));
      } catch { /* cosmetic for review only — never block a submit over it */ }
    }

    // Backstop for proctoring evidence: the client flushes violations live to
    // /events, but resends the whole list here in case a flush failed offline.
    // Deduped on (type, at) so nothing is stored twice. Never blocks the submit.
    try { await persistIntegrityEvents(aid, body.integrityEvents); } catch { /* evidence is best-effort */ }

    // Global AI provider for grading (single global settings row).
    let provider: string | null = null;
    try {
      const s = await getGlobalSettings();
      provider = s?.aiProvider ?? null;
    } catch { /* ignore */ }

    // Persist + grade through the shared path. Objective graded inline; subjective
    // + coding deferred to the background queue. The same path is reused by the
    // server-side auto-submit sweep for abandoned attempts.
    let run = submitsInFlight.get(aid);
    if (!run) {
      run = (async () => {
        const paper = await getExamPaper(attempt.examId);
        return finalizeAttempt(attempt, respArr, provider, undefined, paper);
      })().finally(() => submitsInFlight.delete(aid));
      submitsInFlight.set(aid, run);
    }
    const { score, status, gradeAt } = await run;

    // `gradeAt` is when the deferred grading batch becomes due (null = nothing to
    // wait for, i.e. graded already or grading now). The client uses it to decide
    // whether to keep polling for a score: with grading held until after the exam
    // closes, a fast poll would burn 40 reads per student and never see "graded".
    return c.json({ ok: true, attemptId: aid, score, status, gradeAt }, 200);
  })

  // Review a finished attempt: per-question response, score, correct answer + AI notes.
  .get("/student/attempts/:attemptId/review", async (c) => {
    const sid = await verifyStudentToken(c.req.header("x-student-token"));
    if (!sid) return c.json({ message: "Unauthorized" }, 401);
    const aid = c.req.param("attemptId");
    const [attempt] = await db.select().from(schema.attempts).where(and(eq(schema.attempts.id, aid), eq(schema.attempts.studentId, sid))).limit(1);
    if (!attempt) return c.json({ message: "Not found" }, 404);
    const [exam] = await db.select().from(schema.exams).where(eq(schema.exams.id, attempt.examId)).limit(1);
    // Gate results until the exam closes for everyone (admin finished it, or the
    // deadline passed) — prevents early finishers leaking the answer key.
    const endMs = exam?.endAt ? new Date(exam.endAt).getTime() : null;
    const resultsReady = exam?.status === "finished" || (endMs != null && Date.now() > endMs);
    if (!resultsReady) return c.json({ message: "Results are locked until this exam closes. Please check back later." }, 403);
    const ans = await db.select().from(schema.answers).where(eq(schema.answers.attemptId, aid));
    const aMap = new Map(ans.map((a) => [a.questionId, a]));
    const eqs = await db.select().from(schema.examQuestions).where(eq(schema.examQuestions.examId, attempt.examId)).orderBy(schema.examQuestions.order);
    const qids = eqs.map((q) => q.questionId);
    const qs = qids.length ? await db.select().from(schema.questions).where(inArray(schema.questions.id, qids)) : [];
    const qById = new Map(qs.map((q) => [q.id, q]));

    // Show the review in the SAME option order the student sat the exam in,
    // otherwise "you chose B" contradicts the B they actually clicked. Options,
    // correct answer and response are all translated together, so the payload is
    // self-consistent; nothing stored changes.
    //
    // Gated on the scheme recorded ON THIS ATTEMPT, not on the current build. The
    // exam is over, so there is no bundle left to ask; every attempt sat before
    // shuffling existed has option_order = NULL and must render in the authored
    // order it was actually taken in. Translating those would show a student an
    // option list they never saw and move the tick onto a different line.
    const revTrans = optionTranslator(sid, attempt.examId, qs, tokenIsCurrent(attempt.optionOrder));

    const questions = eqs.map((eq2) => {
      const q = qById.get(eq2.questionId);
      const a = aMap.get(eq2.questionId);
      return {
        id: eq2.questionId,
        type: q?.type ?? "short",
        prompt: q?.prompt ?? "",
        options: revTrans.display(eq2.questionId, (q?.options as string[] | null) ?? null),
        correct: q?.correct != null ? revTrans.toDisplay(eq2.questionId, q.correct) : null,
        points: eq2.points,
        response: a?.response != null ? revTrans.toDisplay(eq2.questionId, a.response) : null,
        score: a?.score ?? null,
        maxScore: a?.maxScore ?? eq2.points,
        aiNotes: a?.aiNotes ?? null,
        explanation: (q?.meta as any)?.explanation ?? null,
      };
    });
    return c.json({
      attempt: { id: attempt.id, status: attempt.status, score: attempt.score, submittedAt: attempt.submittedAt },
      exam: exam ? { id: exam.id, title: exam.title, totalPoints: exam.totalPoints } : null,
      questions,
    }, 200);
  })

  // Run a student's code against Judge0 (RapidAPI) — lets them test before submit.
  // Returns stdout / stderr / compile output; never reveals hidden test cases.
  .post("/student/run-code", async (c) => {
    const sid = await verifyStudentToken(c.req.header("x-student-token"));
    if (!sid) return c.json({ message: "Unauthorized" }, 401);
    const b = await c.req.json().catch(() => ({}));
    const source = String(b.source ?? "");
    const language = String(b.language ?? "python").toLowerCase();
    const stdin = b.stdin != null ? String(b.stdin) : "";
    if (!source.trim()) return c.json({ ok: false, message: "Write some code before running." }, 400);

    // Judge0 CE language IDs (compatible across RapidAPI CE and self-hosted CE).
    const LANG: Record<string, number> = {
      python: 71, python3: 71, py: 71,
      javascript: 63, js: 63, node: 63,
      java: 62, c: 50, cpp: 54, "c++": 54, csharp: 51, "c#": 51,
      go: 60, ruby: 72, php: 68, typescript: 74, ts: 74, kotlin: 78, swift: 83, rust: 73,
    };
    const reqLangId = Number(b.languageId);
    const languageId = Number.isFinite(reqLangId) && reqLangId > 0 ? reqLangId : (LANG[language] ?? 71);

    // Resolve the RapidAPI key (settings first, then env). The config provider is
    // re-evaluated at drain time so a settings change takes effect without restart.
    let key: string | null = null;
    try { key = (await getGlobalSettings())?.judge0Key ?? null; } catch { /* ignore */ }
    if (!key) key = process.env.JUDGE0_KEY || null;
    if (!resolveJudge0Config(key)) {
      return c.json({ ok: false, message: "Code execution is not configured. Contact your administrator." }, 503);
    }

    // Enqueue on the global server-side queue. The queue throttles all students
    // together (<=10 req/s), batches runs (<=20) into single HTTP calls, polls
    // each batch, and retries transient failures with backoff. The student's
    // request stays synchronous — it just waits in line (bounded by MAX_WAIT_MS).
    const result = await judge0Queue.run(
      { source, languageId, stdin },
      () => resolveJudge0Config(key),
    );

    if (!result.ok) {
      return c.json({ ok: false, message: result.message ?? "Couldn't run your code. Try again." }, (result.httpStatus ?? 502) as never);
    }

    // Best-effort usage counter.
    try { await db.update(schema.settings).set({ judge0Used: dsql`${schema.settings.judge0Used} + 1` }).where(eq(schema.settings.id, "global")); } catch { /* ignore */ }
    return c.json({
      ok: true,
      stdout: result.stdout,
      stderr: result.stderr,
      compileOutput: result.compileOutput,
      status: result.status,
      time: result.time,
      memory: result.memory,
    }, 200);
  })

  // =================== QUESTIONS ===================
  // =================== CATEGORIES ===================
  .get("/categories", requireAuth, requirePermission("questionBank"), async (c) => {
    const p = c.get("profile")!;
    const tid = p.role === "super_admin" && c.req.query("tenantId") ? c.req.query("tenantId")! : p.tenantId;
    if (!tid) return c.json({ categories: [] }, 200);
    const rows = await db.select().from(schema.categories).where(eq(schema.categories.tenantId, tid)).orderBy(desc(schema.categories.createdAt));
    const counts = await db
      .select({ categoryId: schema.questions.categoryId, n: dsql<number>`count(*)` })
      .from(schema.questions)
      .where(eq(schema.questions.tenantId, tid))
      .groupBy(schema.questions.categoryId);
    const cmap = new Map(counts.map((x) => [x.categoryId, x.n]));
    return c.json({ categories: rows.map((r) => ({ ...r, questionCount: cmap.get(r.id) ?? 0 })) }, 200);
  })
  .post("/categories", requireAuth, requirePermission("questionBank"), async (c) => {
    const p = c.get("profile")!;
    const b = await c.req.json();
    const tid = p.role === "super_admin" ? (b.tenantId ?? p.tenantId) : p.tenantId;
    if (!tid) return c.json({ message: "No tenant" }, 400);
    const [row] = await db
      .insert(schema.categories)
      .values({ id: id("cat"), tenantId: tid, name: b.name, description: b.description ?? null, color: b.color ?? "#1e3a5f" })
      .returning();
    return c.json({ category: row }, 201);
  })
  .patch("/categories/:id", requireAuth, requirePermission("questionBank"), async (c) => {
    const b = await c.req.json();
    const [row] = await db
      .update(schema.categories)
      .set({ name: b.name, description: b.description ?? null, color: b.color ?? "#1e3a5f" })
      .where(eq(schema.categories.id, c.req.param("id")))
      .returning();
    return c.json({ category: row }, 200);
  })
  .delete("/categories/:id", requireAuth, requirePermission("questionBank"), async (c) => {
    const cid = c.req.param("id");
    // Detach questions from this category (keep the questions).
    await db.update(schema.questions).set({ categoryId: null }).where(eq(schema.questions.categoryId, cid));
    await db.delete(schema.categories).where(eq(schema.categories.id, cid));
    return c.json({ ok: true }, 200);
  })

  .get("/questions", requireAuth, requirePermission("questionBank"), async (c) => {
    const p = c.get("profile")!;
    const tid = p.role === "super_admin" && c.req.query("tenantId") ? c.req.query("tenantId")! : p.tenantId;
    if (!tid) return c.json({ questions: [] }, 200);
    const catFilter = c.req.query("categoryId");
    // Visible = own tenant's questions OR any global question from other colleges.
    const visibility = or(eq(schema.questions.tenantId, tid), eq(schema.questions.isGlobal, true));
    const where = catFilter
      ? and(visibility, eq(schema.questions.categoryId, catFilter))
      : visibility;
    const rows = await db
      .select({ q: schema.questions, catName: schema.categories.name, ownerName: schema.tenants.name })
      .from(schema.questions)
      .leftJoin(schema.categories, eq(schema.categories.id, schema.questions.categoryId))
      .leftJoin(schema.tenants, eq(schema.tenants.id, schema.questions.tenantId))
      .where(where)
      .orderBy(desc(schema.questions.createdAt));
    const questions = rows.map((r) => ({
      ...r.q,
      categoryName: r.catName ?? null,
      ownedByOther: r.q.tenantId !== tid,
      ownerName: r.q.tenantId !== tid ? r.ownerName ?? null : null,
    }));
    return c.json({ questions }, 200);
  })
  .post("/questions", requireAuth, requirePermission("questionBank"), async (c) => {
    const p = c.get("profile")!;
    const b = await c.req.json();
    const tid = p.tenantId!;
    const [row] = await db
      .insert(schema.questions)
      .values({
        id: id("q"),
        tenantId: tid,
        categoryId: b.categoryId ?? null,
        isGlobal: b.isGlobal ?? true,
        type: b.type,
        prompt: b.prompt,
        options: b.options ?? null,
        correct: b.correct ?? null,
        meta: b.meta ?? null,
        points: b.points ?? 1,
        difficulty: b.difficulty ?? "medium",
        topic: b.topic ?? null,
        aiGenerated: !!b.aiGenerated,
        createdBy: p.userId,
      })
      .returning();
    return c.json({ question: row }, 201);
  })
  .patch("/questions/:id", requireAuth, requirePermission("questionBank"), async (c) => {
    const b = await c.req.json();
    const patch: Record<string, unknown> = {};
    for (const k of ["type", "prompt", "options", "correct", "meta", "points", "difficulty", "topic", "isGlobal", "categoryId"]) {
      if (k in b) patch[k] = b[k];
    }
    const [row] = await db
      .update(schema.questions)
      .set(patch)
      .where(eq(schema.questions.id, c.req.param("id")))
      .returning();
    // Option-order translation is derived from the option list, so a cached copy of
    // this question must not outlive the edit. Cheap: exams are few.
    examQuestionsCache.clear();
    examPaperCache.clear();
    return c.json({ question: row }, 200);
  })
  .delete("/questions/:id", requireAuth, requirePermission("questionBank"), async (c) => {
    await db.delete(schema.questions).where(eq(schema.questions.id, c.req.param("id")));
    examQuestionsCache.clear();
    examPaperCache.clear();
    return c.json({ ok: true }, 200);
  })
  // AI question generation (preview, not saved)
  .post("/questions/generate", requireAuth, requirePermission("questionBank"), async (c) => {
    const b = await c.req.json();
    const gs = await getGlobalSettings();
    const items = await generateQuestions({
      topic: b.topic,
      type: b.type,
      count: Math.min(Number(b.count) || 5, 15),
      difficulty: b.difficulty || "medium",
      provider: gs.aiProvider,
    });
    // track AI usage
    await db.update(schema.settings).set({ aiUsed: dsql`${schema.settings.aiUsed} + 1` }).where(eq(schema.settings.id, GLOBAL_SETTINGS));
    return c.json({ questions: items }, 200);
  })
  .post("/questions/bulk", requireAuth, requirePermission("questionBank"), async (c) => {
    const p = c.get("profile")!;
    const b = await c.req.json(); // { questions: [...] }
    const tid = p.tenantId!;
    const values = (b.questions as Array<Record<string, unknown>>).map((q) => ({
      id: id("q"),
      tenantId: tid,
      categoryId: (q.categoryId as string) ?? null,
      type: String(q.type),
      prompt: String(q.prompt),
      options: (q.options as string[]) ?? null,
      correct: q.correct ?? null,
      meta: (q.meta as Record<string, unknown>) ?? null,
      points: Number(q.points) || 1,
      difficulty: String(q.difficulty ?? "medium"),
      topic: (q.topic as string) ?? null,
      aiGenerated: true,
      createdBy: p.userId,
    }));
    if (values.length) await db.insert(schema.questions).values(values);
    return c.json({ inserted: values.length }, 201);
  })

  // =================== EXAMS ===================
  .get("/exams", requireAuth, requirePermission("exams"), async (c) => {
    const p = c.get("profile")!;
    const tid = p.role === "super_admin" && c.req.query("tenantId") ? c.req.query("tenantId")! : p.tenantId;
    if (!tid) return c.json({ exams: [] }, 200);
    const rows = await db.select().from(schema.exams).where(eq(schema.exams.tenantId, tid)).orderBy(desc(schema.exams.createdAt));
    // Newest assessment date first (startAt if scheduled, else createdAt).
    const dateVal = (e: (typeof rows)[number]) => {
      const d = e.startAt ?? e.createdAt;
      return d ? new Date(d as any).getTime() : 0;
    };
    rows.sort((a, b) => dateVal(b) - dateVal(a));
    return c.json({ exams: rows }, 200);
  })
  // Single exam with its selected question IDs (for the edit page).
  .get("/exams/:id", requireAuth, requirePermission("exams"), async (c) => {
    const p = c.get("profile")!;
    const eid = c.req.param("id");
    const [row] = await db.select().from(schema.exams).where(eq(schema.exams.id, eid)).limit(1);
    if (!row || (p.role !== "super_admin" && row.tenantId !== p.tenantId)) return c.json({ error: "not found" }, 404);
    const eqs = await db
      .select({ questionId: schema.examQuestions.questionId })
      .from(schema.examQuestions)
      .where(eq(schema.examQuestions.examId, eid))
      .orderBy(schema.examQuestions.order);
    // Explicitly-added students (used to hydrate the "specific students" picker).
    const adds = await db.select({ studentId: schema.examRoster.studentId }).from(schema.examRoster).where(and(eq(schema.examRoster.examId, eid), eq(schema.examRoster.mode, "add")));
    return c.json({ exam: row, questionIds: eqs.map((e) => e.questionId), studentIds: adds.map((a) => a.studentId) }, 200);
  })
  .post("/exams", requireAuth, requirePermission("exams"), async (c) => {
    const p = c.get("profile")!;
    const b = await c.req.json();
    const tid = p.tenantId!;
    const qids: string[] = b.questionIds ?? [];
    const qs = qids.length ? await db.select().from(schema.questions).where(inArray(schema.questions.id, qids)) : [];
    const total = qs.reduce((s, q) => s + q.points, 0);
    const assignMode = b.assignMode === "students" ? "students" : "cohort";
    const eid = id("ex");
    const [row] = await db
      .insert(schema.exams)
      .values({
        id: eid,
        tenantId: tid,
        title: b.title,
        classId: b.classId ?? null,
        sectionIds: assignMode === "students" ? null : (Array.isArray(b.sectionIds) && b.sectionIds.length ? b.sectionIds : null),
        assignMode,
        status: b.status ?? "scheduled",
        startAt: b.startAt ? new Date(b.startAt) : null,
        // The exam window closes at startAt + duration. After that the window is
        // closed and any student who never showed up is marked absent. (Offline
        // lost time is added back per-attempt beyond this cap at /start & /resume.)
        endAt: b.startAt ? new Date(new Date(b.startAt).getTime() + (b.durationMin ?? 60) * 60_000) : null,
        durationMin: b.durationMin ?? 60,
        totalPoints: total,
        createdBy: p.userId,
      })
      .returning();
    if (qids.length) {
      await db.insert(schema.examQuestions).values(
        qids.map((q, i) => ({ id: id("eq"), examId: eid, questionId: q, order: i, points: qs.find((x) => x.id === q)?.points ?? 1 })),
      );
    }
    // "students" mode: seed the roster add-list with the explicitly picked students.
    if (assignMode === "students" && Array.isArray(b.studentIds) && b.studentIds.length) {
      const ids = [...new Set(b.studentIds.map((s: unknown) => String(s)).filter(Boolean))] as string[];
      const valid = await db.select({ id: schema.students.id }).from(schema.students).where(and(eq(schema.students.tenantId, tid), inArray(schema.students.id, ids)));
      if (valid.length) {
        await db.insert(schema.examRoster).values(
          valid.map((s) => ({ id: id("rst"), examId: eid, studentId: s.id, mode: "add" as const, createdBy: p.userId ?? null })),
        );
      }
    }
    return c.json({ exam: row }, 201);
  })
  .patch("/exams/:id", requireAuth, requirePermission("exams"), async (c) => {
    const eid = c.req.param("id");
    const b = await c.req.json();
    const patch: Record<string, unknown> = {};
    for (const k of ["title", "status", "durationMin"]) if (b[k] !== undefined) patch[k] = b[k];
    if (b.assignMode !== undefined) patch.assignMode = b.assignMode === "students" ? "students" : "cohort";
    if (b.sectionIds !== undefined) patch.sectionIds = Array.isArray(b.sectionIds) && b.sectionIds.length ? b.sectionIds : null;
    if (b.startAt !== undefined || b.durationMin !== undefined) {
      // Keep the exam window (endAt = startAt + duration) in sync whenever EITHER
      // the start time OR the duration changes. Editing only the duration must
      // still move the window, otherwise the deadline stays stale and students
      // can be cut off early / late. Fall back to the exam's stored values for
      // whichever field the request did not include.
      let startAtVal: Date | null | undefined;
      let durMin = b.durationMin;
      if (b.startAt !== undefined) {
        patch.startAt = b.startAt ? new Date(b.startAt) : null;
        startAtVal = patch.startAt as Date | null;
      }
      if (startAtVal === undefined || durMin === undefined) {
        const [ex] = await db
          .select({ startAt: schema.exams.startAt, durationMin: schema.exams.durationMin })
          .from(schema.exams)
          .where(eq(schema.exams.id, eid))
          .limit(1);
        if (startAtVal === undefined) startAtVal = ex?.startAt ?? null;
        if (durMin === undefined) durMin = ex?.durationMin ?? 60;
      }
      patch.endAt = startAtVal ? new Date(new Date(startAtVal).getTime() + durMin * 60_000) : null;
    } else if (b.endAt !== undefined) {
      patch.endAt = b.endAt ? new Date(b.endAt) : null;
    }
    // Optionally replace the exam's question set and recompute total points.
    if (Array.isArray(b.questionIds)) {
      const qids: string[] = b.questionIds;
      const qs = qids.length ? await db.select().from(schema.questions).where(inArray(schema.questions.id, qids)) : [];
      patch.totalPoints = qs.reduce((s, q) => s + q.points, 0);
      await db.delete(schema.examQuestions).where(eq(schema.examQuestions.examId, eid));
      if (qids.length) {
        await db.insert(schema.examQuestions).values(
          qids.map((q, i) => ({ id: id("eq"), examId: eid, questionId: q, order: i, points: qs.find((x) => x.id === q)?.points ?? 1 })),
        );
      }
    }
    // In "students" mode, the picked list IS the roster add-list. Reconcile the
    // exam's "add" overrides to exactly match the provided studentIds. Removing a
    // student also clears any attempt/answers/events so they aren't counted.
    //
    // CRITICAL: this reconcile is DESTRUCTIVE (it purges add-rows + their attempts
    // for anyone not in `studentIds`). It must ONLY run when the exam is actually
    // in "students" assign mode. A cohort exam edited from the admin panel sends
    // `studentIds: []` (the picker is hidden), and running the reconcile there
    // would silently wipe every additive roster override AND their live answers.
    // In cohort mode, roster add/remove is managed solely via the dedicated
    // /roster endpoints — a PATCH must never touch it.
    let effAssignMode: "students" | "cohort";
    if (b.assignMode !== undefined) {
      effAssignMode = b.assignMode === "students" ? "students" : "cohort";
    } else {
      const [exMode] = await db
        .select({ assignMode: schema.exams.assignMode })
        .from(schema.exams)
        .where(eq(schema.exams.id, eid))
        .limit(1);
      effAssignMode = exMode?.assignMode === "students" ? "students" : "cohort";
    }
    if (effAssignMode === "students" && Array.isArray(b.studentIds)) {
      const p = c.get("profile")!;
      const want = new Set(b.studentIds.map((s: unknown) => String(s)).filter(Boolean) as string[]);
      const existing = await db.select().from(schema.examRoster).where(and(eq(schema.examRoster.examId, eid), eq(schema.examRoster.mode, "add")));
      const have = new Set(existing.map((r) => r.studentId));
      // Drop add-rows no longer wanted (and purge their attempts).
      for (const r of existing) {
        if (!want.has(r.studentId)) {
          const atts = await db.select().from(schema.attempts).where(and(eq(schema.attempts.examId, eid), eq(schema.attempts.studentId, r.studentId)));
          for (const a of atts) {
            await db.delete(schema.answers).where(eq(schema.answers.attemptId, a.id));
            await db.delete(schema.integrityEvents).where(eq(schema.integrityEvents.attemptId, a.id));
          }
          // Deleting events can free the top rowid, and the monitor's evidence cache reads
          // forward from a rowid watermark - a reused rowid would land below it. Force a
          // full rebuild; see lib/integrity-rollup.ts.
          integrityRollup.invalidateAll();
          // The attempts themselves are gone, so the owner cache must not keep
          // authorizing their former owners; see lib/attempt-owner.ts.
          attemptOwners.invalidateAll();
          // Evidence rows are going with them, so the stored-evidence counters must
          // be dropped too or a re-sit starts life already at its ceiling.
          evidenceMeter.invalidateAll();
          if (atts.length) await db.delete(schema.attempts).where(and(eq(schema.attempts.examId, eid), eq(schema.attempts.studentId, r.studentId)));
          await db.delete(schema.examRoster).where(eq(schema.examRoster.id, r.id));
        }
      }
      // Add new picks (validate they belong to the tenant).
      const toAdd = [...want].filter((sid) => !have.has(sid));
      if (toAdd.length) {
        const valid = await db.select({ id: schema.students.id }).from(schema.students).where(and(eq(schema.students.tenantId, p.tenantId!), inArray(schema.students.id, toAdd)));
        if (valid.length) {
          await db.insert(schema.examRoster).values(
            valid.map((s) => ({ id: id("rst"), examId: eid, studentId: s.id, mode: "add" as const, createdBy: p.userId ?? null })),
          );
        }
      }
    }
    const [row] = await db.update(schema.exams).set(patch).where(eq(schema.exams.id, eid)).returning();
    // Students read the exam row (and its question set) through short-lived caches;
    // drop them so an admin edit is visible on the next heartbeat, not one TTL later.
    invalidateExam(eid);
    invalidateExamQuestions(eid);
    return c.json({ exam: row }, 200);
  })

  // ---- Admin exam controls: global hold / resume / extra time (outage handling) ----
  // Hold the WHOLE exam (e.g. a venue-wide internet/power outage). Every running
  // student's timer freezes; the held duration is added back to the deadline on resume.
  .post("/exams/:id/hold", requireAuth, requirePermission("exams"), async (c) => {
    const eid = c.req.param("id");
    const [ex] = await db.select().from(schema.exams).where(eq(schema.exams.id, eid)).limit(1);
    if (!ex) return c.json({ message: "Not found" }, 404);
    if (!ex.heldAt) await db.update(schema.exams).set({ heldAt: new Date() }).where(eq(schema.exams.id, eid));
    invalidateExam(eid);
    return c.json({ ok: true, held: true }, 200);
  })
  // Resume a held exam: fold the elapsed hold into holdMs and clear heldAt so
  // deadlines shift forward by exactly the outage duration.
  .post("/exams/:id/unhold", requireAuth, requirePermission("exams"), async (c) => {
    const eid = c.req.param("id");
    const [ex] = await db.select().from(schema.exams).where(eq(schema.exams.id, eid)).limit(1);
    if (!ex) return c.json({ message: "Not found" }, 404);
    if (ex.heldAt) {
      const elapsed = Math.max(0, Date.now() - new Date(ex.heldAt).getTime());
      await db.update(schema.exams).set({ heldAt: null, holdMs: (ex.holdMs ?? 0) + elapsed }).where(eq(schema.exams.id, eid));
    }
    invalidateExam(eid);
    return c.json({ ok: true, held: false }, 200);
  })
  // Grant extra minutes to the whole exam (shifts every deadline forward).
  .post("/exams/:id/extra-time", requireAuth, requirePermission("exams"), async (c) => {
    const eid = c.req.param("id");
    const b = await c.req.json().catch(() => ({}));
    let minutes = Number(b.minutes);
    if (!Number.isFinite(minutes)) minutes = 0;
    minutes = Math.round(minutes);
    const [ex] = await db.select().from(schema.exams).where(eq(schema.exams.id, eid)).limit(1);
    if (!ex) return c.json({ message: "Not found" }, 404);
    const next = Math.max(0, (ex.extraMin ?? 0) + minutes);
    const [row] = await db.update(schema.exams).set({ extraMin: next }).where(eq(schema.exams.id, eid)).returning();
    invalidateExam(eid);
    return c.json({ ok: true, extraMin: row.extraMin }, 200);
  })

  // =================== SCHEDULE-ASSESSMENT ROSTER (add / remove students) ===================
  // Manage the per-assessment student roster from the Schedule Assessment screen.
  // Same override model as the reports roster, but gated by the "exams" permission
  // so it lives with assessment scheduling. Works regardless of exam status.

  // Current roster overrides for an exam: explicitly added + explicitly removed.
  .get("/exams/:examId/roster", requireAuth, requirePermission("exams"), async (c) => {
    const p = c.get("profile")!;
    const eid = c.req.param("examId");
    const [ex] = await db.select().from(schema.exams).where(eq(schema.exams.id, eid)).limit(1);
    if (!ex || ex.tenantId !== p.tenantId) return c.json({ message: "Not found" }, 404);
    const overrides = await db.select().from(schema.examRoster).where(eq(schema.examRoster.examId, eid));
    // Names and section codes come from the directory cache — this handler only
    // needs them to label rows, so two full-table reads per open were pure waste.
    const clmap = (await directory.classIndex(p.tenantId!)).byId;
    const smap = (await directory.studentIndex(p.tenantId!)).byId;
    const shape = (o: typeof overrides[number]) => {
      const s = smap.get(o.studentId);
      return { id: o.studentId, name: s?.name ?? "—", rollNo: s?.rollNo ?? "", email: s?.email ?? null, section: s?.classId ? clmap.get(s.classId)?.code ?? "" : "" };
    };
    const added = overrides.filter((o) => o.mode === "add").map(shape);
    const removed = overrides.filter((o) => o.mode === "remove").map(shape);
    return c.json({ added, removed }, 200);
  })

  // Students NOT currently eligible for the exam — the "Add student" picker.
  .get("/exams/:examId/roster/candidates", requireAuth, requirePermission("exams"), async (c) => {
    const p = c.get("profile")!;
    const eid = c.req.param("examId");
    const q = (c.req.query("q") ?? "").trim().toLowerCase();
    const [ex] = await db.select().from(schema.exams).where(eq(schema.exams.id, eid)).limit(1);
    if (!ex || ex.tenantId !== p.tenantId) return c.json({ message: "Not found" }, 404);
    const roster = await loadRoster(eid);
    const allStudents = (await directory.studentIndex(p.tenantId!)).enabled;
    const clmap = (await directory.classIndex(p.tenantId!)).byId;
    const candidates = allStudents
      .filter((stu) => !isEligible(ex, stu, roster))
      .filter((stu) => !q || (stu.name ?? "").toLowerCase().includes(q) || (stu.rollNo ?? "").toLowerCase().includes(q) || (stu.email ?? "").toLowerCase().includes(q))
      .slice(0, 30)
      .map((stu) => ({ id: stu.id, name: stu.name ?? "—", rollNo: stu.rollNo ?? "", email: stu.email ?? null, section: stu.classId ? clmap.get(stu.classId)?.code ?? "" : "" }));
    return c.json({ candidates }, 200);
  })

  // Students CURRENTLY eligible for the exam — the "Remove student" picker.
  .get("/exams/:examId/roster/eligible", requireAuth, requirePermission("exams"), async (c) => {
    const p = c.get("profile")!;
    const eid = c.req.param("examId");
    const q = (c.req.query("q") ?? "").trim().toLowerCase();
    const [ex] = await db.select().from(schema.exams).where(eq(schema.exams.id, eid)).limit(1);
    if (!ex || ex.tenantId !== p.tenantId) return c.json({ message: "Not found" }, 404);
    const roster = await loadRoster(eid);
    const allStudents = (await directory.studentIndex(p.tenantId!)).enabled;
    const clmap = (await directory.classIndex(p.tenantId!)).byId;
    const eligible = allStudents
      .filter((stu) => isEligible(ex, stu, roster))
      .filter((stu) => !q || (stu.name ?? "").toLowerCase().includes(q) || (stu.rollNo ?? "").toLowerCase().includes(q) || (stu.email ?? "").toLowerCase().includes(q))
      .slice(0, 30)
      .map((stu) => ({ id: stu.id, name: stu.name ?? "—", rollNo: stu.rollNo ?? "", email: stu.email ?? null, section: stu.classId ? clmap.get(stu.classId)?.code ?? "" : "" }));
    return c.json({ eligible }, 200);
  })

  // Add a student to the assessment (idempotent). Clears any prior override.
  .post("/exams/:examId/roster/add", requireAuth, requirePermission("exams"), async (c) => {
    const p = c.get("profile")!;
    const eid = c.req.param("examId");
    const b = await c.req.json().catch(() => ({}));
    const studentId = String(b.studentId ?? "");
    if (!studentId) return c.json({ message: "studentId required" }, 400);
    const [ex] = await db.select().from(schema.exams).where(eq(schema.exams.id, eid)).limit(1);
    if (!ex || ex.tenantId !== p.tenantId) return c.json({ message: "Not found" }, 404);
    const [stu] = await db.select().from(schema.students).where(eq(schema.students.id, studentId)).limit(1);
    if (!stu || stu.tenantId !== p.tenantId) return c.json({ message: "Student not found" }, 404);
    await db.delete(schema.examRoster).where(and(eq(schema.examRoster.examId, eid), eq(schema.examRoster.studentId, studentId)));
    await ensureOptInOnlyLoaded();
    if (!matchesCohort(ex, stu)) {
      await db.insert(schema.examRoster).values({ id: id("rst"), examId: eid, studentId, mode: "add", createdBy: p.userId ?? null });
    }
    return c.json({ ok: true }, 200);
  })

  // Remove a student from the assessment: records a "remove" override and deletes
  // any attempt/answers/events for this exam so they are not counted at all.
  .post("/exams/:examId/roster/remove", requireAuth, requirePermission("exams"), async (c) => {
    const p = c.get("profile")!;
    const eid = c.req.param("examId");
    const b = await c.req.json().catch(() => ({}));
    const studentId = String(b.studentId ?? "");
    if (!studentId) return c.json({ message: "studentId required" }, 400);
    const [ex] = await db.select().from(schema.exams).where(eq(schema.exams.id, eid)).limit(1);
    if (!ex || ex.tenantId !== p.tenantId) return c.json({ message: "Not found" }, 404);
    const atts = await db.select().from(schema.attempts).where(and(eq(schema.attempts.examId, eid), eq(schema.attempts.studentId, studentId)));
    for (const a of atts) {
      await db.delete(schema.answers).where(eq(schema.answers.attemptId, a.id));
      await db.delete(schema.integrityEvents).where(eq(schema.integrityEvents.attemptId, a.id));
    }
    // Deleting events can free the top rowid, and the monitor's evidence cache reads
    // forward from a rowid watermark - a reused rowid would land below it. Force a
    // full rebuild; see lib/integrity-rollup.ts.
    integrityRollup.invalidateAll();
    // The attempts themselves are gone, so the owner cache must not keep
    // authorizing their former owners; see lib/attempt-owner.ts.
    attemptOwners.invalidateAll();
    // Evidence rows are going with them, so the stored-evidence counters must
    // be dropped too or a re-sit starts life already at its ceiling.
    evidenceMeter.invalidateAll();
    if (atts.length) await db.delete(schema.attempts).where(and(eq(schema.attempts.examId, eid), eq(schema.attempts.studentId, studentId)));
    await db.delete(schema.examRoster).where(and(eq(schema.examRoster.examId, eid), eq(schema.examRoster.studentId, studentId)));
    // Only need a "remove" override if the student would otherwise be a cohort match.
    const [stu] = await db.select().from(schema.students).where(eq(schema.students.id, studentId)).limit(1);
    await ensureOptInOnlyLoaded();
    if (stu && matchesCohort(ex, stu)) {
      await db.insert(schema.examRoster).values({ id: id("rst"), examId: eid, studentId, mode: "remove", createdBy: p.userId ?? null });
    }
    return c.json({ ok: true }, 200);
  })

  // Undo an override — restore a student to their default cohort eligibility.
  .post("/exams/:examId/roster/reset", requireAuth, requirePermission("exams"), async (c) => {
    const p = c.get("profile")!;
    const eid = c.req.param("examId");
    const b = await c.req.json().catch(() => ({}));
    const studentId = String(b.studentId ?? "");
    if (!studentId) return c.json({ message: "studentId required" }, 400);
    const [ex] = await db.select().from(schema.exams).where(eq(schema.exams.id, eid)).limit(1);
    if (!ex || ex.tenantId !== p.tenantId) return c.json({ message: "Not found" }, 404);
    await db.delete(schema.examRoster).where(and(eq(schema.examRoster.examId, eid), eq(schema.examRoster.studentId, studentId)));
    return c.json({ ok: true }, 200);
  })

  // Reopen a single accidentally-submitted attempt. Flips submitted/graded back
  // to in_progress WITHOUT wiping the student's work — their answers stay in the
  // DB and their timer resumes from the original startedAt (via effectiveEndMs).
  // Optional addMinutes grants extra time to THIS student only by bumping the
  // per-attempt pausedMs (does not affect anyone else in the exam).
  .post("/exams/:id/attempts/:attemptId/reopen", requireAuth, requirePermission("liveMonitor"), async (c) => {
    const p = c.get("profile")!;
    const eid = c.req.param("id");
    const aid = c.req.param("attemptId");
    const b = await c.req.json().catch(() => ({}));
    let addMinutes = Number(b.addMinutes);
    if (!Number.isFinite(addMinutes) || addMinutes < 0) addMinutes = 0;
    addMinutes = Math.round(addMinutes);

    const [exam] = await db.select().from(schema.exams).where(eq(schema.exams.id, eid)).limit(1);
    if (!exam || exam.tenantId !== p.tenantId) return c.json({ message: "Not found" }, 404);
    const [attempt] = await db.select().from(schema.attempts).where(eq(schema.attempts.id, aid)).limit(1);
    if (!attempt || attempt.examId !== eid) return c.json({ message: "Attempt not found" }, 404);
    if (attempt.status !== "submitted" && attempt.status !== "graded") {
      return c.json({ message: "Only a submitted or graded attempt can be reopened." }, 400);
    }

    const now = Date.now();
    const addMs = addMinutes * 60_000;

    // Shared exam-window end that everyone still writing is bound to:
    // endAt + admin extra time + accumulated hold + any currently-running hold.
    // This is independent of THIS attempt's (possibly skewed) startedAt, so a
    // reset student picks up exactly the time still left on the room's clock.
    let sharedEnd = 0;
    if (exam.endAt) {
      sharedEnd =
        new Date(exam.endAt).getTime() + (exam.extraMin ?? 0) * 60_000 + (exam.holdMs ?? 0);
      if (exam.heldAt) sharedEnd += Math.max(0, now - new Date(exam.heldAt).getTime());
    }

    // Deadline if we simply resumed this attempt's own timer.
    const naturalEnd = effectiveEndMs(exam, { startedAt: attempt.startedAt, pausedMs: attempt.pausedMs ?? 0 }, now);

    // Target deadline = the later of the shared window end and this attempt's
    // natural end, plus any admin-granted minutes for THIS student only. Using
    // the shared end means a student who submitted early (or whose start time is
    // skewed) resumes with the SAME leftover time as the rest of the room — e.g.
    // 30 min left on the window + 20 min admin extra = 50 min — never a fresh
    // full duration.
    let target = Math.max(sharedEnd, naturalEnd) + addMs;

    // Always guarantee a real writable cushion after a reopen. A tiny floor (e.g.
    // 1 min) caused a submit/reopen loop: the client's auto-submit-on-timeout
    // fires again within a heartbeat, the admin reopens, and round it goes. Give
    // at least MIN_WRITABLE_MS of usable time from now — the admin's added
    // minutes if larger, else this floor (or a fresh duration if the whole
    // window has already closed and no minutes were specified).
    const MIN_WRITABLE_MS = 10 * 60_000; // 10 min floor of usable time
    if (target - now < MIN_WRITABLE_MS) {
      const grantMin =
        addMinutes > 0 ? Math.max(addMinutes, 10) : (target - now <= 0 ? exam.durationMin : 10);
      target = now + grantMin * 60_000;
    }

    // Realise `target` via pausedMs (added AFTER the exam-window cap inside
    // effectiveEndMs), keeping startedAt untouched. pausedMs affects only this
    // attempt.
    const floorEnd = effectiveEndMs(exam, { startedAt: attempt.startedAt, pausedMs: 0 }, now);
    const newPaused = Math.max(0, target - floorEnd);

    await db
      .update(schema.attempts)
      .set({
        status: "in_progress",
        score: null,
        submittedAt: null,
        pausedMs: newPaused,
        lastPausedAt: null,
        lastSeenAt: new Date(),
      })
      .where(eq(schema.attempts.id, aid));

    const endAtMs = effectiveEndMs(exam, { startedAt: attempt.startedAt, pausedMs: newPaused }, now);
    return c.json({ ok: true, endAt: new Date(endAtMs), grantedUntil: new Date(endAtMs), addedMinutes: addMinutes }, 200);
  })

  // =================== LIVE MONITOR ===================
  .get("/monitor", requireAuth, requirePermission("liveMonitor"), async (c) => {
    const p = c.get("profile")!;
    const tid = p.tenantId;
    if (!tid) return c.json({ live: [], nextScheduled: null, health: null }, 200);

    // Every open Live Monitor tab polls this endpoint every 5s, and during an exam
    // several invigilators watch at once. The payload is identical for everyone in
    // the tenant, so build it ONCE and share it: concurrent callers join the
    // in-flight promise, and callers within the cache window get the last result.
    // This is what stops N invigilators turning into N x the database load — the
    // single biggest reason the monitor seized up during a live exam.
    const snapshot = await getMonitorSnapshot(tid);
    // Ship the watchdog verdict with the payload so a slow monitor is visible to
    // the invigilator looking at the screen, not only in the server logs. This is
    // outside the cached snapshot because the timing changes per build.
    const t = monitorTiming();
    return c.json(
      {
        ...snapshot,
        health: {
          degraded: t.degraded,
          lastBuildMs: t.lastBuildMs,
          worstBuildMs: t.worstBuildMs,
          budgetMs: MONITOR_BUDGET_MS,
          pollMs: MONITOR_POLL_MS,
        },
      },
      200,
    );
  })


  // =================== DASHBOARD ===================
  .get("/dashboard", requireAuth, requirePermission("dashboard"), async (c) => {
    const p = c.get("profile")!;
    const tid = p.tenantId;
    if (!tid) return c.json({ stats: null, classAvg: [], trend: [], topStudents: [], classToppers: [] }, 200);

    // An exam counts toward results once it is either explicitly finished OR its
    // window has closed (deadline passed). Drafts never count. This mirrors the
    // effective-status logic used by the reports endpoint so the dashboard stays
    // consistent with what admins see under Reports.
    const nowMs = Date.now();
    // Optional period filter: from / to are YYYY-MM-DD (inclusive). Scopes every
    // finished-exam-derived stat to assessments conducted within the window.
    const fromQ = (c.req.query("from") ?? "").trim();
    const toQ = (c.req.query("to") ?? "").trim();
    const fromMs = fromQ ? new Date(`${fromQ}T00:00:00`).getTime() : null;
    const toMs = toQ ? new Date(`${toQ}T23:59:59.999`).getTime() : null;
    const conductedMs = (e: { endAt: any; startAt: any; createdAt: any }) => {
      const raw = e.endAt ?? e.startAt ?? e.createdAt;
      const t = raw ? new Date(raw).getTime() : NaN;
      return Number.isNaN(t) ? null : t;
    };
    const inPeriod = (e: { endAt: any; startAt: any; createdAt: any }) => {
      if (fromMs === null && toMs === null) return true;
      const t = conductedMs(e);
      if (t === null) return false;
      if (fromMs !== null && t < fromMs) return false;
      if (toMs !== null && t > toMs) return false;
      return true;
    };
    const allExams = await db.select().from(schema.exams).where(and(eq(schema.exams.tenantId, tid), ne(schema.exams.status, "draft"))).orderBy(schema.exams.createdAt);
    const finishedExams = allExams.filter((e) => {
      const isFinished = e.status === "finished" || (() => {
        const end = e.endAt ? new Date(e.endAt).getTime() : null;
        return end != null && !Number.isNaN(end) && nowMs > end;
      })();
      return isFinished && inPeriod(e);
    });
    const examIds = finishedExams.map((e) => e.id);
    const atts = examIds.length ? await db.select().from(schema.attempts).where(inArray(schema.attempts.examId, examIds)) : [];
    const graded = atts.filter((a) => a.score != null);

    const avg = graded.length ? graded.reduce((s, a) => s + (a.score ?? 0), 0) / graded.length : 0;
    const passRate = graded.length ? (graded.filter((a) => (a.score ?? 0) >= 40).length / graded.length) * 100 : 0;

    // class-wise average. Students and classes come from the directory cache: the
    // dashboard only needs them to label and group scores, and re-reading 1,124
    // rows on every load was most of this endpoint's latency.
    const classIdx = await directory.classIndex(tid);
    const studentIdx = await directory.studentIndex(tid);
    const classes = classIdx.all;
    const students = studentIdx.all;
    const stuClass = new Map(students.map((s) => [s.id, s.classId]));
    const classScores = new Map<string, number[]>();
    for (const a of graded) {
      const cid = stuClass.get(a.studentId);
      if (!cid) continue;
      if (!classScores.has(cid)) classScores.set(cid, []);
      classScores.get(cid)!.push(a.score ?? 0);
    }
    const classAvg = classes
      .map((cl) => {
        const arr = classScores.get(cl.id) ?? [];
        if (!arr.length) return null;
        return { code: cl.code, avg: Math.round((arr.reduce((s, v) => s + v, 0) / arr.length) * 10) / 10 };
      })
      .filter((x): x is { code: string; avg: number } => x != null);

    // trend across finished exams (avg per exam)
    const trend = finishedExams.slice(-6).map((e) => {
      const ea = graded.filter((a) => a.examId === e.id);
      return { name: e.title.length > 8 ? e.title.slice(0, 8) : e.title, avg: ea.length ? Math.round((ea.reduce((s, a) => s + (a.score ?? 0), 0) / ea.length) * 10) / 10 : 0 };
    });

    // top students overall (avg score per student)
    const stuScores = new Map<string, number[]>();
    for (const a of graded) {
      if (!stuScores.has(a.studentId)) stuScores.set(a.studentId, []);
      stuScores.get(a.studentId)!.push(a.score ?? 0);
    }
    const smap = new Map(students.map((s) => [s.id, s]));
    const clmap = new Map(classes.map((cl) => [cl.id, cl]));
    const topStudents = [...stuScores.entries()]
      .map(([sid, arr]) => {
        const s = smap.get(sid);
        const cl = s?.classId ? clmap.get(s.classId) : null;
        return { name: s?.name ?? "—", rollNo: s?.rollNo ?? "", classCode: cl?.code ?? "—", avg: Math.round((arr.reduce((a, b) => a + b, 0) / arr.length) * 10) / 10 };
      })
      .sort((a, b) => b.avg - a.avg)
      .slice(0, 8);

    // class toppers (only classes that actually have a graded student)
    const classToppers = classes
      .map((cl) => {
        const best = [...stuScores.entries()]
          .map(([sid, arr]) => ({ s: smap.get(sid), avg: arr.reduce((a, b) => a + b, 0) / arr.length }))
          .filter((x) => x.s?.classId === cl.id)
          .sort((a, b) => b.avg - a.avg)[0];
        if (!best?.s) return null;
        return { code: cl.code, name: best.s.name, score: Math.round(best.avg * 10) / 10 };
      })
      .filter((t): t is { code: string; name: string; score: number } => t != null);

    // settings for limit alert (platform-global)
    const s = await getGlobalSettings();
    const judge0Pct = s ? Math.round((s.judge0Used / Math.max(1, s.judge0Limit)) * 100) : 0;
    const aiPct = s ? Math.round((s.aiUsed / Math.max(1, s.aiLimit)) * 100) : 0;

    return c.json(
      {
        stats: {
          totalStudents: students.length,
          avg: Math.round(avg * 10) / 10,
          passRate: Math.round(passRate),
          completed: finishedExams.length,
        },
        classAvg,
        trend,
        topStudents,
        classToppers,
        limits: { judge0Pct, aiPct, judge0Used: s?.judge0Used ?? 0, judge0Limit: s?.judge0Limit ?? 0, aiUsed: s?.aiUsed ?? 0, aiLimit: s?.aiLimit ?? 0 },
      },
      200,
    );
  })

  // =================== REPORTS (finished only for TPO) ===================
  .get("/reports", requireAuth, requirePermission("reports"), async (c) => {
    const p = c.get("profile")!;
    const tid = p.tenantId;
    if (!tid) return c.json({ exams: [] }, 200);
    // Reports only cover CONDUCTED assessments — never drafts/scheduled-in-future.
    // TPO sees finished only; others see finished + live (in-progress). A scheduled
    // exam whose start time has passed is effectively live, so include it for
    // non-TPO roles too (mirrors the Live Monitor / Schedule list behaviour).
    const now = Date.now();
    const endMs = (e: { endAt: Date | number | string | null }) => toMs(e.endAt);
    // A scheduled exam whose start time has passed is effectively LIVE — until its
    // window (endAt + admin extra time + hold time) closes, after which it has ENDED.
    // Derivation lives in lib/exam-status so every caller agrees; see effStatus below.
    const effStatus = (e: StatusExam) => examEffStatus(e, now);
    const allExams = await db.select().from(schema.exams).where(eq(schema.exams.tenantId, tid)).orderBy(desc(schema.exams.createdAt));
    // Filter on DERIVED status, never the raw column. The raw column is admin intent
    // and never self-updates, so an exam conducted last month still reads "scheduled":
    // matching `status === "finished"` here hid every conducted exam from TPOs.
    const rows = allExams.filter((e) => (p.role === "tpo" ? isConcluded(e, now) : isReportable(e, now)));
    // All students in the tenant — used to size the "assigned" cohort per exam.
    // Directory cache: the list only counts eligibility, it never returns students.
    const allStudents = (await directory.studentIndex(tid)).enabled;
    const reportRosters = await loadRosters(rows.map((e) => e.id));
    const assignedFor = (e: { id: string; classId: string | null; sectionIds: string[] | null }) =>
      allStudents.filter((stu) => isEligible(e, stu, reportRosters.get(e.id))).length;
    // Per-exam counts in ONE grouped aggregate, not one query per exam.
    //
    // This used to be `rows.map(async (e) => select().from(attempts).where(examId))`
    // inside a Promise.all: a remote round trip per exam, each shipping every column
    // of every attempt row, to end up with seven integers per card. At 11 exams and
    // 2,520 stored attempts that meant transferring every attempt ever taken on every
    // open of the reports page — and because it scales with exam HISTORY rather than
    // with load, it got worse every week on its own. SQLite counts better than we do;
    // see lib/report-rollup.ts for the definitions (which are subtle: passed/failed
    // key off `score IS NOT NULL`, not status).
    const rollups = await loadAttemptRollups(db, rows.map((e) => e.id));
    const withStats = rows.map((e) => {
      const r = rollups.get(e.id) ?? EMPTY_ROLLUP;
      const assigned = assignedFor(e);
      // absent = assigned students who never finished nor are in progress, but ONLY
      // once the exam deadline has passed (before that they may still show up).
      const deadline = endMs(e);
      const deadlineOver = e.status === "finished" || (deadline !== null && now >= deadline);
      const absent = deadlineOver ? Math.max(0, assigned - r.finished - r.inProgress) : 0;
      // "wrote" retained for backward compat (== finished).
      return { ...e, status: effStatus(e), attempts: r.attempts, assigned, finished: r.finished, inProgress: r.inProgress, absent, wrote: r.finished, graded: r.graded, passed: r.passed, failed: r.failed, avg: rollupAvg(r) };
    });
    // Newest assessment date first (startAt if set, else createdAt).
    const dateVal = (e: (typeof withStats)[number]) => {
      const d = e.startAt ?? e.createdAt;
      return d ? new Date(d as any).getTime() : 0;
    };
    withStats.sort((a, b) => dateVal(b) - dateVal(a));
    return c.json({ exams: withStats }, 200);
  })
  .get("/reports/:examId", requireAuth, requirePermission("reports"), async (c) => {
    const p = c.get("profile")!;
    const eid = c.req.param("examId");
    const [ex] = await db.select().from(schema.exams).where(eq(schema.exams.id, eid));
    if (!ex || ex.tenantId !== p.tenantId) return c.json({ message: "Not found" }, 404);
    // Same rule as the /reports list: gate on DERIVED status, not the raw column, or a
    // TPO who can see a conducted exam in the list gets a 403 when opening it.
    if (p.role === "tpo" && !isConcluded(ex)) return c.json({ message: "Report not available until finished" }, 403);
    const atts = await db.select().from(schema.attempts).where(eq(schema.attempts.examId, eid));
    // Total questions on the exam so the report can show "answered N/total".
    const totalQuestions = (await db.select().from(schema.examQuestions).where(eq(schema.examQuestions.examId, eid))).length;
    // Directory cache. This report used to read all 1,124 students and every class
    // on EVERY open, purely to label attempt rows with a name and a section code.
    const studentIdx = await directory.studentIndex(p.tenantId!);
    const smap = studentIdx.byId;
    const clmap = (await directory.classIndex(p.tenantId!)).byId;
    // Prefer the section frozen on the attempt (historical truth). Fall back to the
    // student's current section for older rows that predate the snapshot.
    const sectionOf = (sid: string) => {
      const cid = smap.get(sid)?.classId;
      return cid ? clmap.get(cid)?.code ?? "" : "";
    };
    const sectionOfAttempt = (a: { studentId: string; sectionSnapshot?: string | null }) =>
      a.sectionSnapshot && a.sectionSnapshot.trim() ? a.sectionSnapshot : sectionOf(a.studentId);
    // How many webcam frames does each attempt actually have?
    //
    // WHY IT IS ON THE ROSTER. A student sat four exams whose camera never produced a
    // single frame. Nothing failed loudly: he started, submitted, scored 95, and the
    // only trace was an empty gallery on a review page nobody had a reason to open.
    // Surfacing the count here means "no proctoring evidence" is visible without
    // opening anyone, which is the difference between finding this in two months and
    // finding it the same day.
    //
    // ONE STATEMENT, NOT N+1. A naive count per row is ~200 round trips on a full
    // cohort. This is a single grouped aggregate over `integrity_events` restricted to
    // the frame types, chunked only to stay under SQLite's bound-variable cap, and it
    // rides `integrity_attempt_type_idx` (attempt_id, type).
    const frameCounts = new Map<string, number>();
    const failCounts = new Map<string, number>();
    const attIds = atts.map((a) => a.id);
    for (let i = 0; i < attIds.length; i += 200) {
      const slice = attIds.slice(i, i + 200);
      const agg = await db
        .select({ attemptId: schema.integrityEvents.attemptId, type: schema.integrityEvents.type, n: dsql<number>`count(*)` })
        .from(schema.integrityEvents)
        .where(and(
          inArray(schema.integrityEvents.attemptId, slice),
          inArray(schema.integrityEvents.type, [...FRAME_EVENT_TYPES, "snapshot_failed"]),
        ))
        .groupBy(schema.integrityEvents.attemptId, schema.integrityEvents.type);
      for (const row of agg) {
        const target = row.type === "snapshot_failed" ? failCounts : frameCounts;
        target.set(row.attemptId, (target.get(row.attemptId) ?? 0) + Number(row.n ?? 0));
      }
    }
    const attemptRows = atts
      .map((a) => ({ attemptId: a.id, studentId: a.studentId, name: smap.get(a.studentId)?.name ?? "—", rollNo: smap.get(a.studentId)?.rollNo ?? "", email: smap.get(a.studentId)?.email ?? null, section: sectionOfAttempt(a), score: a.score, status: a.status, submittedAt: a.submittedAt, absent: false, disconnected: !!a.disconnected, answeredCount: a.answeredCount ?? 0, frames: frameCounts.get(a.id) ?? 0, snapshotFailures: failCounts.get(a.id) ?? 0 }))
      .sort((x, y) => (y.score ?? -1) - (x.score ?? -1));
    // Assigned-but-absent students: enrolled in the exam's cohort yet no attempt row.
    // Only surface them once the exam window has closed (before that they may still
    // show up). Rendered as "A" (absent) rather than a misleading 0.
    const attemptedIds = new Set(atts.map((a) => a.studentId));
    const endAtMs = ex.endAt == null ? null : typeof ex.endAt === "number" ? ex.endAt : new Date(ex.endAt as any).getTime();
    const deadlineOver = ex.status === "finished" || (endAtMs !== null && !Number.isNaN(endAtMs) && Date.now() >= endAtMs);
    const exRoster = await loadRoster(eid);
    const absentRows = !deadlineOver
      ? []
      // `.all` (not `.enabled`) because the filter below drops disabled students
      // itself — keeping that explicit check preserves the previous behaviour.
      : studentIdx.all
          .filter((stu) => {
            if (stu.enabled === false) return false;
            if (attemptedIds.has(stu.id)) return false;
            return isEligible(ex, stu, exRoster);
          })
          .map((stu) => ({ attemptId: `absent-${stu.id}`, studentId: stu.id, name: stu.name ?? "—", rollNo: stu.rollNo ?? "", email: stu.email ?? null, section: sectionOf(stu.id), score: null, status: "absent", submittedAt: null, absent: true, disconnected: false, answeredCount: 0, frames: 0, snapshotFailures: 0 }))
          .sort((x, y) => x.rollNo.localeCompare(y.rollNo));
    // Attempts (scored, sorted high→low) first, absentees last.
    const rows = [...attemptRows, ...absentRows];
    // Whether snapshots are expected AT ALL right now. Proctoring is one global config
    // blob, so this is the only honest gate available: with webcam snapshots switched
    // off every attempt legitimately has zero frames, and the roster must not then
    // light up every student as a camera failure.
    const gsReport = await getGlobalSettings();
    const snapshotsExpected = { ...schema.DEFAULT_PROCTORING, ...(gsReport.proctoring ?? {}) }.webcamSnapshots !== false;
    return c.json({ exam: ex, results: rows, totalQuestions, snapshotsExpected }, 200);
  })
  .get("/reports/:examId/attempt/:attemptId", requireAuth, requirePermission("reports"), async (c) => {
    const p = c.get("profile")!;
    const eid = c.req.param("examId");
    const aid = c.req.param("attemptId");
    const [ex] = await db.select().from(schema.exams).where(eq(schema.exams.id, eid));
    if (!ex || ex.tenantId !== p.tenantId) return c.json({ message: "Not found" }, 404);
    const [att] = await db.select().from(schema.attempts).where(eq(schema.attempts.id, aid));
    if (!att || att.examId !== eid) return c.json({ message: "Not found" }, 404);
    const [stu] = await db.select().from(schema.students).where(eq(schema.students.id, att.studentId));
    const ans = await db.select().from(schema.answers).where(eq(schema.answers.attemptId, aid));
    const aMap = new Map(ans.map((a) => [a.questionId, a]));
    // Order questions by the exam's question order so the answer sheet reads top-to-bottom.
    const eqs = await db.select().from(schema.examQuestions).where(eq(schema.examQuestions.examId, eid)).orderBy(schema.examQuestions.order);
    const orderedQids = eqs.length ? eqs.map((e) => e.questionId) : ans.map((a) => a.questionId);
    const qs = orderedQids.length ? await db.select().from(schema.questions).where(inArray(schema.questions.id, orderedQids)) : [];
    const qmap = new Map(qs.map((q) => [q.id, q]));
    const answers = orderedQids.map((qid, i) => {
      const q = qmap.get(qid);
      const a = aMap.get(qid);
      const eqRow = eqs.find((e) => e.questionId === qid);
      return {
        id: a?.id ?? `q-${i}`,
        prompt: q?.prompt ?? "—",
        type: q?.type ?? "—",
        topic: q?.topic ?? null,
        options: q?.options ?? null,
        correct: q?.correct ?? null,
        explanation: (q?.meta as any)?.explanation ?? null,
        response: a?.response ?? null,
        score: a?.score ?? null,
        maxScore: a?.maxScore ?? eqRow?.points ?? q?.points ?? null,
        aiNotes: a?.aiNotes ?? null,
        autoGraded: a?.autoGraded ?? null,
      };
    });
    // Proctoring evidence: every recorded violation for this attempt, newest
    // first, with a short-lived signed URL for the webcam snapshot captured at
    // that moment (null when no snapshot was captured / storage was unavailable).
    const evRows = await db.select().from(schema.integrityEvents)
      .where(eq(schema.integrityEvents.attemptId, aid))
      .orderBy(desc(schema.integrityEvents.at));
    // Two separate streams for the reviewer: `integrity` is misconduct (what needs a
    // decision), `snapshots` is the routine timed camera trail (what proves the
    // student sat there alone). Mixing them buries the real flags in noise.
    const sign = async (ev: typeof evRows[number]) => {
      let photo: string | null = null;
      // Cached: the drawer re-polls every 10s while an attempt is live, and this
      // signs up to 900 URLs per open. The URL is valid 24h; the cache hands out
      // ones with at least 12h left.
      if (ev.photoUrl) { try { photo = await presignGetCached(ev.photoUrl); } catch { photo = null; } }
      // Same-origin proxy path for the same object. The presigned URL above is
      // fine for <img>, but a cross-origin fetch() to Tigris is blocked unless
      // the bucket carries a CORS policy — so bulk download (ZIP) reads through
      // our own /api/files/* route instead, which also never expires.
      const proxy = ev.photoUrl ? `/api/files/${ev.photoUrl}` : null;
      return { id: ev.id, type: ev.type, detail: ev.detail, at: ev.at, photo, proxy };
    };
    const integrity = await Promise.all(
      evRows.filter((ev) => !isFrameEvent(ev.type)).slice(0, 300).map(sign),
    );
    // Capped — at the ~27s cadence a 3h attempt is ~400 frames, so the cap has to
    // clear that or the tail of a long attempt silently disappears from review.
    const snapshots = (await Promise.all(
      evRows.filter((ev) => isFrameEvent(ev.type) && ev.photoUrl).slice(0, 600).map(sign),
    )).filter((s) => s.photo);
    return c.json({
      exam: { id: ex.id, title: ex.title },
      student: { name: stu?.name ?? "—", rollNo: stu?.rollNo ?? "", email: stu?.email ?? null },
      attempt: { score: att.score, status: att.status, submittedAt: att.submittedAt, startedAt: att.startedAt },
      answers,
      integrity,
      snapshots,
    }, 200);
  })

  // =================== ROSTER (per-exam add / remove / mark-absent) ===================
  // Search enabled students in the tenant who are NOT already eligible for the
  // exam — used by the "Add student to assessment" picker.
  .get("/reports/:examId/roster/candidates", requireAuth, requirePermission("reports"), async (c) => {
    const p = c.get("profile")!;
    const eid = c.req.param("examId");
    const q = (c.req.query("q") ?? "").trim().toLowerCase();
    const [ex] = await db.select().from(schema.exams).where(eq(schema.exams.id, eid));
    if (!ex || ex.tenantId !== p.tenantId) return c.json({ message: "Not found" }, 404);
    const roster = await loadRoster(eid);
    const allStudents = (await directory.studentIndex(p.tenantId!)).enabled;
    const clmap = (await directory.classIndex(p.tenantId!)).byId;
    const candidates = allStudents
      // Not already eligible (so the picker only offers students you can add).
      .filter((stu) => !isEligible(ex, stu, roster))
      .filter((stu) => {
        if (!q) return true;
        return (stu.name ?? "").toLowerCase().includes(q) || (stu.rollNo ?? "").toLowerCase().includes(q) || (stu.email ?? "").toLowerCase().includes(q);
      })
      .slice(0, 30)
      .map((stu) => ({ id: stu.id, name: stu.name ?? "—", rollNo: stu.rollNo ?? "", email: stu.email ?? null, section: stu.classId ? clmap.get(stu.classId)?.code ?? "" : "" }));
    return c.json({ candidates }, 200);
  })

  // Add a student to an assessment (ad-hoc, outside their cohort). Idempotent:
  // clears any prior "remove" override and records an "add" override.
  .post("/reports/:examId/roster/add", requireAuth, requirePermission("reports"), async (c) => {
    const p = c.get("profile")!;
    const eid = c.req.param("examId");
    const b = await c.req.json().catch(() => ({}));
    const studentId = String(b.studentId ?? "");
    if (!studentId) return c.json({ message: "studentId required" }, 400);
    const [ex] = await db.select().from(schema.exams).where(eq(schema.exams.id, eid));
    if (!ex || ex.tenantId !== p.tenantId) return c.json({ message: "Not found" }, 404);
    const [stu] = await db.select().from(schema.students).where(eq(schema.students.id, studentId));
    if (!stu || stu.tenantId !== p.tenantId) return c.json({ message: "Student not found" }, 404);
    // Drop any existing override for this student, then add.
    await db.delete(schema.examRoster).where(and(eq(schema.examRoster.examId, eid), eq(schema.examRoster.studentId, studentId)));
    // Only need an explicit "add" row when the student isn't already a cohort match.
    await ensureOptInOnlyLoaded();
    if (!matchesCohort(ex, stu)) {
      await db.insert(schema.examRoster).values({ id: id("rst"), examId: eid, studentId, mode: "add", createdBy: p.userId ?? null });
    }
    return c.json({ ok: true }, 200);
  })

  // Remove a student from an assessment entirely: records a "remove" override
  // (so they drop off the roster/report) AND deletes any attempt + answers they
  // had for this exam, so they are not counted at all.
  .post("/reports/:examId/roster/remove", requireAuth, requirePermission("reports"), async (c) => {
    const p = c.get("profile")!;
    const eid = c.req.param("examId");
    const b = await c.req.json().catch(() => ({}));
    const studentId = String(b.studentId ?? "");
    if (!studentId) return c.json({ message: "studentId required" }, 400);
    const [ex] = await db.select().from(schema.exams).where(eq(schema.exams.id, eid));
    if (!ex || ex.tenantId !== p.tenantId) return c.json({ message: "Not found" }, 404);
    // Delete this student's attempt(s) + answers for the exam.
    const atts = await db.select().from(schema.attempts).where(and(eq(schema.attempts.examId, eid), eq(schema.attempts.studentId, studentId)));
    for (const a of atts) {
      await db.delete(schema.answers).where(eq(schema.answers.attemptId, a.id));
      await db.delete(schema.integrityEvents).where(eq(schema.integrityEvents.attemptId, a.id));
    }
    // Deleting events can free the top rowid, and the monitor's evidence cache reads
    // forward from a rowid watermark - a reused rowid would land below it. Force a
    // full rebuild; see lib/integrity-rollup.ts.
    integrityRollup.invalidateAll();
    // The attempts themselves are gone, so the owner cache must not keep
    // authorizing their former owners; see lib/attempt-owner.ts.
    attemptOwners.invalidateAll();
    // Evidence rows are going with them, so the stored-evidence counters must
    // be dropped too or a re-sit starts life already at its ceiling.
    evidenceMeter.invalidateAll();
    if (atts.length) await db.delete(schema.attempts).where(and(eq(schema.attempts.examId, eid), eq(schema.attempts.studentId, studentId)));
    // Record the remove override (clear any prior override first).
    await db.delete(schema.examRoster).where(and(eq(schema.examRoster.examId, eid), eq(schema.examRoster.studentId, studentId)));
    await db.insert(schema.examRoster).values({ id: id("rst"), examId: eid, studentId, mode: "remove", createdBy: p.userId ?? null });
    return c.json({ ok: true }, 200);
  })

  // Bulk-remove students from the assessment (checkbox selection on the report).
  .post("/reports/:examId/roster/bulk-remove", requireAuth, requirePermission("reports"), async (c) => {
    const p = c.get("profile")!;
    const eid = c.req.param("examId");
    const b = await c.req.json().catch(() => ({}));
    const studentIds = Array.isArray(b.studentIds) ? b.studentIds.map((s: unknown) => String(s)).filter(Boolean) : [];
    if (!studentIds.length) return c.json({ message: "studentIds required" }, 400);
    const [ex] = await db.select().from(schema.exams).where(eq(schema.exams.id, eid));
    if (!ex || ex.tenantId !== p.tenantId) return c.json({ message: "Not found" }, 404);
    let removed = 0;
    for (const studentId of studentIds) {
      const atts = await db.select().from(schema.attempts).where(and(eq(schema.attempts.examId, eid), eq(schema.attempts.studentId, studentId)));
      for (const a of atts) {
        await db.delete(schema.answers).where(eq(schema.answers.attemptId, a.id));
        await db.delete(schema.integrityEvents).where(eq(schema.integrityEvents.attemptId, a.id));
      }
      // Deleting events can free the top rowid, and the monitor's evidence cache reads
      // forward from a rowid watermark - a reused rowid would land below it. Force a
      // full rebuild; see lib/integrity-rollup.ts.
      integrityRollup.invalidateAll();
      // The attempts themselves are gone, so the owner cache must not keep
      // authorizing their former owners; see lib/attempt-owner.ts.
      attemptOwners.invalidateAll();
      // Evidence rows are going with them, so the stored-evidence counters must
      // be dropped too or a re-sit starts life already at its ceiling.
      evidenceMeter.invalidateAll();
      if (atts.length) await db.delete(schema.attempts).where(and(eq(schema.attempts.examId, eid), eq(schema.attempts.studentId, studentId)));
      await db.delete(schema.examRoster).where(and(eq(schema.examRoster.examId, eid), eq(schema.examRoster.studentId, studentId)));
      await db.insert(schema.examRoster).values({ id: id("rst"), examId: eid, studentId, mode: "remove", createdBy: p.userId ?? null });
      removed++;
    }
    return c.json({ ok: true, removed }, 200);
  })

  // Mark a student Absent: they STAY on the report (as "A") but are counted
  // absent. Ensures they are roster-eligible, then deletes any attempt so they
  // fall through to the auto-absent path (assigned + no attempt + deadline).
  .post("/reports/:examId/roster/mark-absent", requireAuth, requirePermission("reports"), async (c) => {
    const p = c.get("profile")!;
    const eid = c.req.param("examId");
    const b = await c.req.json().catch(() => ({}));
    const studentId = String(b.studentId ?? "");
    if (!studentId) return c.json({ message: "studentId required" }, 400);
    const [ex] = await db.select().from(schema.exams).where(eq(schema.exams.id, eid));
    if (!ex || ex.tenantId !== p.tenantId) return c.json({ message: "Not found" }, 404);
    const [stu] = await db.select().from(schema.students).where(eq(schema.students.id, studentId));
    if (!stu || stu.tenantId !== p.tenantId) return c.json({ message: "Student not found" }, 404);
    // Delete any attempt + answers so they read as absent (never attempted).
    const atts = await db.select().from(schema.attempts).where(and(eq(schema.attempts.examId, eid), eq(schema.attempts.studentId, studentId)));
    for (const a of atts) {
      await db.delete(schema.answers).where(eq(schema.answers.attemptId, a.id));
      await db.delete(schema.integrityEvents).where(eq(schema.integrityEvents.attemptId, a.id));
    }
    // Deleting events can free the top rowid, and the monitor's evidence cache reads
    // forward from a rowid watermark - a reused rowid would land below it. Force a
    // full rebuild; see lib/integrity-rollup.ts.
    integrityRollup.invalidateAll();
    // The attempts themselves are gone, so the owner cache must not keep
    // authorizing their former owners; see lib/attempt-owner.ts.
    attemptOwners.invalidateAll();
    // Evidence rows are going with them, so the stored-evidence counters must
    // be dropped too or a re-sit starts life already at its ceiling.
    evidenceMeter.invalidateAll();
    if (atts.length) await db.delete(schema.attempts).where(and(eq(schema.attempts.examId, eid), eq(schema.attempts.studentId, studentId)));
    // Guarantee roster eligibility: clear a stray "remove"; add an "add" override
    // only if the student isn't already a cohort match.
    await db.delete(schema.examRoster).where(and(eq(schema.examRoster.examId, eid), eq(schema.examRoster.studentId, studentId), eq(schema.examRoster.mode, "remove")));
    await ensureOptInOnlyLoaded();
    if (!matchesCohort(ex, stu)) {
      const existing = await db.select().from(schema.examRoster).where(and(eq(schema.examRoster.examId, eid), eq(schema.examRoster.studentId, studentId), eq(schema.examRoster.mode, "add")));
      if (!existing.length) await db.insert(schema.examRoster).values({ id: id("rst"), examId: eid, studentId, mode: "add", createdBy: p.userId ?? null });
    }
    return c.json({ ok: true }, 200);
  })

  // =================== SETTINGS ===================
  .post("/change-password", requireAuth, async (c) => {
    const user = c.get("user")!;
    const b = await c.req.json();
    const currentPassword = String(b.currentPassword ?? "");
    const newPassword = String(b.newPassword ?? "");
    if (newPassword.length < 8) return c.json({ message: "New password must be at least 8 characters" }, 400);
    const [acc] = await db.select().from(schema.account).where(and(eq(schema.account.userId, user.id), eq(schema.account.providerId, "credential")));
    if (!acc || !acc.password) return c.json({ message: "No credential account" }, 404);
    const valid = await verifyPassword({ hash: acc.password, password: currentPassword });
    if (!valid) return c.json({ message: "Current password is incorrect" }, 400);
    await db.update(schema.account).set({ password: await hashPassword(newPassword), updatedAt: new Date() }).where(eq(schema.account.id, acc.id));
    return c.json({ ok: true }, 200);
  })

  .get("/settings", requireAuth, requireSuperAdmin, async (c) => {
    const s = await getGlobalSettings();
    // mask keys
    const mask = (v: string | null) => (v ? `${v.slice(0, 4)}••••${v.slice(-3)}` : null);
    return c.json(
      {
        settings: {
          ...s,
          judge0Key: mask(s.judge0Key),
          claudeKey: mask(s.claudeKey),
          geminiKey: mask(s.geminiKey),
          openaiKey: mask(s.openaiKey),
          proctoring: { ...schema.DEFAULT_PROCTORING, ...(s.proctoring ?? {}) },
        },
      },
      200,
    );
  })
  .patch("/settings", requireAuth, requireSuperAdmin, async (c) => {
    const b = await c.req.json();
    const patch: Record<string, unknown> = { updatedAt: new Date() };
    for (const k of ["aiProvider", "judge0Limit", "aiLimit"]) if (b[k] !== undefined) patch[k] = b[k];
    // Platform-global quota defaults (lib/tenant-quota.ts). A cleared field, a
    // null, a 0 or junk all store NULL = unlimited: a ceiling of zero would
    // refuse every student on the platform, and the likeliest source of a 0 is an
    // empty input box rather than intent.
    for (const k of ["maxConcurrentAttempts", "maxEvidencePerAttempt"]) {
      if (b[k] === undefined) continue;
      const n = Math.floor(Number(b[k]));
      patch[k] = b[k] === null || b[k] === "" || !Number.isFinite(n) || n <= 0 ? null : n;
    }
    // only overwrite keys if a non-masked value is provided
    for (const k of ["judge0Key", "claudeKey", "geminiKey", "openaiKey"]) {
      if (b[k] !== undefined && b[k] !== null && !String(b[k]).includes("••")) patch[k] = b[k];
    }
    if (b.proctoring !== undefined) {
      const cur = await getGlobalSettings();
      patch.proctoring = { ...schema.DEFAULT_PROCTORING, ...(cur.proctoring ?? {}), ...b.proctoring };
    }
    await getGlobalSettings(); // ensure row exists
    const [s] = await db.update(schema.settings).set(patch).where(eq(schema.settings.id, GLOBAL_SETTINGS)).returning();
    invalidateGlobalSettings();
    // A changed default must apply now, not after the quota cache TTL.
    tenantQuotas.invalidateAll();
    return c.json({ ok: true, aiProvider: s.aiProvider }, 200);
  })

  // =================== AI EVALUATION (manual re-grade demo) ===================
  .post("/ai/grade", requireAuth, requirePermission("questionBank"), async (c) => {
    const b = await c.req.json();
    // Settings are a single global row keyed by id — there is no per-tenant
    // settings row (an earlier per-tenant lookup here referenced a column that
    // does not exist and 500'd this endpoint on every call).
    const s = await getGlobalSettings();
    const provider: string | null = s?.aiProvider ?? null;
    await db.update(schema.settings).set({ aiUsed: dsql`${schema.settings.aiUsed} + 1` }).where(eq(schema.settings.id, GLOBAL_SETTINGS));
    const res = await gradeSubjective({
      question: b.question,
      rubric: b.rubric,
      studentAnswer: b.studentAnswer,
      maxPoints: b.maxPoints ?? 10,
      isCode: b.isCode,
      language: b.language,
      provider,
    });
    return c.json(res, 200);
  });

export type AppType = typeof app;
export default app;
